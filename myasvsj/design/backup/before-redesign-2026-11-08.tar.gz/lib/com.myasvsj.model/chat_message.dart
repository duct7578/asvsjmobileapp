/// Một tin nhắn, ứng với một dòng của bảng `chat_messages` (Message của web).
///
/// JSON: `{id, mine, content, encrypted, replyToId, edited, recalled, reactions: [{emoji, count, mine}], fileIds,
/// createdAt}`.
class ChatMessage {
  const ChatMessage({
    required this.id,
    required this.mine,
    this.content,
    this.isEncrypted = false,
    this.replyToId,
    this.edited = false,
    this.recalled = false,
    this.reactions = const [],
    this.hasFiles = false,
    required this.createdAt,
  });

  final int id;

  /// Tin do người đang xem gửi.
  final bool mine;

  /// Chữ của tin thường; null khi tin đã mã hóa hoặc đã thu hồi.
  final String? content;

  /// Tin mã hóa đầu cuối (gửi từ web): chỉ trình duyệt có khóa đọc được, app chưa hỗ trợ.
  final bool isEncrypted;

  /// Tin được trả lời (trích dẫn), nếu có.
  final int? replyToId;

  final bool edited;

  /// "Tin nhắn đã được thu hồi": không còn chữ, cảm xúc, tệp.
  final bool recalled;

  /// Cảm xúc của tin (👍 ❤️ 😂 😮 😢 🙏): số người chọn, người đang xem có chọn không.
  final List<({String emoji, int count, bool mine})> reactions;

  /// Có ảnh, video hoặc ghi âm kèm theo (chỉ có trong hội thoại mã hóa).
  final bool hasFiles;

  final DateTime createdAt;

  /// Tin như server trả về sau khi sửa / thu hồi thay cho tin cũ cùng id.
  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    final created = json['createdAt'];
    return ChatMessage(
      id: json['id'] as int,
      mine: (json['mine'] ?? false) as bool,
      content: json['content'] as String?,
      isEncrypted: json['encrypted'] is Map,
      replyToId: json['replyToId'] as int?,
      edited: (json['edited'] ?? false) as bool,
      recalled: (json['recalled'] ?? false) as bool,
      reactions: [
        for (final r in (json['reactions'] as List?) ?? const [])
          if (r is Map<String, dynamic>)
            (emoji: (r['emoji'] ?? '') as String, count: (r['count'] ?? 0) as int, mine: (r['mine'] ?? false) as bool),
      ],
      hasFiles: ((json['fileIds'] as List?) ?? const []).isNotEmpty,
      createdAt: (created is String ? DateTime.tryParse(created)?.toLocal() : null) ?? DateTime.now(),
    );
  }

  static List<ChatMessage> listFrom(Object? json) => [
    for (final item in (json as List?) ?? const []) ChatMessage.fromJson(item as Map<String, dynamic>),
  ];
}
