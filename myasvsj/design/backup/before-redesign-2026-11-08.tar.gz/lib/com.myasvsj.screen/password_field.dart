import 'package:flutter/material.dart';

/// Ô nhập mật khẩu có nút Hiện / Ẩn, dùng ở Đăng nhập, Đăng ký, Đặt lại và Đổi mật khẩu.
class PasswordField extends StatefulWidget {
  const PasswordField({
    super.key,
    required this.controller,
    required this.label,
    this.errorText,
    this.helperText,
    this.isNewPassword = false,
    this.textInputAction,
    this.onSubmitted,
  });

  final TextEditingController controller;
  final String label;
  final String? errorText;
  final String? helperText;

  /// Mật khẩu mới: giới hạn 72 ký tự và gợi ý tự điền "mật khẩu mới".
  final bool isNewPassword;
  final TextInputAction? textInputAction;
  final ValueChanged<String>? onSubmitted;

  @override
  State<PasswordField> createState() => _PasswordFieldState();
}

class _PasswordFieldState extends State<PasswordField> {
  bool _visible = false;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: widget.controller,
      obscureText: !_visible,
      enableSuggestions: false,
      autocorrect: false,
      maxLength: widget.isNewPassword ? 72 : null,
      autofillHints: [widget.isNewPassword ? AutofillHints.newPassword : AutofillHints.password],
      textInputAction: widget.textInputAction,
      onSubmitted: widget.onSubmitted,
      decoration: InputDecoration(
        labelText: widget.label,
        errorText: widget.errorText,
        errorMaxLines: 3,
        helperText: widget.helperText,
        helperMaxLines: 2,
        counterText: '',
        suffixIcon: IconButton(
          tooltip: _visible ? 'Ẩn mật khẩu' : 'Hiện mật khẩu',
          icon: Icon(_visible ? Icons.visibility_off_outlined : Icons.visibility_outlined),
          onPressed: () => setState(() => _visible = !_visible),
        ),
      ),
    );
  }
}
