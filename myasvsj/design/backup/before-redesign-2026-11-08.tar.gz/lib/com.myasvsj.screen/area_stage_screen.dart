import 'dart:async';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/area_stage_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.model/area_option.dart';
import 'package:myasvsj/com.myasvsj.model/profile_stage.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/profile_sign_in_prompt.dart';
import 'package:myasvsj/com.myasvsj.screen/profile_user_watcher.dart';

/// Hàm lấy vị trí hiện tại của máy; trả về null khi không lấy được (bị từ chối quyền, tắt GPS…).
typedef AreaLocator = Future<({double lat, double lng})?> Function();

/// "Khu vực và giai đoạn": chọn giai đoạn (Sắp sang Nhật / Mới đến / Sắp về nước / Đã về nước) và khu vực sống
/// (tỉnh → quận / thành phố, tìm nhanh theo tên, hoặc "Vị trí của tôi"), rồi lưu.
///
/// Lưu xong thì đóng và trả về true (Trang chủ, trang Tôi dùng để tải lại).
class AreaStageScreen extends StatefulWidget {
  const AreaStageScreen({super.key, this.locate});

  /// Cách lấy vị trí cho "Vị trí của tôi"; null là dùng GPS của máy. Test truyền hàm giả.
  final AreaLocator? locate;

  @override
  State<AreaStageScreen> createState() => _AreaStageScreenState();
}

class _AreaStageScreenState extends State<AreaStageScreen> with ProfileUserWatcher {
  final _search = TextEditingController();
  Timer? _searchTimer;

  @override
  void onUserChanged(int? userId) {
    if (userId != null) {
      context.read<AreaStageController>().open();
    }
  }

  @override
  void dispose() {
    _searchTimer?.cancel();
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthController>().currentUser;
    watchUser(user?.id);
    return Scaffold(
      appBar: AppBar(title: const Text('Khu vực và giai đoạn')),
      body: user == null
          ? const ProfileSignInPrompt(text: 'Đăng nhập để chọn khu vực và giai đoạn của bạn.')
          : _body(context.watch<AreaStageController>()),
    );
  }

  Widget _body(AreaStageController areas) {
    if (areas.isLoading) {
      return const LoadingView();
    }
    if (areas.error != null) {
      return ErrorView(message: areas.error!, onRetry: areas.open);
    }
    final theme = Theme.of(context);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
      children: [
        Text(
          'Không bắt buộc. Dùng để gợi ý việc cần làm, review và sự kiện gần bạn. '
          'Chỉ lưu khu vực, không lưu địa chỉ; chỉ mình bạn thấy.',
          style: theme.textTheme.bodySmall,
        ),
        const SizedBox(height: 16),
        Text('Giai đoạn', style: theme.textTheme.titleMedium),
        const SizedBox(height: 8),
        _stages(areas),
        const SizedBox(height: 24),
        Text(areas.areaLabel, style: theme.textTheme.titleMedium),
        const SizedBox(height: 8),
        _current(areas),
        const SizedBox(height: 8),
        _searchBox(areas),
        const SizedBox(height: 8),
        _location(areas),
        const SizedBox(height: 16),
        _pickers(areas),
        const SizedBox(height: 8),
        Text(
          'Danh sách khu vực: Geolonia 住所データ (CC BY 4.0), dựa trên dữ liệu của デジタル庁.',
          style: theme.textTheme.bodySmall,
        ),
        if (areas.saveError != null) ...[
          const SizedBox(height: 12),
          Text(areas.saveError!, style: TextStyle(color: theme.colorScheme.error)),
        ],
        const SizedBox(height: 16),
        FilledButton(
          onPressed: areas.isSaving ? null : () => _save(areas),
          child: Text(areas.isSaving ? 'Đang lưu…' : 'Lưu'),
        ),
      ],
    );
  }

  Widget _stages(AreaStageController areas) {
    final error = areas.fieldErrors['stage'];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final stage in ProfileStage.all)
              ChoiceChip(
                label: Text(stage.label),
                selected: areas.stage == stage.code,
                // Bấm lại giai đoạn đang chọn để bỏ chọn
                onSelected: (on) => areas.selectStage(on ? stage.code : null),
              ),
          ],
        ),
        if (error != null)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(error, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ),
      ],
    );
  }

  /// Khu vực đang chọn, kèm nút bỏ chọn.
  Widget _current(AreaStageController areas) {
    final area = areas.area;
    if (area == null) {
      return Text('Chưa chọn khu vực.', style: Theme.of(context).textTheme.bodyMedium);
    }
    return Card(
      margin: EdgeInsets.zero,
      child: ListTile(
        leading: const Icon(Icons.place_outlined),
        title: Text(area.name.isEmpty ? area.label : area.name),
        trailing: IconButton(tooltip: 'Bỏ chọn khu vực', icon: const Icon(Icons.close), onPressed: areas.clearArea),
      ),
    );
  }

  Widget _searchBox(AreaStageController areas) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          controller: _search,
          textInputAction: TextInputAction.search,
          decoration: InputDecoration(
            labelText: 'Tìm khu vực theo tên',
            hintText: 'Tìm nhanh: Arakawa, 荒川, Osaka…',
            prefixIcon: const Icon(Icons.search),
            suffixIcon: _search.text.isEmpty
                ? null
                : IconButton(tooltip: 'Xóa', icon: const Icon(Icons.clear), onPressed: () => _clearSearch(areas)),
          ),
          onChanged: (text) {
            setState(() {}); // hiện / ẩn nút Xóa
            _searchTimer?.cancel();
            _searchTimer = Timer(const Duration(milliseconds: 300), () => areas.searchAreas(text));
          },
          onSubmitted: (text) {
            _searchTimer?.cancel();
            areas.searchAreas(text);
          },
        ),
        if (areas.isSearching) const LinearProgressIndicator(),
        for (final option in areas.searchResults)
          ListTile(
            dense: true,
            leading: const Icon(Icons.place_outlined),
            title: Text(_withPrefecture(areas, option), maxLines: 1, overflow: TextOverflow.ellipsis),
            subtitle: Text(option.nameJa),
            onTap: () => _choose(areas, option),
          ),
        if (areas.searchFoundNothing)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(
              'Không tìm thấy khu vực nào. Thử tên khác hoặc chọn tỉnh ở dưới.',
              style: theme.textTheme.bodySmall,
            ),
          ),
        if (areas.searchError != null)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(areas.searchError!, style: TextStyle(color: theme.colorScheme.error)),
          ),
      ],
    );
  }

  /// "Arakawa-ku, Tokyo" như kết quả tìm của web.
  String _withPrefecture(AreaStageController areas, AreaOption option) {
    final prefecture = areas.prefectureOf(option.prefectureCode);
    return prefecture == null ? option.nameEn : '${option.nameEn}, ${prefecture.nameEn}';
  }

  Widget _location(AreaStageController areas) {
    final theme = Theme.of(context);
    final suggested = areas.suggested;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            OutlinedButton.icon(
              onPressed: areas.isLocating ? null : () => _locate(areas),
              icon: const Icon(Icons.my_location),
              label: const Text('Vị trí của tôi'),
            ),
            if (areas.isLocating) ...[
              const SizedBox(width: 12),
              const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
            ],
          ],
        ),
        Text('Vị trí chỉ dùng để gợi ý khu vực, không được lưu.', style: theme.textTheme.bodySmall),
        if (suggested != null)
          Card(
            margin: const EdgeInsets.only(top: 8),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Khu vực gợi ý: ${suggested.name.isEmpty ? suggested.label : suggested.name}'),
                  const SizedBox(height: 8),
                  FilledButton.tonal(onPressed: areas.useSuggested, child: const Text('Dùng khu vực này')),
                ],
              ),
            ),
          ),
        if (areas.locateMessage != null)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(areas.locateMessage!, style: theme.textTheme.bodySmall),
          ),
      ],
    );
  }

  /// Ô chọn tỉnh, rồi ô chọn khu vực của tỉnh đó.
  Widget _pickers(AreaStageController areas) {
    final selectedArea = areas.areas.any((a) => a.id == areas.area?.id) ? areas.area?.id : null;
    final canPickArea = areas.prefectureCode != null && !areas.isLoadingAreas && areas.areasError == null;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        DropdownButtonFormField<String?>(
          // Khóa theo giá trị: ô chọn đổi theo Controller (tìm nhanh, gợi ý vị trí, bỏ chọn)
          key: ValueKey('prefecture-${areas.prefectureCode}'),
          initialValue: areas.prefectureCode,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Tỉnh / thành phố'),
          items: [
            const DropdownMenuItem<String?>(value: null, child: Text('Chưa chọn')),
            for (final p in areas.prefectures)
              DropdownMenuItem<String?>(
                value: p.code,
                child: Text(p.label, maxLines: 1, overflow: TextOverflow.ellipsis),
              ),
          ],
          onChanged: areas.selectPrefecture,
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<int?>(
          key: ValueKey('area-${areas.prefectureCode}-$selectedArea-${areas.areas.length}'),
          initialValue: selectedArea,
          isExpanded: true,
          decoration: InputDecoration(
            labelText: areas.areaLabel,
            helperText: areas.prefectureCode == null ? 'Chọn tỉnh trước' : null,
          ),
          hint: Text(areas.isLoadingAreas ? 'Đang tải…' : 'Chưa chọn'),
          items: [
            const DropdownMenuItem<int?>(value: null, child: Text('Chưa chọn')),
            for (final a in areas.areas)
              DropdownMenuItem<int?>(
                value: a.id,
                child: Text(a.label, maxLines: 1, overflow: TextOverflow.ellipsis),
              ),
          ],
          onChanged: canPickArea ? areas.selectArea : null,
        ),
        if (areas.areasError != null)
          Row(
            children: [
              Expanded(
                child: Text(areas.areasError!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ),
              TextButton(onPressed: areas.retryAreas, child: const Text('Thử lại')),
            ],
          ),
      ],
    );
  }

  void _clearSearch(AreaStageController areas) {
    _searchTimer?.cancel();
    _search.clear();
    areas.searchAreas('');
    setState(() {});
  }

  Future<void> _choose(AreaStageController areas, AreaOption option) async {
    _searchTimer?.cancel();
    _search.clear();
    FocusScope.of(context).unfocus();
    await areas.chooseArea(option);
  }

  /// "Vị trí của tôi": server thử có vị trí cố định thì dùng nó; ngược lại hỏi quyền rồi lấy GPS.
  Future<void> _locate(AreaStageController areas) async {
    final dev = areas.devLocation;
    if (dev != null) {
      await areas.suggestNearest(dev.lat, dev.lng);
      return;
    }
    areas.startLocating();
    final position = await (widget.locate ?? _devicePosition)();
    if (!mounted) {
      return;
    }
    if (position == null) {
      areas.locationUnavailable();
    } else {
      await areas.suggestNearest(position.lat, position.lng);
    }
  }

  /// Vị trí từ GPS của máy; hệ điều hành hỏi người dùng trước. Không lấy được thì trả về null.
  static Future<({double lat, double lng})?> _devicePosition() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        return null;
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        return null;
      }
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.low, timeLimit: Duration(seconds: 15)),
      );
      return (lat: position.latitude, lng: position.longitude);
    } catch (_) {
      // Hết thời gian, máy không có GPS, plugin chưa sẵn sàng…
      return null;
    }
  }

  Future<void> _save(AreaStageController areas) async {
    final saved = await areas.save();
    if (saved && mounted) {
      showMessage(context, areas.takeMessage());
      Navigator.pop(context, true);
    }
  }
}
