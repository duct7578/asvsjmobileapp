import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.model/legal_document.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';

/// Văn bản pháp lý đang hiệu lực, như trang /terms của web: Điều khoản sử dụng, Chính sách bảo mật,
/// Quy tắc cộng đồng.
class LegalScreen extends StatefulWidget {
  const LegalScreen({super.key, required this.type});

  /// Loại văn bản: 'terms' (server gọi là 'tos'), 'privacy' hoặc 'community'.
  final String type;

  @override
  State<LegalScreen> createState() => _LegalScreenState();
}

class _LegalScreenState extends State<LegalScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() => context.read<AuthController>().loadLegal(widget.type);

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    return Scaffold(
      appBar: AppBar(title: Text(LegalDocument.titleOf(widget.type))),
      body: _body(auth),
    );
  }

  Widget _body(AuthController auth) {
    final doc = auth.legalOf(widget.type);
    if (doc == null) {
      final error = auth.legalErrorOf(widget.type);
      if (error != null && !auth.isLoadingLegal(widget.type)) {
        return ErrorView(message: error, onRetry: _load);
      }
      return const LoadingView();
    }
    final theme = Theme.of(context);
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Phiên bản ${doc.version}', style: theme.textTheme.bodySmall),
          const SizedBox(height: 12),
          SelectableText(doc.content, style: theme.textTheme.bodyLarge?.copyWith(height: 1.5)),
        ],
      ),
    );
  }
}
