import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:myasvsj/com.myasvsj.model/blog_place.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/place_detail_screen.dart';

/// "Địa điểm liên quan" của bài: bấm tên mở trang địa điểm, nút "Chỉ đường" mở Google Maps.
class BlogPlaceList extends StatelessWidget {
  const BlogPlaceList({super.key, required this.places});

  final List<BlogPlace> places;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(Icons.map_outlined, size: 20, color: Theme.of(context).colorScheme.primary),
            const SizedBox(width: 6),
            Text('Địa điểm liên quan', style: Theme.of(context).textTheme.titleMedium),
          ],
        ),
        for (final place in places)
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.location_on_outlined),
            title: Text(place.name, maxLines: 2, overflow: TextOverflow.ellipsis),
            subtitle: place.detail.isEmpty ? null : Text(place.detail, maxLines: 2, overflow: TextOverflow.ellipsis),
            onTap: place.id == null
                ? null
                : () => Navigator.push(
                    context,
                    MaterialPageRoute<void>(builder: (_) => PlaceDetailScreen(placeId: place.id!)),
                  ),
            trailing: TextButton.icon(
              onPressed: () => _directions(context, place),
              icon: const Icon(Icons.directions_outlined, size: 18),
              label: const Text('Chỉ đường'),
            ),
          ),
      ],
    );
  }

  static Future<void> _directions(BuildContext context, BlogPlace place) async {
    var opened = false;
    try {
      opened = await launchUrl(Uri.parse(place.directionsUrl), mode: LaunchMode.externalApplication);
    } catch (_) {
      opened = false;
    }
    if (!opened && context.mounted) {
      showMessage(context, 'Không mở được Google Maps.');
    }
  }
}
