import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/phrase_controller.dart';
import 'package:myasvsj/com.myasvsj.model/phrase.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/phrase_icon.dart';
import 'package:myasvsj/com.myasvsj.screen/phrase_list_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/phrase_staff_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/report_dialog.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// Thẻ một mẫu câu / từ vựng (kết quả tìm và các bộ), như phraseCard() của web: nhãn loại, loại địa điểm và chủ đề
/// (bấm để mở bộ đó), dấu "Chưa thuộc" / "Đã thuộc"; chữ Nhật lớn, romaji, nghĩa; các nút "Đưa cho nhân viên xem"
/// (chỉ mẫu câu), "Nghe", "Bỏ đánh dấu" (thành viên, mục đã có dấu) và "Báo lỗi" (khách được đưa sang Đăng nhập).
class PhraseCard extends StatelessWidget {
  const PhraseCard({super.key, required this.phrase, this.showCategory = true});

  final Phrase phrase;

  /// Ẩn loại địa điểm khi cả bộ đã là loại địa điểm đó.
  final bool showCategory;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final member = context.select<PhraseController, bool>((c) => c.isMember);
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 6,
              runSpacing: 6,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                _Badge(label: Phrase.kindName(phrase.kind)),
                if (showCategory && phrase.category.id.isNotEmpty)
                  _Badge(
                    label: phrase.category.name,
                    icon: phrase.category.icon,
                    onTap: () => _openSet(context, categoryId: phrase.category.id),
                  ),
                for (final topic in phrase.topics)
                  _Badge(
                    label: topic.name,
                    outlined: true,
                    onTap: () => _openSet(context, topicId: topic.id),
                  ),
                if (phrase.learned)
                  _Badge(label: 'Đã thuộc', mark: Icons.check_circle_outline, color: theme.colorScheme.primaryContainer)
                else if (phrase.learning)
                  _Badge(label: 'Chưa thuộc', mark: Icons.replay, color: theme.colorScheme.tertiaryContainer),
              ],
            ),
            const SizedBox(height: 10),
            Text(phrase.japanese, locale: const Locale('ja'), style: theme.textTheme.headlineSmall),
            if (phrase.romaji.isNotEmpty)
              Text(phrase.romaji, style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.outline)),
            const SizedBox(height: 4),
            Text(phrase.meaningVi, style: theme.textTheme.bodyLarge),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                if (phrase.isPhrase)
                  FilledButton.tonalIcon(
                    onPressed: () => _showStaff(context),
                    icon: const Icon(Icons.front_hand_outlined),
                    label: const Text('Đưa cho nhân viên xem'),
                  ),
                OutlinedButton.icon(
                  onPressed: () => _speak(context),
                  icon: const Icon(Icons.volume_up_outlined),
                  label: const Text('Nghe'),
                ),
                if (member && !phrase.isNew)
                  TextButton.icon(
                    onPressed: () => _clearMark(context),
                    icon: const Icon(Icons.undo),
                    label: const Text('Bỏ đánh dấu'),
                  ),
                TextButton.icon(
                  onPressed: () => _report(context),
                  icon: const Icon(Icons.flag_outlined),
                  label: const Text('Báo lỗi'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _openSet(BuildContext context, {String? topicId, String? categoryId}) {
    Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (_) => PhraseListScreen(topicId: topicId, categoryId: categoryId),
      ),
    );
  }

  void _showStaff(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute<void>(fullscreenDialog: true, builder: (_) => PhraseStaffScreen(phrase: phrase)),
    );
  }

  Future<void> _speak(BuildContext context) async {
    final phrases = context.read<PhraseController>();
    final spoken = await phrases.speak(phrase.japanese);
    if (!spoken && context.mounted) {
      showMessage(context, phrases.takeMessage());
    }
  }

  Future<void> _clearMark(BuildContext context) async {
    final phrases = context.read<PhraseController>();
    await phrases.clearMark(phrase);
    if (context.mounted) {
      showMessage(context, phrases.takeMessage());
    }
  }

  /// "Báo lỗi": khách đăng nhập trước; lý do lấy từ trang đầu (Sai tiếng Nhật, Sai nghĩa, Xúc phạm, Spam).
  Future<void> _report(BuildContext context) async {
    if (!await requireSignIn(context) || !context.mounted) {
      return;
    }
    final phrases = context.read<PhraseController>();
    if (phrases.reportReasons.isEmpty) {
      await phrases.loadOverview();
      if (!context.mounted) {
        return;
      }
    }
    final choice = await showReportDialog(context, reasons: phrases.reportReasons, title: 'Báo lỗi mẫu câu');
    if (choice == null || !context.mounted) {
      return;
    }
    await phrases.report(phrase.id, choice.reasonId, choice.note);
    if (context.mounted) {
      showMessage(context, phrases.takeMessage());
    }
  }
}

/// Nhãn nhỏ trên thẻ (loại, địa điểm, chủ đề, dấu thuộc); có [onTap] thì bấm được.
class _Badge extends StatelessWidget {
  const _Badge({required this.label, this.icon, this.mark, this.color, this.outlined = false, this.onTap});

  final String label;

  /// Biểu tượng của web (loại địa điểm).
  final String? icon;

  /// Biểu tượng Flutter (dấu thuộc).
  final IconData? mark;
  final Color? color;
  final bool outlined;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final style = Theme.of(context).textTheme.labelMedium;
    return Material(
      color: outlined ? Colors.transparent : (color ?? scheme.secondaryContainer),
      shape: StadiumBorder(side: outlined ? BorderSide(color: scheme.outlineVariant) : BorderSide.none),
      child: InkWell(
        customBorder: const StadiumBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (icon != null) ...[PhraseIcon(icon!, size: 14), const SizedBox(width: 4)],
              if (mark != null) ...[Icon(mark, size: 14), const SizedBox(width: 4)],
              Flexible(
                child: Text(label, style: style, maxLines: 1, overflow: TextOverflow.ellipsis),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
