import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.screen/auth_notice.dart';
import 'package:myasvsj/com.myasvsj.screen/forgot_password_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/password_field.dart';
import 'package:myasvsj/com.myasvsj.screen/register_screen.dart';

/// Màn hình đăng nhập bằng email (UC đăng nhập của web). Đăng nhập xong thì đóng và trả về true.
///
/// Có đường sang "Quên mật khẩu?" và "Đăng ký"; đăng ký xong app đăng nhập luôn nên màn này cũng đóng với true.
/// Tài khoản staff bị từ chối (AuthController.staffMessage).
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Lỗi của lần mở trước không hiện lại
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<AuthController>().clearForm());
  }

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Đăng nhập')),
      body: AutofillGroup(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text('Chào mừng bạn quay lại Senpai ơi.', style: theme.textTheme.titleMedium),
            const SizedBox(height: 16),
            if (auth.bannerError != null) AuthNotice(text: auth.bannerError!),
            TextField(
              controller: _email,
              keyboardType: TextInputType.emailAddress,
              autofillHints: const [AutofillHints.email],
              autocorrect: false,
              textInputAction: TextInputAction.next,
              decoration: InputDecoration(labelText: 'Email', errorText: auth.fieldErrors['email']),
            ),
            const SizedBox(height: 12),
            PasswordField(
              controller: _password,
              label: 'Mật khẩu',
              errorText: auth.fieldErrors['password'],
              textInputAction: TextInputAction.done,
              onSubmitted: (_) => _login(),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(onPressed: auth.isLoading ? null : _forgot, child: const Text('Quên mật khẩu?')),
            ),
            FilledButton(
              onPressed: auth.isLoading ? null : _login,
              child: Text(auth.isLoading ? 'Đang đăng nhập…' : 'Đăng nhập'),
            ),
            const SizedBox(height: 16),
            Wrap(
              alignment: WrapAlignment.center,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                const Text('Chưa có tài khoản?'),
                TextButton(onPressed: auth.isLoading ? null : _register, child: const Text('Đăng ký')),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _login() async {
    final auth = context.read<AuthController>();
    final ok = await auth.login(_email.text, _password.text);
    if (!mounted) {
      return;
    }
    if (ok) {
      TextInput.finishAutofillContext();
      Navigator.pop(context, true);
    } else {
      // Như trang web: nhập lại mật khẩu sau mỗi lần thất bại
      _password.clear();
    }
  }

  Future<void> _forgot() async {
    await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => ForgotPasswordScreen(initialEmail: _email.text.trim())),
    );
    if (!mounted) {
      return;
    }
    context.read<AuthController>().clearForm();
  }

  Future<void> _register() async {
    final signedIn = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => const RegisterScreen(fromLogin: true)),
    );
    if (!mounted) {
      return;
    }
    if (signedIn == true) {
      Navigator.pop(context, true);
      return;
    }
    context.read<AuthController>().clearForm();
  }
}
