import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/interest_controller.dart';
import 'package:myasvsj/com.myasvsj.model/interest_topic.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/profile_sign_in_prompt.dart';
import 'package:myasvsj/com.myasvsj.screen/profile_user_watcher.dart';

/// "Chủ đề quan tâm": chọn tối đa 5 chủ đề blog để "Dành cho bạn" gợi ý bài của các chủ đề này trước.
/// Chủ đề server học được từ những gì người dùng hay đọc mang dấu gợi ý. Lưu xong thì đóng và trả về true.
class InterestScreen extends StatefulWidget {
  const InterestScreen({super.key});

  @override
  State<InterestScreen> createState() => _InterestScreenState();
}

class _InterestScreenState extends State<InterestScreen> with ProfileUserWatcher {
  @override
  void onUserChanged(int? userId) {
    if (userId != null) {
      context.read<InterestController>().load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthController>().currentUser;
    watchUser(user?.id);
    return Scaffold(
      appBar: AppBar(title: const Text('Chủ đề quan tâm')),
      body: user == null
          ? const ProfileSignInPrompt(text: 'Đăng nhập để chọn chủ đề bạn quan tâm.')
          : _body(context.watch<InterestController>()),
    );
  }

  Widget _body(InterestController interests) {
    if (interests.isLoading) {
      return const LoadingView();
    }
    if (interests.error != null) {
      return ErrorView(message: interests.error!, onRetry: interests.load);
    }
    final theme = Theme.of(context);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
      children: [
        Text('Không bắt buộc. Chỉ mình bạn thấy.', style: theme.textTheme.bodySmall),
        const SizedBox(height: 8),
        Text(
          'Chọn tối đa ${interests.max} chủ đề. Bài thuộc các chủ đề này được gợi ý trước trong “Dành cho bạn”. '
          'Đã chọn ${interests.selectedIds.length}/${interests.max}.',
        ),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: [for (final topic in interests.topics) _chip(interests, topic)]),
        if (interests.hasSuggestions) ...[
          const SizedBox(height: 12),
          Row(
            children: [
              Icon(Icons.history, size: 18, color: theme.colorScheme.outline),
              const SizedBox(width: 6),
              Expanded(
                child: Text('Gợi ý: chủ đề bạn hay đọc, thích hoặc lưu gần đây.', style: theme.textTheme.bodySmall),
              ),
            ],
          ),
        ],
        if (interests.saveError != null) ...[
          const SizedBox(height: 12),
          Text(interests.saveError!, style: TextStyle(color: theme.colorScheme.error)),
        ],
        const SizedBox(height: 16),
        FilledButton(
          onPressed: interests.isSaving ? null : () => _save(interests),
          child: Text(interests.isSaving ? 'Đang lưu…' : 'Lưu'),
        ),
      ],
    );
  }

  Widget _chip(InterestController interests, InterestTopic topic) {
    final selected = interests.isSelected(topic.id);
    final blocked = interests.isFull && !selected;
    final chip = FilterChip(
      label: Text(topic.name),
      selected: selected,
      // Chủ đề gợi ý chưa chọn mang biểu tượng "lịch sử", như trên web
      avatar: topic.learnt && !selected ? const Icon(Icons.history, size: 18) : null,
      onSelected: blocked || interests.isSaving ? null : (_) => interests.toggle(topic.id),
    );
    return blocked ? Tooltip(message: 'Đã chọn đủ ${interests.max} chủ đề', child: chip) : chip;
  }

  Future<void> _save(InterestController interests) async {
    final saved = await interests.save();
    if (saved && mounted) {
      showMessage(context, interests.takeMessage());
      Navigator.pop(context, true);
    }
  }
}
