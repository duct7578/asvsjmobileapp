import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.screen/media_image.dart';

/// Ảnh đại diện tròn của một thành viên trong "Tin nhắn"; chưa có ảnh thì hiện chữ cái đầu của tên.
class ChatAvatar extends StatelessWidget {
  const ChatAvatar({super.key, required this.name, this.url = '', this.radius = 20});

  final String name;

  /// Đường dẫn ảnh của server; rỗng khi chưa có.
  final String url;
  final double radius;

  @override
  Widget build(BuildContext context) {
    if (url.isNotEmpty) {
      return MediaImage(url: url, width: radius * 2, height: radius * 2, radius: radius);
    }
    final trimmed = name.trim();
    return CircleAvatar(radius: radius, child: Text(trimmed.isEmpty ? '?' : trimmed.characters.first.toUpperCase()));
  }
}
