import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:myasvsj/com.myasvsj.model/faq_entry.dart';
import 'package:myasvsj/com.myasvsj.model/faq_resource.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';
import 'package:myasvsj/com.myasvsj.screen/faq_answer_text.dart';
import 'package:myasvsj/com.myasvsj.screen/faq_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/guide_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/question_detail_screen.dart';

/// Một câu hỏi thường gặp mở rộng tại chỗ (giống `faqItem` của web): câu hỏi và chủ đề; bấm vào hiện câu trả lời,
/// các liên kết "Xem thêm", ngày cập nhật và "Mở riêng câu này".
///
/// Dùng ở tab "Câu hỏi thường gặp", màn FaqScreen, phần FAQ liên quan trên kết quả tìm câu hỏi và gợi ý khi đặt câu
/// hỏi.
class FaqTile extends StatelessWidget {
  const FaqTile({super.key, required this.entry, this.initiallyExpanded = false, this.showOpenLink = true});

  final FaqEntry entry;
  final bool initiallyExpanded;

  /// Hiện nút "Mở riêng câu này" (ẩn khi câu đã đang được mở riêng).
  final bool showOpenLink;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final resources = entry.resources.where(_usable).toList();
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        key: PageStorageKey<String>('faq-${entry.id}'),
        initiallyExpanded: initiallyExpanded,
        shape: const Border(),
        collapsedShape: const Border(),
        leading: Icon(Icons.quiz_outlined, color: theme.colorScheme.primary),
        title: Text(entry.question, style: theme.textTheme.titleSmall),
        subtitle: entry.topicName.isEmpty ? null : Text(entry.topicName, style: theme.textTheme.bodySmall),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [
          FaqAnswerText(text: entry.answer),
          if (resources.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text('Xem thêm', style: theme.textTheme.labelLarge),
            for (final r in resources)
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  style: TextButton.styleFrom(padding: EdgeInsets.zero, visualDensity: VisualDensity.compact),
                  onPressed: () => _open(context, r),
                  icon: Icon(r.isExternal ? Icons.open_in_new : Icons.link, size: 18),
                  label: Text(r.label, maxLines: 2, overflow: TextOverflow.ellipsis),
                ),
              ),
          ],
          Row(
            children: [
              if (entry.updatedAt != null)
                Expanded(child: Text('Cập nhật ${formatDate(entry.updatedAt!)}', style: theme.textTheme.bodySmall))
              else
                const Spacer(),
              if (showOpenLink)
                TextButton(
                  onPressed: () =>
                      Navigator.push(context, MaterialPageRoute<void>(builder: (_) => FaqScreen(faqId: entry.id))),
                  child: const Text('Mở riêng câu này'),
                ),
            ],
          ),
        ],
      ),
    );
  }

  /// Liên kết mở được: web chỉ hiện địa chỉ http(s) và cẩm nang / bài viết / câu hỏi có id.
  static bool _usable(FaqResource r) {
    if (r.isExternal) {
      final uri = Uri.tryParse(r.url ?? '');
      return uri != null && (uri.scheme == 'http' || uri.scheme == 'https') && uri.host.isNotEmpty;
    }
    return r.targetId != null && const {'GUIDE', 'BLOG', 'QUESTION'}.contains(r.kind);
  }

  static void _open(BuildContext context, FaqResource r) {
    if (r.isExternal) {
      launchUrl(Uri.parse(r.url!), mode: LaunchMode.externalApplication);
      return;
    }
    final id = r.targetId!;
    final Widget screen = switch (r.kind) {
      'GUIDE' => GuideDetailScreen(guideId: id),
      'BLOG' => BlogDetailScreen(blogId: id),
      _ => QuestionDetailScreen(questionId: id),
    };
    Navigator.push(context, MaterialPageRoute<void>(builder: (_) => screen));
  }
}
