import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/media_item.dart';
import 'package:myasvsj/com.myasvsj.model/place_review.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';
import 'package:myasvsj/com.myasvsj.screen/media_image.dart';
import 'package:myasvsj/com.myasvsj.screen/place_rating_stars.dart';

/// Một review trong chi tiết địa điểm: tác giả, số sao, nội dung, ảnh, và nút Thích / Báo cáo (review của người
/// khác) hoặc Sửa / Xóa (review của mình).
class PlaceReviewCard extends StatelessWidget {
  const PlaceReviewCard({
    super.key,
    required this.review,
    this.canAct = true,
    this.onLike,
    this.onReport,
    this.onEdit,
    this.onDelete,
    this.now,
  });

  final PlaceReview review;

  /// false khi người xem là tài khoản staff (chỉ xem): khóa Thích / Báo cáo. Khách vẫn bấm được (sang Đăng nhập).
  final bool canAct;
  final VoidCallback? onLike;
  final VoidCallback? onReport;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  /// Giờ hiện tại để tính "Còn mới" (test truyền vào); mặc định là giờ máy.
  final DateTime? now;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final author = review.author;
    final at = now ?? DateTime.now();
    final badges = [
      ...author.tagNames,
      if (author.rankName.isNotEmpty) author.rankName,
      if (review.authorRoleLabel.isNotEmpty) review.authorRoleLabel,
    ];
    final actOnOthers = canAct && review.isPublished;
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      color: review.mine ? scheme.secondaryContainer.withValues(alpha: 0.4) : null,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 16,
                  child: Text(author.displayName.isEmpty ? '?' : author.displayName.characters.first.toUpperCase()),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        author.displayName,
                        style: theme.textTheme.titleSmall,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      if (badges.isNotEmpty)
                        Text(
                          badges.join(' · '),
                          style: theme.textTheme.bodySmall,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 4,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                PlaceRatingStars(rating: review.rating.toDouble()),
                if (review.isFresh(at)) _tag(context, 'Còn mới'),
                if (review.isOld(at)) _tag(context, 'Hơn 1 năm, cần xác minh lại'),
                if (review.helpful) _tag(context, 'Hữu ích'),
                if (review.isProcessing) _tag(context, 'Đang xử lý ảnh'),
              ],
            ),
            const SizedBox(height: 8),
            Text(review.content),
            if (review.images.isNotEmpty) ...[
              const SizedBox(height: 8),
              SizedBox(
                height: 88,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: review.images.length,
                  separatorBuilder: (_, _) => const SizedBox(width: 8),
                  itemBuilder: (_, i) => GestureDetector(
                    onTap: () => _showImage(context, review.images[i]),
                    child: MediaImage(url: review.images[i].url, width: 88, height: 88),
                  ),
                ),
              ),
            ],
            const SizedBox(height: 8),
            Text(
              [if (review.createdAt != null) formatTimeAgo(review.createdAt!), if (review.edited) 'đã sửa'].join(' · '),
              style: theme.textTheme.bodySmall,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            // Nút xuống dòng khi màn hẹp
            OverflowBar(
              alignment: MainAxisAlignment.end,
              overflowAlignment: OverflowBarAlignment.end,
              children: [
                if (review.mine) ...[
                  TextButton.icon(onPressed: onEdit, icon: const Icon(Icons.edit, size: 18), label: const Text('Sửa')),
                  TextButton.icon(
                    onPressed: onDelete,
                    icon: Icon(Icons.delete_outline, size: 18, color: scheme.error),
                    label: Text('Xóa', style: TextStyle(color: scheme.error)),
                  ),
                ] else ...[
                  TextButton.icon(
                    onPressed: actOnOthers ? onLike : null,
                    icon: Icon(review.liked ? Icons.thumb_up : Icons.thumb_up_outlined, size: 18),
                    label: Text(review.likeCount > 0 ? 'Thích (${review.likeCount})' : 'Thích'),
                  ),
                  TextButton.icon(
                    onPressed: actOnOthers ? onReport : null,
                    icon: const Icon(Icons.flag_outlined, size: 18),
                    label: const Text('Báo cáo'),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _tag(BuildContext context, String text) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(color: scheme.tertiaryContainer, borderRadius: BorderRadius.circular(8)),
      child: Text(text, style: TextStyle(fontSize: 12, color: scheme.onTertiaryContainer)),
    );
  }

  /// Ảnh lớn khi bấm vào ảnh nhỏ.
  void _showImage(BuildContext context, MediaItem image) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => Dialog(
        insetPadding: const EdgeInsets.all(12),
        child: Stack(
          children: [
            InteractiveViewer(
              child: MediaImage(url: image.url, fit: BoxFit.contain),
            ),
            Positioned(
              right: 4,
              top: 4,
              child: IconButton.filledTonal(
                tooltip: 'Đóng',
                icon: const Icon(Icons.close),
                onPressed: () => Navigator.pop(dialogContext),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
