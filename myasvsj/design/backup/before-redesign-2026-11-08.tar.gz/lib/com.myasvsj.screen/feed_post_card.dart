import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/feed_post.dart';
import 'package:myasvsj/com.myasvsj.model/feed_reason.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';
import 'package:myasvsj/com.myasvsj.screen/home_format.dart';
import 'package:myasvsj/com.myasvsj.screen/search_highlight.dart';

/// Một bài của "Dành cho bạn" (trang chủ và màn "Dành cho bạn"): lý do được chọn, tiêu đề, đoạn trích, chủ đề,
/// tác giả, lượt thích, bình luận. Bấm vào thì mở bài viết.
class FeedPostCard extends StatelessWidget {
  const FeedPostCard({super.key, required this.post, this.showExcerpt = true, this.query = ''});

  final FeedPost post;

  /// Bài đầu của trang chủ và mọi bài ở màn "Dành cho bạn" có đoạn trích; các bài sau trên trang chủ thì không.
  final bool showExcerpt;

  /// Từ khóa đang tìm, được tô trong tiêu đề và đoạn trích.
  final String query;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final meta = theme.textTheme.bodySmall;
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => pushScreen<void>(context, BlogDetailScreen(blogId: post.id)),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (post.reasons.isNotEmpty) ...[
                Wrap(spacing: 6, runSpacing: 4, children: [for (final r in post.reasons) _ReasonChip(reason: r)]),
                const SizedBox(height: 8),
              ],
              SearchHighlight(text: post.title, query: query, style: theme.textTheme.titleMedium, maxLines: 2),
              if (showExcerpt && post.excerpt.isNotEmpty) ...[
                const SizedBox(height: 4),
                SearchHighlight(text: post.excerpt, query: query, style: theme.textTheme.bodyMedium, maxLines: 3),
              ],
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 4,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  if ((post.topicName ?? '').isNotEmpty)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(post.topicName!, style: theme.textTheme.labelSmall),
                    ),
                  Text(
                    [post.authorName, if (post.createdAt != null) formatTimeAgo(post.createdAt!)].join(' · '),
                    style: meta,
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.favorite_border, size: 14),
                      Text(' ${post.likeCount}', style: meta, semanticsLabel: '${post.likeCount} lượt thích'),
                      const SizedBox(width: 8),
                      const Icon(Icons.chat_bubble_outline, size: 14),
                      Text(' ${post.commentCount}', style: meta, semanticsLabel: '${post.commentCount} bình luận'),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Một lý do: "Gần khu vực của bạn · Ga Nippori".
class _ReasonChip extends StatelessWidget {
  const _ReasonChip({required this.reason});

  final FeedReason reason;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final (icon, background, foreground) = switch (reason.code) {
      'AREA' => (Icons.location_on_outlined, scheme.primaryContainer, scheme.onPrimaryContainer),
      'PREFECTURE' => (Icons.map_outlined, scheme.primaryContainer, scheme.onPrimaryContainer),
      'STAGE' => (Icons.flag_outlined, scheme.secondaryContainer, scheme.onSecondaryContainer),
      'INTEREST' => (Icons.interests_outlined, scheme.tertiaryContainer, scheme.onTertiaryContainer),
      _ => (Icons.auto_awesome_outlined, scheme.surfaceContainerHighest, scheme.onSurface),
    };
    final detail = reason.detail;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: background, borderRadius: BorderRadius.circular(12)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: foreground),
          const SizedBox(width: 4),
          Flexible(
            child: Text.rich(
              TextSpan(
                children: [
                  TextSpan(text: reason.label),
                  if (detail != null && detail.isNotEmpty) ...[
                    const TextSpan(text: ' · '),
                    TextSpan(
                      text: detail,
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ],
                ],
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.labelSmall?.copyWith(color: foreground),
            ),
          ),
        ],
      ),
    );
  }
}
