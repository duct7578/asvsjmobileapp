import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/review_controller.dart';
import 'package:myasvsj/com.myasvsj.model/media_item.dart';
import 'package:myasvsj/com.myasvsj.model/review_compose.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/media_image.dart';
import 'package:myasvsj/com.myasvsj.screen/photo_picker.dart';
import 'package:myasvsj/com.myasvsj.screen/review_star_picker.dart';

/// Form viết review (UC-U16, khi không có [reviewId]) và sửa review (UC-U17), xóa review (UC-U18) ở thanh tiêu đề
/// khi sửa. 1–5 sao, nội dung 10–2.000 ký tự, tối đa 5 ảnh. Khi lưu hoặc xóa xong, màn hình đóng và trả về true để
/// màn trước hiện câu thông báo của server (`ReviewController.takeMessage`).
class ReviewFormScreen extends StatefulWidget {
  const ReviewFormScreen({super.key, this.placeId, this.reviewId, this.externalPlaceId, this.placeName = ''});

  /// Viết review cho địa điểm [placeId], hoặc sửa review [reviewId].
  final int? placeId;
  final int? reviewId;

  /// Địa điểm OpenStreetMap chưa có trên Senpai ơi ("Viết review đầu tiên"): server thêm địa điểm khi lưu.
  final String? externalPlaceId;

  /// Tên địa điểm để hiện trên form.
  final String placeName;

  @override
  State<ReviewFormScreen> createState() => _ReviewFormScreenState();
}

class _ReviewFormScreenState extends State<ReviewFormScreen> {
  final _content = TextEditingController();
  int _rating = 0;

  /// Ảnh cũ giữ lại (khi sửa) và ảnh mới chọn trên máy.
  List<MediaItem> _keep = [];
  List<String> _newPaths = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final reviews = context.read<ReviewController>();
    await reviews.openForm(placeId: widget.placeId, externalPlaceId: widget.externalPlaceId, reviewId: widget.reviewId);
    final old = reviews.editing;
    if (!mounted || old == null) {
      return;
    }
    _content.text = old.content;
    setState(() {
      _rating = old.rating;
      _keep = [
        for (final m in old.media)
          if (m.isImage) m,
      ];
    });
  }

  @override
  void dispose() {
    _content.dispose();
    super.dispose();
  }

  /// Có thay đổi chưa lưu: hỏi trước khi bỏ (giống "Bỏ review đang viết?" của web).
  bool _dirty(ReviewController reviews) {
    if (_newPaths.isNotEmpty) {
      return true;
    }
    return reviews.editing == null && (_rating > 0 || _content.text.trim().isNotEmpty);
  }

  @override
  Widget build(BuildContext context) {
    final reviews = context.watch<ReviewController>();
    final editing = reviews.editing;
    return PopScope(
      canPop: reviews.isSaving || !_dirty(reviews),
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) {
          _confirmLeave();
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(editing == null && widget.reviewId == null ? 'Viết review' : 'Sửa review'),
          actions: [
            if (editing != null)
              IconButton(
                tooltip: 'Xóa review',
                icon: const Icon(Icons.delete_outline),
                onPressed: reviews.isSaving ? null : () => _delete(reviews, editing.id!),
              ),
          ],
        ),
        body: _body(reviews),
      ),
    );
  }

  Widget _body(ReviewController reviews) {
    if (reviews.isLoadingForm) {
      return const LoadingView();
    }
    final compose = reviews.compose;
    if (compose == null) {
      // Không mở được form: chưa đăng nhập, tài khoản staff, review không phải của mình hoặc đã bị xóa
      return ErrorView(message: reviews.formError ?? 'Không mở được form review.', onRetry: _load);
    }
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final editing = reviews.editing;
    final errors = reviews.fieldErrors;
    final placeName = editing?.placeName.isNotEmpty == true ? editing!.placeName : widget.placeName;
    final room = compose.imagesMax - _keep.length;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (placeName.isNotEmpty) Text(placeName, style: theme.textTheme.titleLarge),
        if (editing != null && editing.isRejected)
          _notice(
            'Review chưa được đăng vì ảnh hoặc video vi phạm Quy tắc cộng đồng. Hãy sửa rồi lưu lại.',
            scheme.errorContainer,
          ),
        if (editing == null && compose.newAccount) _notice(_quotaText(compose), scheme.secondaryContainer),
        const SizedBox(height: 12),
        Text('Đánh giá *', style: theme.textTheme.titleSmall),
        ReviewStarPicker(value: _rating, errorText: errors['rating'], onChanged: (n) => setState(() => _rating = n)),
        const SizedBox(height: 8),
        TextField(
          controller: _content,
          minLines: 5,
          maxLines: 12,
          maxLength: compose.contentMax,
          onChanged: (_) => setState(() {}),
          decoration: InputDecoration(
            labelText: 'Nội dung *',
            hintText: 'Bạn thấy nơi này thế nào? Có mẹo gì cho người mới không?',
            helperText: 'Ít nhất ${compose.contentMin} ký tự',
            alignLabelWithHint: true,
            border: const OutlineInputBorder(),
            errorText: errors['content'],
          ),
        ),
        const SizedBox(height: 12),
        if (_keep.isNotEmpty) ...[
          Text('Ảnh đang có (${_keep.length})'),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [for (final m in _keep) _keptThumb(m, editing?.scanningMediaIds)]),
          const SizedBox(height: 12),
        ],
        if (editing != null && editing.media.any((m) => !m.isImage))
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Text('Video đã gắn (đăng từ web) được giữ nguyên.', style: theme.textTheme.bodySmall),
          ),
        if (room > 0 || _newPaths.isNotEmpty)
          PhotoPicker(
            paths: _newPaths,
            max: room < _newPaths.length ? _newPaths.length : room,
            label: _keep.isEmpty ? 'Ảnh (không bắt buộc)' : 'Ảnh mới',
            onChanged: (paths) => setState(() => _newPaths = paths),
          ),
        const SizedBox(height: 4),
        Text(
          'Tối đa ${compose.imagesMax} ảnh. Ảnh được quét tự động trước khi hiện cho mọi người.',
          style: theme.textTheme.bodySmall,
        ),
        for (final key in const ['images', 'place'])
          if (errors[key] != null) Text(errors[key]!, style: TextStyle(color: scheme.error)),
        if (reviews.formError != null)
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Text(reviews.formError!, style: TextStyle(color: scheme.error)),
          ),
        const SizedBox(height: 16),
        FilledButton(
          onPressed: reviews.isSaving ? null : () => _save(reviews),
          child: Text(reviews.isSaving ? 'Đang gửi…' : (editing == null ? 'Đăng review' : 'Lưu thay đổi')),
        ),
      ],
    );
  }

  Widget _notice(String text, Color color) => Card(
    margin: const EdgeInsets.only(top: 12),
    color: color,
    child: Padding(padding: const EdgeInsets.all(12), child: Text(text)),
  );

  static String _quotaText(ReviewCompose c) =>
      'Tài khoản mới (dưới ${c.newAccountDays} ngày): hôm nay còn ${c.postsLeft}/${c.postsLimit} lượt đăng bài viết '
      'hoặc review.';

  Widget _keptThumb(MediaItem media, List<int>? scanning) {
    return Stack(
      children: [
        MediaImage(url: media.url, width: 80, height: 80),
        if (scanning?.contains(media.id) == true)
          Positioned(
            left: 4,
            bottom: 4,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              color: Theme.of(context).colorScheme.surface,
              child: const Text('Đang quét', style: TextStyle(fontSize: 11)),
            ),
          ),
        Positioned(
          right: 0,
          top: 0,
          child: InkWell(
            onTap: () => setState(
              () => _keep = [
                for (final m in _keep)
                  if (m.id != media.id) m,
              ],
            ),
            child: const Tooltip(
              message: 'Bỏ ảnh này',
              child: CircleAvatar(radius: 12, child: Icon(Icons.close, size: 16)),
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _save(ReviewController reviews) async {
    FocusScope.of(context).unfocus();
    final saved = await reviews.saveReview(
      placeId: widget.placeId,
      externalPlaceId: widget.externalPlaceId,
      rating: _rating,
      content: _content.text,
      keep: _keep,
      imagePaths: _newPaths,
    );
    if (saved && mounted) {
      Navigator.pop(context, true);
    }
  }

  Future<void> _delete(ReviewController reviews, int id) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Xóa review?'),
        content: const Text('Xóa review này? Điểm của review này sẽ được thu lại.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Xóa')),
        ],
      ),
    );
    if (confirmed != true || !mounted) {
      return;
    }
    if (await reviews.deleteReview(id) && mounted) {
      Navigator.pop(context, true);
    } else if (mounted) {
      showMessage(context, reviews.takeMessage());
    }
  }

  Future<void> _confirmLeave() async {
    final leave = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Bỏ review đang viết?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Viết tiếp')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Bỏ')),
        ],
      ),
    );
    if (leave == true && mounted) {
      Navigator.pop(context, false);
    }
  }
}
