import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/home_event.dart';
import 'package:myasvsj/com.myasvsj.model/home_featured.dart';
import 'package:myasvsj/com.myasvsj.model/home_member.dart';
import 'package:myasvsj/com.myasvsj.model/home_review.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';
import 'package:myasvsj/com.myasvsj.screen/event_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/event_list_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/home_for_you_section.dart';
import 'package:myasvsj/com.myasvsj.screen/home_format.dart';
import 'package:myasvsj/com.myasvsj.screen/home_next_card.dart';
import 'package:myasvsj/com.myasvsj.screen/home_phrase_card.dart';
import 'package:myasvsj/com.myasvsj.screen/home_search_box.dart';
import 'package:myasvsj/com.myasvsj.screen/home_tag_chips.dart';
import 'package:myasvsj/com.myasvsj.screen/place_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/profile_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/recent_reviews_screen.dart';

/// Trang chủ của thành viên (thứ tự như home.js của web): lời chào, ô tìm kiếm, "Dành cho bạn", "Việc tiếp theo",
/// "Review mới quanh …", sự kiện 2 tuần tới, câu tiếng Nhật hôm nay, bài nổi bật.
class HomeMemberView extends StatelessWidget {
  const HomeMemberView({
    super.key,
    required this.home,
    this.banner,
    this.notice,
    this.showAreaPrompt = false,
    required this.onHidePrompt,
    required this.onSettingsSaved,
  });

  final HomeMember home;

  /// Báo lỗi khi tải lại (giữ trang cũ); null khi không có.
  final Widget? banner;
  final String? notice;
  final bool showAreaPrompt;
  final VoidCallback onHidePrompt;
  final VoidCallback onSettingsSaved;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final stage = home.stage ?? '';
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        ?banner,
        Row(
          children: [
            CircleAvatar(
              backgroundColor: theme.colorScheme.primaryContainer,
              child: Icon(Icons.local_florist_outlined, color: theme.colorScheme.onPrimaryContainer),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    homeGreeting(displayName: home.displayName, stage: home.stage, areaName: home.areaName),
                    style: theme.textTheme.titleLarge,
                  ),
                  Wrap(
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      if (stage.isNotEmpty) Text('Giai đoạn của bạn: ${stageName(stage)} · '),
                      InkWell(
                        onTap: () => pushScreen<void>(context, const ProfileScreen()),
                        child: Text(
                          '${home.points} điểm · ${home.rankName}',
                          style: TextStyle(color: theme.colorScheme.primary),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        const HomeSearchBox(),
        const SizedBox(height: 12),
        HomeForYouSection(
          home: home,
          notice: notice,
          showAreaPrompt: showAreaPrompt,
          onHidePrompt: onHidePrompt,
          onSettingsSaved: onSettingsSaved,
        ),
        if (home.guide != null) HomeNextCard(guide: home.guide!),
        _ReviewsCard(home: home),
        _EventsCard(events: home.events),
        if (home.phrase != null) HomePhraseCard(phrase: home.phrase!),
        if (home.featured != null) _FeaturedCard(featured: home.featured!),
      ],
    );
  }
}

/// Đầu thẻ: biểu tượng, tên, nút "Tất cả" bên phải.
class _CardHead extends StatelessWidget {
  const _CardHead({required this.icon, required this.title, required this.onAll});

  final IconData icon;
  final String title;
  final VoidCallback onAll;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      children: [
        Icon(icon, color: theme.colorScheme.primary),
        const SizedBox(width: 8),
        Expanded(
          child: Text(title, style: theme.textTheme.titleMedium, maxLines: 2, overflow: TextOverflow.ellipsis),
        ),
        TextButton(onPressed: onAll, child: const Text('Tất cả')),
      ],
    );
  }
}

/// "Review mới quanh …": 3 review, trong khu vực trước rồi trong tỉnh. Tiêu đề chỉ nói "quanh" khi có review
/// thật sự ở khu vực; mỗi review mở địa điểm của nó.
class _ReviewsCard extends StatelessWidget {
  const _ReviewsCard({required this.home});

  final HomeMember home;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final reviews = home.reviews;
    final area = home.areaName ?? '';
    final inArea = reviews.any((r) => r.near == 'AREA');
    final inPrefecture = reviews.any((r) => r.near == 'PREFECTURE');
    final title = area.isEmpty
        ? 'Review mới'
        : inArea
        ? 'Review mới quanh ${areaShort(area)}'
        : inPrefecture
        ? 'Review mới ở ${prefectureShort(area)}'
        : 'Review mới';
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _CardHead(
              icon: Icons.rate_review_outlined,
              title: title,
              onAll: () => pushScreen<void>(context, const RecentReviewsScreen()),
            ),
            if (area.isNotEmpty && reviews.isNotEmpty && !inArea)
              Text(
                'Chưa có review nào ở ${areaShort(area)}, đây là review mới '
                '${inPrefecture ? 'trong tỉnh' : 'ở nơi khác'}.',
                style: theme.textTheme.bodySmall,
              ),
            if (reviews.isEmpty) const Text('Chưa có review mới.'),
            for (final review in reviews) _ReviewTile(review: review),
          ],
        ),
      ),
    );
  }
}

class _ReviewTile extends StatelessWidget {
  const _ReviewTile({required this.review});

  final HomeReview review;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final where = areaRoman(review.placeArea);
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(categoryIcon(review.categoryIcon)),
      title: Text.rich(
        TextSpan(
          children: [
            TextSpan(text: review.placeName),
            const TextSpan(text: '  '),
            TextSpan(
              text: starText(review.rating),
              style: TextStyle(color: theme.colorScheme.tertiary),
              semanticsLabel: '${review.rating} sao',
            ),
          ],
        ),
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
      ),
      subtitle: Text(
        '${review.authorName}: ${review.excerpt}\n'
        '${[if (where.isNotEmpty) where, if (review.createdAt != null) formatTimeAgo(review.createdAt!)].join(' · ')}',
        maxLines: 4,
        overflow: TextOverflow.ellipsis,
      ),
      onTap: () => pushScreen<void>(context, PlaceDetailScreen(placeId: review.placeId)),
    );
  }
}

/// "Sự kiện 2 tuần tới".
class _EventsCard extends StatelessWidget {
  const _EventsCard({required this.events});

  final List<HomeEvent> events;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _CardHead(
              icon: Icons.celebration_outlined,
              title: 'Sự kiện 2 tuần tới',
              onAll: () => pushScreen<void>(context, const EventListScreen()),
            ),
            if (events.isEmpty) const Text('Chưa có sự kiện nào trong 2 tuần tới.'),
            for (final event in events)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Container(
                  width: 48,
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.secondaryContainer,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('${event.startDate.day}', style: theme.textTheme.titleMedium),
                      Text('Th${event.startDate.month}', style: theme.textTheme.labelSmall),
                    ],
                  ),
                ),
                title: Text(event.title, maxLines: 2, overflow: TextOverflow.ellipsis),
                subtitle: Text(
                  [eventWhen(event.daysUntil), if (event.locationName.isNotEmpty) event.locationName].join(' · '),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                onTap: () => pushScreen<void>(context, EventDetailScreen(eventId: event.id)),
              ),
          ],
        ),
      ),
    );
  }
}

/// "Bài nổi bật tuần này / tháng này".
class _FeaturedCard extends StatelessWidget {
  const _FeaturedCard({required this.featured});

  final HomeFeatured featured;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => pushScreen<void>(context, BlogDetailScreen(blogId: featured.id)),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.star_outline, color: theme.colorScheme.primary),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Bài nổi bật ${featured.isThisWeek ? 'tuần này' : 'tháng này'}',
                      style: theme.textTheme.titleMedium,
                    ),
                  ),
                  Text('${featured.readMinutes} phút đọc', style: theme.textTheme.bodySmall),
                ],
              ),
              const SizedBox(height: 8),
              Text(featured.title, style: theme.textTheme.titleSmall, maxLines: 2, overflow: TextOverflow.ellipsis),
              if (featured.excerpt.isNotEmpty) Text(featured.excerpt, maxLines: 3, overflow: TextOverflow.ellipsis),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  Text(featured.authorName, style: theme.textTheme.labelLarge),
                  HomeTagChips(tags: featured.authorTags),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
