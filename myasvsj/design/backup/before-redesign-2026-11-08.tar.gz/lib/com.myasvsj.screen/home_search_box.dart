import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:myasvsj/com.myasvsj.screen/global_search_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/home_format.dart';

/// Ô "Tìm trên Senpai ơi" của trang chủ: gõ rồi bấm "Tìm" (hoặc Enter) để mở màn Tìm kiếm với chữ đã gõ.
/// Ô trống thì không mở, con trỏ ở lại trong ô.
class HomeSearchBox extends StatefulWidget {
  const HomeSearchBox({super.key});

  @override
  State<HomeSearchBox> createState() => _HomeSearchBoxState();
}

class _HomeSearchBoxState extends State<HomeSearchBox> {
  final _text = TextEditingController();
  final _focus = FocusNode();

  @override
  void dispose() {
    _text.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _search() {
    final q = _text.text.trim();
    if (q.isEmpty) {
      _focus.requestFocus();
      return;
    }
    _focus.unfocus();
    pushScreen<void>(context, GlobalSearchScreen(initialQuery: q));
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: TextField(
            key: const ValueKey('home-search'),
            controller: _text,
            focusNode: _focus,
            textInputAction: TextInputAction.search,
            inputFormatters: [LengthLimitingTextInputFormatter(100)],
            onSubmitted: (_) => _search(),
            decoration: const InputDecoration(
              hintText: 'Tìm địa điểm, bài viết, sự kiện…',
              prefixIcon: Icon(Icons.search),
              border: OutlineInputBorder(),
              isDense: true,
            ),
          ),
        ),
        const SizedBox(width: 8),
        FilledButton(onPressed: _search, child: const Text('Tìm')),
      ],
    );
  }
}
