import 'package:flutter/material.dart';

/// Biểu tượng của một chủ đề học hoặc loại địa điểm Nhật ngữ. Server gửi tên Material Symbols của web
/// ("payments", "local_convenience_store"…); tên lạ hiện nhãn chung.
class PhraseIcon extends StatelessWidget {
  const PhraseIcon(this.name, {super.key, this.size, this.color});

  final String name;
  final double? size;
  final Color? color;

  /// Tên của web → biểu tượng Flutter: biểu tượng chủ đề (AcademicService.ICONS), loại địa điểm (place_categories)
  /// và hai phần Mẫu câu / Từ vựng.
  static const Map<String, IconData> icons = {
    'label': Icons.label_outline,
    'payments': Icons.payments_outlined,
    'help': Icons.help_outline,
    'restaurant_menu': Icons.restaurant_menu,
    'train': Icons.train_outlined,
    'medical_services': Icons.medical_services_outlined,
    'description': Icons.description_outlined,
    'waving_hand': Icons.waving_hand_outlined,
    'home': Icons.home_outlined,
    'bed': Icons.bed_outlined,
    'work': Icons.work_outline,
    'school': Icons.school_outlined,
    'shopping_cart': Icons.shopping_cart_outlined,
    'local_post_office': Icons.local_post_office_outlined,
    'smartphone': Icons.smartphone,
    'directions_bus': Icons.directions_bus_outlined,
    'local_laundry_service': Icons.local_laundry_service_outlined,
    'emergency': Icons.emergency_outlined,
    'celebration': Icons.celebration_outlined,
    'account_balance': Icons.account_balance_outlined,
    'translate': Icons.translate,
    'forum': Icons.forum_outlined,
    'local_convenience_store': Icons.local_convenience_store_outlined,
    'restaurant': Icons.restaurant,
    'local_hospital': Icons.local_hospital_outlined,
    'local_pharmacy': Icons.local_pharmacy_outlined,
    'park': Icons.park_outlined,
    'temple_buddhist': Icons.temple_buddhist_outlined,
    'home_work': Icons.home_work_outlined,
    'place': Icons.place_outlined,
    'chat': Icons.chat_outlined,
    'abc': Icons.abc,
  };

  @override
  Widget build(BuildContext context) => Icon(icons[name] ?? Icons.label_outline, size: size, color: color);
}
