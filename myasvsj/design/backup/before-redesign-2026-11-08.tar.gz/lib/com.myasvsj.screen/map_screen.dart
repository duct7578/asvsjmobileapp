import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/place_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/review_controller.dart';
import 'package:myasvsj/com.myasvsj.model/map_festival.dart';
import 'package:myasvsj/com.myasvsj.model/map_place.dart';
import 'package:myasvsj/com.myasvsj.model/place_option.dart';
import 'package:myasvsj/com.myasvsj.screen/app_bar_actions.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/event_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/map_distance_text.dart';
import 'package:myasvsj/com.myasvsj.screen/map_pin.dart';
import 'package:myasvsj/com.myasvsj.screen/map_result_panel.dart';
import 'package:myasvsj/com.myasvsj.screen/place_category_icon.dart';
import 'package:myasvsj/com.myasvsj.screen/place_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/place_summary_sheet.dart';
import 'package:myasvsj/com.myasvsj.screen/review_form_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// Tab Bản đồ (UC-U14): bản đồ OpenStreetMap với ghim địa điểm theo danh mục, lớp sự kiện 15 / 30 ngày, tìm địa
/// điểm, "Địa điểm quanh đây" (chạm bản đồ khi đã phóng to), "Vị trí của tôi". Bấm ghim → bảng tóm tắt →
/// chi tiết địa điểm.
class MapScreen extends StatefulWidget {
  const MapScreen({super.key, this.focusPlaceId, this.showTiles = true});

  /// Mở bản đồ tại địa điểm này; null = khu vực của tôi hoặc mặc định.
  final int? focusPlaceId;

  /// false trong widget test: không tải ô bản đồ từ mạng (test không có mạng).
  final bool showTiles;

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  static const _tileUrl = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
  static const _focusZoom = 16.0;

  final _map = MapController();
  final _search = TextEditingController();
  bool _mapReady = false;
  bool _focusDone = false;
  int? _selectedId;
  LatLng? _tapPoint;

  /// Người đang đăng nhập lúc dựng lần trước: đổi thì tải lại ghim (ghim chờ duyệt của mình, khu vực của tôi).
  int? _userId;
  bool _userSeen = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<PlaceController>().loadMap());
  }

  @override
  void dispose() {
    _search.dispose();
    _map.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final places = context.watch<PlaceController>();
    _watchUser(context.watch<AuthController>().currentUser?.id);
    return Scaffold(
      appBar: AppBar(title: const Text('Bản đồ'), actions: const [AppBarActions()]),
      body: Column(
        children: [
          _searchBox(places),
          _categoryChips(places),
          _eventChips(places),
          Expanded(child: _mapArea(places)),
          if (places.isPanelOpen)
            ConstrainedBox(
              constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height * 0.4),
              child: MapResultPanel(onOpen: _openOption, onCategory: _pickCategory),
            ),
        ],
      ),
    );
  }

  void _watchUser(int? userId) {
    if (_userSeen && userId == _userId) {
      return;
    }
    final changed = _userSeen;
    _userSeen = true;
    _userId = userId;
    if (changed) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          context.read<PlaceController>().refreshMap();
        }
      });
    }
  }

  // ---------------------------------------------------------------- công cụ trên cùng

  Widget _searchBox(PlaceController places) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      child: TextField(
        controller: _search,
        textInputAction: TextInputAction.search,
        inputFormatters: [LengthLimitingTextInputFormatter(100)],
        onChanged: (_) => setState(() {}),
        onSubmitted: (text) => _runSearch(places, text),
        decoration: InputDecoration(
          hintText: 'Tìm địa điểm',
          prefixIcon: const Icon(Icons.search),
          suffixIcon: _search.text.isEmpty
              ? null
              : IconButton(
                  tooltip: 'Xóa từ khóa',
                  icon: const Icon(Icons.close),
                  onPressed: () {
                    _search.clear();
                    places.closePanel();
                    setState(() {});
                  },
                ),
          isDense: true,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(24)),
        ),
      ),
    );
  }

  Widget _categoryChips(PlaceController places) {
    return SizedBox(
      height: 48,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        children: [
          Padding(
            padding: const EdgeInsets.only(right: 6),
            child: ChoiceChip(
              label: Text('Tất cả (${places.totalCount})'),
              selected: places.categoryId == null,
              onSelected: (_) => places.setCategory(null),
            ),
          ),
          for (final category in places.activeCategories)
            Padding(
              padding: const EdgeInsets.only(right: 6),
              child: ChoiceChip(
                avatar: Icon(placeCategoryIcon(category.icon), size: 18),
                label: Text('${category.name} (${category.count})'),
                selected: places.categoryId == category.id,
                onSelected: (on) => _pickCategory(on ? category.id : null),
              ),
            ),
        ],
      ),
    );
  }

  Widget _eventChips(PlaceController places) {
    const labels = {0: 'Tắt', 15: '15 ngày tới', 30: '30 ngày tới'};
    return SizedBox(
      height: 44,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        children: [
          const Padding(
            padding: EdgeInsets.only(right: 6),
            child: Row(children: [Icon(Icons.celebration, size: 18), SizedBox(width: 4), Text('Sự kiện:')]),
          ),
          for (final days in PlaceController.eventDayChoices)
            Padding(
              padding: const EdgeInsets.only(right: 6),
              child: ChoiceChip(
                label: Text(labels[days]!),
                selected: places.eventDays == days,
                onSelected: (_) => places.setEventDays(days),
                visualDensity: VisualDensity.compact,
              ),
            ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------- bản đồ

  Widget _mapArea(PlaceController places) {
    final overview = places.overview;
    if (overview == null) {
      if (places.mapError != null) {
        return ErrorView(message: places.mapError!, onRetry: places.loadMap);
      }
      return const LoadingView();
    }
    final scheme = Theme.of(context).colorScheme;
    final start = _focusPlace(places);
    return Stack(
      children: [
        FlutterMap(
          mapController: _map,
          options: MapOptions(
            initialCenter: start == null ? LatLng(places.center.lat, places.center.lng) : LatLng(start.lat, start.lng),
            initialZoom: start == null ? places.center.zoom : _focusZoom,
            minZoom: 3,
            maxZoom: 19,
            interactionOptions: const InteractionOptions(flags: InteractiveFlag.all & ~InteractiveFlag.rotate),
            onMapReady: _onMapReady,
            onTap: (_, point) => _onMapTap(places, point),
          ),
          children: [
            if (widget.showTiles)
              TileLayer(urlTemplate: _tileUrl, userAgentPackageName: 'com.example.myasvsj', maxNativeZoom: 19),
            MarkerLayer(markers: _markers(places)),
          ],
        ),
        // Ghi nguồn bản đồ (bắt buộc với ô bản đồ OpenStreetMap); bấm mở trang bản quyền
        Positioned(
          right: 0,
          bottom: 0,
          child: GestureDetector(
            onTap: () =>
                launchUrl(Uri.parse('https://www.openstreetmap.org/copyright'), mode: LaunchMode.externalApplication),
            child: ColoredBox(
              color: scheme.surface.withValues(alpha: 0.85),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                child: Text('© OpenStreetMap', style: Theme.of(context).textTheme.labelSmall),
              ),
            ),
          ),
        ),
        if (places.isLoadingMap) const Positioned(top: 0, left: 0, right: 0, child: LinearProgressIndicator()),
        Positioned(
          top: 12,
          right: 12,
          child: Column(
            children: [
              FloatingActionButton.small(
                heroTag: null,
                tooltip: 'Vị trí của tôi',
                onPressed: places.isLocating ? null : () => _locate(places),
                child: places.isLocating
                    ? SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2, color: scheme.onPrimaryContainer),
                      )
                    : Icon(places.myLocation == null ? Icons.location_searching : Icons.my_location),
              ),
              const SizedBox(height: 8),
              FloatingActionButton.small(
                heroTag: null,
                tooltip: 'Chú thích',
                onPressed: _showLegend,
                child: const Icon(Icons.info_outline),
              ),
            ],
          ),
        ),
      ],
    );
  }

  /// Địa điểm cần mở khi vào màn hình ([MapScreen.focusPlaceId]), nếu có ghim.
  MapPlace? _focusPlace(PlaceController places) {
    final id = widget.focusPlaceId;
    return id == null || _focusDone ? null : places.placeById(id);
  }

  List<Marker> _markers(PlaceController places) {
    final scheme = Theme.of(context).colorScheme;
    return [
      for (final event in places.events)
        Marker(
          point: LatLng(event.lat, event.lng),
          width: 96,
          height: 58,
          child: _EventPin(key: ValueKey('map-event-${event.id}'), event: event, onTap: () => _showEvent(event)),
        ),
      for (final option in places.panelItems)
        if (!option.isOnSenpai && option.lat != null && option.lng != null)
          Marker(
            point: LatLng(option.lat!, option.lng!),
            width: 34,
            height: 34,
            child: _OsmPin(
              key: ValueKey('map-osm-${option.externalId}'),
              icon: places.categoryByName(option.category)?.icon,
              label: '${option.name}, OpenStreetMap, chưa có trên Senpai ơi',
              onTap: () => _showOption(option),
            ),
          ),
      for (final place in places.places)
        Marker(
          point: LatLng(place.lat, place.lng),
          width: place.isLit ? MapPin.litSize : MapPin.dimSize,
          height: place.isLit ? MapPin.litSize : MapPin.dimSize,
          child: MapPin(
            key: ValueKey('map-pin-${place.id}'),
            place: place,
            icon: places.categoryById(place.categoryId)?.icon ?? 'place',
            selected: _selectedId == place.id,
            onTap: () => _showPlace(place),
          ),
        ),
      if (_tapPoint != null && places.panelTitle == PlaceController.nearbyTitle)
        Marker(
          point: _tapPoint!,
          width: 18,
          height: 18,
          child: Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: scheme.tertiary.withValues(alpha: 0.5),
              border: Border.all(color: scheme.tertiary, width: 2),
            ),
          ),
        ),
      if (places.myLocation != null)
        Marker(
          point: LatLng(places.myLocation!.lat, places.myLocation!.lng),
          width: 20,
          height: 20,
          child: Semantics(
            label: 'Vị trí của bạn',
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: scheme.primary,
                border: Border.all(color: scheme.surface, width: 3),
              ),
            ),
          ),
        ),
    ];
  }

  void _onMapReady() {
    _mapReady = true;
    final id = widget.focusPlaceId;
    if (id != null && !_focusDone) {
      _focusOn(id);
    }
  }

  /// Mở bản đồ tại địa điểm [id]: có ghim thì mở bảng tóm tắt; không có (ví dụ ghim vừa thêm) thì hỏi chi tiết.
  Future<void> _focusOn(int id) async {
    final places = context.read<PlaceController>();
    final pin = places.placeById(id);
    _focusDone = true;
    if (pin != null) {
      _showPlace(pin);
      return;
    }
    await places.loadPlace(id);
    if (!mounted) {
      return;
    }
    final detail = places.detailOf(id);
    if (detail == null || detail.lat == null || detail.lng == null) {
      showMessage(context, places.detailErrorOf(id) ?? 'Địa điểm này chưa có vị trí trên bản đồ.');
      return;
    }
    _moveTo(detail.lat!, detail.lng!);
    _openDetail(id);
  }

  void _moveTo(double lat, double lng, {double? zoom}) {
    if (!_mapReady) {
      return;
    }
    final current = _map.camera.zoom;
    _map.move(LatLng(lat, lng), zoom ?? (current < _focusZoom ? _focusZoom : current));
  }

  /// Chạm bản đồ khi đã phóng to: "Địa điểm quanh đây".
  void _onMapTap(PlaceController places, LatLng point) {
    if (_map.camera.zoom < PlaceController.nearbyZoom) {
      showMessage(context, 'Phóng to bản đồ rồi chạm vào chỗ bạn muốn để xem các địa điểm quanh đó.');
      return;
    }
    setState(() => _tapPoint = point);
    _search.clear();
    places.loadNearby(point.latitude, point.longitude, signedIn: context.read<AuthController>().isSignedIn);
  }

  Future<void> _runSearch(PlaceController places, String text) async {
    if (text.trim().isEmpty) {
      return;
    }
    FocusScope.of(context).unfocus();
    await places.search(text);
    if (!mounted || !_mapReady) {
      return;
    }
    final points = [
      for (final o in places.panelItems)
        if (o.lat != null && o.lng != null) LatLng(o.lat!, o.lng!),
    ];
    if (points.isNotEmpty) {
      _map.fitCamera(CameraFit.coordinates(coordinates: points, padding: const EdgeInsets.all(48), maxZoom: 16));
    }
  }

  void _pickCategory(String? id) {
    _search.clear();
    context.read<PlaceController>().setCategory(id);
  }

  Future<void> _locate(PlaceController places) async {
    final note = await places.locateMe();
    if (!mounted) {
      return;
    }
    showMessage(context, note);
    final me = places.myLocation;
    if (me != null) {
      _moveTo(me.lat, me.lng, zoom: _focusZoom);
    }
  }

  // ---------------------------------------------------------------- bảng dưới

  /// Bấm một kết quả trong bảng: địa điểm có ghim → bảng tóm tắt; địa điểm OpenStreetMap → bảng "chưa có".
  void _openOption(PlaceOption option) {
    final places = context.read<PlaceController>();
    final pin = option.id == null ? null : places.placeById(option.id!);
    if (pin != null) {
      _moveTo(pin.lat, pin.lng);
      _showPlace(pin);
    } else if (option.id != null) {
      _openDetail(option.id!);
    } else {
      if (option.lat != null && option.lng != null) {
        _moveTo(option.lat!, option.lng!);
      }
      _showOption(option);
    }
  }

  void _showPlace(MapPlace place) {
    final places = context.read<PlaceController>();
    final category = places.categoryById(place.categoryId);
    setState(() => _selectedId = place.id);
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (sheetContext) => PlaceSummarySheet.place(
        place,
        categoryName: category?.name ?? '',
        categoryIcon: category?.icon ?? 'place',
        distanceText: formatMapDistance(places.distanceTo(place.lat, place.lng)),
        onOpenDetail: () {
          Navigator.pop(sheetContext);
          _openDetail(place.id);
        },
      ),
    ).whenComplete(() {
      if (mounted) {
        setState(() => _selectedId = null);
      }
    });
  }

  void _showOption(PlaceOption option) {
    final places = context.read<PlaceController>();
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (sheetContext) => PlaceSummarySheet.option(
        option,
        categoryIcon: places.categoryByName(option.category)?.icon ?? 'place',
        distanceText: formatMapDistance(places.distanceTo(option.lat, option.lng)),
        onOpenDetail: option.id == null
            ? null
            : () {
                Navigator.pop(sheetContext);
                _openDetail(option.id!);
              },
        onWriteFirst: option.id != null || option.externalId == null
            ? null
            : () {
                Navigator.pop(sheetContext);
                _writeFirst(option);
              },
      ),
    );
  }

  void _showEvent(MapFestival event) {
    final dates = [
      if (event.startDate != null) formatDate(event.startDate!),
      if (event.endDate != null && event.endDate != event.startDate) formatDate(event.endDate!),
    ].join(' – ');
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Chip(
                avatar: const Icon(Icons.celebration, size: 18),
                label: Text(event.whenLabel),
                visualDensity: VisualDensity.compact,
              ),
              Text(event.title, style: Theme.of(sheetContext).textTheme.titleLarge),
              const SizedBox(height: 4),
              Text([event.locationName, dates].where((s) => s.isNotEmpty).join(' · ')),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: () {
                  Navigator.pop(sheetContext);
                  Navigator.push(
                    context,
                    MaterialPageRoute<void>(builder: (_) => EventDetailScreen(eventId: event.id)),
                  );
                },
                icon: const Icon(Icons.arrow_forward),
                label: const Text('Xem sự kiện'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showLegend() {
    final scheme = Theme.of(context).colorScheme;
    Widget row(Widget mark, String text) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(width: 32, child: Center(child: mark)),
          const SizedBox(width: 8),
          Expanded(child: Text(text)),
        ],
      ),
    );
    Widget dot(Color color, {double size = 20, double radius = 10}) => Container(
      width: size,
      height: size,
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(radius)),
    );
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Chú thích'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              row(dot(scheme.primary, size: 24, radius: 12), 'Đã có review (tròn to, có số review)'),
              row(dot(scheme.primary, radius: 4), 'Ghim cộng đồng (vuông)'),
              row(dot(scheme.surfaceContainerHighest), 'Chưa có review (tròn, nhỏ)'),
              row(Icon(Icons.celebration, color: scheme.tertiary), 'Sự kiện (đèn lồng)'),
              row(
                Text(
                  '!',
                  style: TextStyle(color: scheme.error, fontWeight: FontWeight.bold),
                ),
                'Có cảnh báo lừa đảo',
              ),
              row(dot(scheme.outline), 'Đã đóng cửa'),
              const SizedBox(height: 8),
              const Text('Phóng to rồi chạm vào bất kỳ chỗ nào trên bản đồ để xem và review các địa điểm quanh đó.'),
            ],
          ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Đóng'))],
      ),
    );
  }

  // ---------------------------------------------------------------- mở màn hình khác

  Future<void> _openDetail(int placeId) async {
    await Navigator.push(context, MaterialPageRoute<void>(builder: (_) => PlaceDetailScreen(placeId: placeId)));
    if (mounted) {
      // Review vừa viết / sửa / xóa đổi số review và màu ghim
      context.read<PlaceController>().refreshMap();
    }
  }

  /// "Viết review đầu tiên" cho địa điểm OpenStreetMap: server thêm địa điểm khi lưu review.
  Future<void> _writeFirst(PlaceOption option) async {
    if (!await requireSignIn(context) || !mounted) {
      return;
    }
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => ReviewFormScreen(externalPlaceId: option.externalId, placeName: option.name),
      ),
    );
    if (saved != true || !mounted) {
      return;
    }
    final reviews = context.read<ReviewController>();
    final places = context.read<PlaceController>();
    showMessage(context, reviews.takeMessage());
    places.closePanel();
    await places.refreshMap();
    final placeId = reviews.savedPlaceId;
    if (placeId != null && mounted) {
      await _openDetail(placeId);
    }
  }
}

/// Ghim đèn lồng của sự kiện, nhãn "Còn N ngày" / "Đang diễn ra" bên dưới.
class _EventPin extends StatelessWidget {
  const _EventPin({super.key, required this.event, required this.onTap});

  final MapFestival event;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Semantics(
      label: 'Sự kiện: ${event.title}, ${event.whenLabel}',
      button: true,
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: scheme.tertiaryContainer,
                shape: BoxShape.circle,
                border: Border.all(color: scheme.tertiary, width: 2),
              ),
              child: Icon(Icons.celebration, size: 18, color: scheme.onTertiaryContainer),
            ),
            const SizedBox(height: 2),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
              decoration: BoxDecoration(color: scheme.tertiary, borderRadius: BorderRadius.circular(8)),
              child: Text(
                event.whenLabel,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: scheme.onTertiary, fontSize: 10, height: 1.3),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Ghim tạm (màu tối) của địa điểm OpenStreetMap trong kết quả tìm, chưa có trên Senpai ơi.
class _OsmPin extends StatelessWidget {
  const _OsmPin({super.key, required this.icon, required this.label, required this.onTap});

  final String? icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Semantics(
      label: label,
      button: true,
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Container(
          decoration: BoxDecoration(
            color: scheme.inverseSurface,
            shape: BoxShape.circle,
            border: Border.all(color: scheme.surface, width: 2),
          ),
          child: Icon(placeCategoryIcon(icon), size: 16, color: scheme.onInverseSurface),
        ),
      ),
    );
  }
}
