import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/map_place.dart';
import 'package:myasvsj/com.myasvsj.screen/place_category_icon.dart';

/// Ghim một địa điểm trên bản đồ, giống chú thích của web:
/// - sáng (tròn to, có số review): đã có review, đang hoạt động, chưa đóng cửa;
/// - mờ (tròn nhỏ): chưa có review;
/// - vuông: ghim cộng đồng; viền đứt: ghim của mình chờ duyệt; xám: đã đóng cửa;
/// - dấu "!" đỏ: có bài cảnh báo lừa đảo.
class MapPin extends StatelessWidget {
  const MapPin({super.key, required this.place, required this.icon, this.selected = false, this.onTap});

  /// Kích thước khung của ghim sáng và ghim mờ (Marker của bản đồ dùng cỡ này).
  static const double litSize = 44;
  static const double dimSize = 34;

  final MapPlace place;

  /// Tên biểu tượng của danh mục (Material Symbols).
  final String icon;
  final bool selected;
  final VoidCallback? onTap;

  /// Câu đọc cho trình đọc màn hình, giống `pinLabel` của web.
  String get label => [
    place.name,
    if (place.reviewCount > 0) '${place.reviewCount} review' else 'chưa có review',
    if (place.closed) 'đã đóng cửa',
    if (place.scam) 'có cảnh báo lừa đảo',
    if (place.isPending) 'chờ Moderator duyệt',
  ].join(', ');

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final lit = place.isLit;
    final size = (lit ? litSize : dimSize) - 4;
    final Color background;
    final Color foreground;
    if (place.closed) {
      background = scheme.outline;
      foreground = scheme.surface;
    } else if (lit) {
      background = scheme.primary;
      foreground = scheme.onPrimary;
    } else {
      background = scheme.surfaceContainerHighest;
      foreground = scheme.primary;
    }
    final shape = place.isCommunity ? BorderRadius.circular(8) : BorderRadius.circular(size);
    final body = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: place.isPending ? background.withValues(alpha: 0.6) : background,
        borderRadius: shape,
        border: Border.all(
          color: selected ? scheme.tertiary : (place.isPending ? scheme.tertiary : scheme.surface),
          width: selected || place.isPending ? 3 : 2,
        ),
        boxShadow: [BoxShadow(color: scheme.shadow.withValues(alpha: 0.25), blurRadius: 3, offset: const Offset(0, 1))],
      ),
      child: Icon(placeCategoryIcon(icon), size: lit ? 20 : 16, color: foreground),
    );
    return Semantics(
      label: label,
      button: true,
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: SizedBox(
          width: lit ? litSize : dimSize,
          height: lit ? litSize : dimSize,
          child: Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.center,
            children: [
              body,
              if (lit)
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: _Badge(text: '${place.reviewCount}', color: scheme.surface, textColor: scheme.primary),
                ),
              if (place.scam)
                Positioned(
                  right: 0,
                  top: 0,
                  child: _Badge(text: '!', color: scheme.error, textColor: scheme.onError),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Số nhỏ ở góc ghim (số review, dấu "!").
class _Badge extends StatelessWidget {
  const _Badge({required this.text, required this.color, required this.textColor});

  final String text;
  final Color color;
  final Color textColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
      padding: const EdgeInsets.symmetric(horizontal: 3),
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(8)),
      alignment: Alignment.center,
      child: Text(
        text,
        style: TextStyle(color: textColor, fontSize: 10, fontWeight: FontWeight.bold, height: 1.2),
      ),
    );
  }
}
