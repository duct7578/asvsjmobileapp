import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/event_controller.dart';
import 'package:myasvsj/com.myasvsj.model/event.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/empty_view.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/event_card.dart';
import 'package:myasvsj/com.myasvsj.screen/event_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/event_review_form_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// Danh sách "Lễ hội và sự kiện" (`GET /api/events?q=`), nhóm như web: Đang diễn ra, Trong 30 ngày tới, Sau này,
/// Đã diễn ra. Gõ để tìm theo tên, nơi tổ chức hoặc chi phí. Server trả cả danh sách nên không có "Tải thêm".
class EventListScreen extends StatefulWidget {
  const EventListScreen({super.key});

  @override
  State<EventListScreen> createState() => _EventListScreenState();
}

class _EventListScreenState extends State<EventListScreen> {
  /// Chờ người dùng ngừng gõ một chút rồi mới tìm (như web).
  static const Duration _searchDelay = Duration(milliseconds: 250);

  final _search = TextEditingController();
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<EventController>().loadEvents(q: ''));
  }

  @override
  void dispose() {
    _timer?.cancel();
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final events = context.watch<EventController>();
    return Scaffold(
      appBar: AppBar(title: const Text('Lễ hội và sự kiện')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: TextField(
              controller: _search,
              maxLength: 100,
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: 'Tìm sự kiện hoặc nơi tổ chức',
                prefixIcon: const Icon(Icons.search),
                counterText: '',
                isDense: true,
                border: const OutlineInputBorder(),
                suffixIcon: _search.text.isEmpty
                    ? null
                    : IconButton(tooltip: 'Xóa từ khóa', icon: const Icon(Icons.clear), onPressed: _clear),
              ),
              onChanged: _onChanged,
              onSubmitted: (text) {
                _timer?.cancel();
                events.loadEvents(q: text);
              },
            ),
          ),
          Expanded(child: _body(events)),
        ],
      ),
    );
  }

  Widget _body(EventController events) {
    if (events.isLoading && events.events.isEmpty) {
      return const LoadingView();
    }
    if (events.error != null) {
      return ErrorView(message: events.error!, onRetry: events.loadEvents);
    }
    final sections = <(String, List<Event>)>[
      ('Đang diễn ra', events.nowEvents),
      ('Trong 30 ngày tới', events.soonEvents),
      ('Sau này', events.laterEvents),
      ('Đã diễn ra (vẫn viết review được)', events.pastEvents),
    ];
    final theme = Theme.of(context);
    return RefreshIndicator(
      onRefresh: events.loadEvents,
      child: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
            child: Text(
              'Do Moderator đăng. Sự kiện đang hoặc sắp diễn ra cũng hiện trên bản đồ. '
              'Ai đã đi có thể viết review và đăng ảnh cho năm đó.',
              style: theme.textTheme.bodySmall,
            ),
          ),
          if (events.events.isEmpty)
            EmptyView(
              text: events.query.isEmpty ? 'Chưa có sự kiện nào.' : 'Không có sự kiện nào khớp.',
              icon: Icons.festival_outlined,
            ),
          for (final (title, list) in sections)
            if (list.isNotEmpty) ...[
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
                child: Text('$title (${list.length})', style: theme.textTheme.titleMedium),
              ),
              for (final event in list)
                EventCard(
                  event: event,
                  onTap: () => _openDetail(event.id),
                  onWriteReview: () => _writeReview(event.id),
                ),
            ],
        ],
      ),
    );
  }

  void _onChanged(String text) {
    setState(() {}); // vẽ lại nút xóa từ khóa
    _timer?.cancel();
    _timer = Timer(_searchDelay, () => context.read<EventController>().loadEvents(q: text));
  }

  void _clear() {
    _timer?.cancel();
    _search.clear();
    setState(() {});
    context.read<EventController>().loadEvents(q: '');
  }

  Future<void> _openDetail(int eventId) =>
      Navigator.push(context, MaterialPageRoute<void>(builder: (_) => EventDetailScreen(eventId: eventId)));

  /// Viết review cần tài khoản User: khách được đưa sang đăng nhập trước.
  Future<void> _writeReview(int eventId) async {
    if (!await requireSignIn(context) || !mounted) {
      return;
    }
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => EventReviewFormScreen(eventId: eventId)),
    );
    if (saved == true && mounted) {
      showMessage(context, context.read<EventController>().takeMessage());
    }
  }
}
