import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/saved_controller.dart';
import 'package:myasvsj/com.myasvsj.model/saved_blog.dart';
import 'package:myasvsj/com.myasvsj.model/saved_guide.dart';
import 'package:myasvsj/com.myasvsj.model/saved_item.dart';
import 'package:myasvsj/com.myasvsj.model/saved_kind.dart';
import 'package:myasvsj/com.myasvsj.model/saved_place.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';
import 'package:myasvsj/com.myasvsj.screen/empty_view.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/guide_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/place_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/profile_sign_in_prompt.dart';
import 'package:myasvsj/com.myasvsj.screen/profile_user_watcher.dart';
import 'package:myasvsj/com.myasvsj.screen/question_detail_screen.dart';

/// "Đã lưu": địa điểm, bài viết, câu hỏi và cẩm nang đã lưu, mỗi loại một tab, mới lưu trước.
/// Bấm một mục để mở; "Bỏ lưu" gỡ mục ngay (lỗi thì mục quay lại) và cho "Hoàn tác".
class SavedScreen extends StatefulWidget {
  const SavedScreen({super.key});

  @override
  State<SavedScreen> createState() => _SavedScreenState();
}

class _SavedScreenState extends State<SavedScreen> with ProfileUserWatcher {
  /// Tên tab, biểu tượng và câu "chưa có" của từng loại, như trang web.
  static const _titles = {
    SavedKind.place: 'Địa điểm',
    SavedKind.post: 'Bài viết',
    SavedKind.question: 'Câu hỏi',
    SavedKind.guide: 'Cẩm nang',
  };
  static const _icons = {
    SavedKind.place: Icons.location_on_outlined,
    SavedKind.post: Icons.article_outlined,
    SavedKind.question: Icons.contact_support_outlined,
    SavedKind.guide: Icons.menu_book_outlined,
  };
  static const _empty = {
    SavedKind.place: 'Chưa lưu địa điểm nào.',
    SavedKind.post: 'Chưa lưu bài nào.',
    SavedKind.question: 'Chưa lưu câu hỏi nào.',
    SavedKind.guide: 'Chưa lưu cẩm nang nào.',
  };

  /// Biểu tượng loại địa điểm (tên Material Symbols trong bảng `place_categories`).
  static const _placeIcons = {
    'local_convenience_store': Icons.local_convenience_store,
    'restaurant': Icons.restaurant,
    'train': Icons.train,
    'shopping_cart': Icons.shopping_cart,
    'account_balance': Icons.account_balance,
    'local_hospital': Icons.local_hospital,
    'local_post_office': Icons.local_post_office,
    'local_pharmacy': Icons.local_pharmacy,
    'school': Icons.school,
    'local_laundry_service': Icons.local_laundry_service,
    'park': Icons.park,
    'temple_buddhist': Icons.temple_buddhist,
    'smartphone': Icons.smartphone,
    'home_work': Icons.home_work,
  };

  @override
  void onUserChanged(int? userId) {
    final saved = context.read<SavedController>();
    // Bỏ danh sách cũ (có thể của người khác) rồi tải của người đang đăng nhập
    saved.clear();
    if (userId != null) {
      saved.load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthController>().currentUser;
    watchUser(user?.id);
    final saved = context.watch<SavedController>();
    return DefaultTabController(
      length: SavedKind.values.length,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Đã lưu'),
          bottom: user == null
              ? null
              : TabBar(
                  isScrollable: true,
                  tabAlignment: TabAlignment.start,
                  tabs: [
                    for (final kind in SavedKind.values)
                      Tab(
                        text: saved.saved.countOf(kind) == 0
                            ? _titles[kind]
                            : '${_titles[kind]} (${saved.saved.countOf(kind)})',
                      ),
                  ],
                ),
        ),
        body: user == null
            ? const ProfileSignInPrompt(text: 'Đăng nhập để xem địa điểm, bài viết, câu hỏi và cẩm nang bạn đã lưu.')
            : _body(saved),
      ),
    );
  }

  Widget _body(SavedController saved) {
    if (!saved.isLoaded) {
      if (saved.error != null && !saved.isLoading) {
        return ErrorView(message: saved.error!, onRetry: saved.load);
      }
      return const LoadingView();
    }
    return TabBarView(
      children: [
        for (final kind in SavedKind.values)
          RefreshIndicator(
            onRefresh: saved.load,
            child: saved.saved.countOf(kind) == 0
                ? ListView(
                    children: [EmptyView(text: _empty[kind]!, icon: _icons[kind]!)],
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    itemCount: saved.saved.countOf(kind),
                    itemBuilder: (_, i) => _item(saved.saved.itemsOf(kind)[i]),
                  ),
          ),
      ],
    );
  }

  Widget _item(SavedItem item) => switch (item) {
    SavedPlace place => _placeTile(place),
    SavedBlog blog => _blogCard(blog),
    SavedGuide guide => _guideCard(guide),
    _ => const SizedBox.shrink(),
  };

  Widget _unsaveButton(SavedItem item) => TextButton.icon(
    onPressed: () => _unsave(item),
    icon: const Icon(Icons.bookmark_remove_outlined),
    label: const Text('Bỏ lưu'),
  );

  Widget _placeTile(SavedPlace place) {
    final theme = Theme.of(context);
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: InkWell(
        onTap: () => _open(PlaceDetailScreen(placeId: place.id)),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 4, 4),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(child: Icon(_placeIcons[place.icon] ?? Icons.place)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(place.name, style: theme.textTheme.titleMedium, maxLines: 2, overflow: TextOverflow.ellipsis),
                    Text(
                      [
                        place.categoryName,
                        if (place.address != null && place.address!.isNotEmpty) place.address,
                      ].join(' · '),
                      style: theme.textTheme.bodySmall,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: place.closed ? _badge('Đã đóng cửa', warn: true) : null,
                          ),
                        ),
                        _unsaveButton(place),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _blogCard(SavedBlog blog) {
    final theme = Theme.of(context);
    final created = blog.createdAt;
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: InkWell(
        onTap: () =>
            _open(blog.isQuestion ? QuestionDetailScreen(questionId: blog.id) : BlogDetailScreen(blogId: blog.id)),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 4, 4),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(
                spacing: 6,
                runSpacing: 4,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  if (blog.topics.isNotEmpty) _badge(blog.topics.first.name),
                  if (blog.isQuestion && blog.solved) _badge('Đã giải quyết', ok: true),
                  if (created != null) Text(formatTimeAgo(created), style: theme.textTheme.bodySmall),
                ],
              ),
              const SizedBox(height: 6),
              Text(blog.title, style: theme.textTheme.titleMedium, maxLines: 2, overflow: TextOverflow.ellipsis),
              Row(
                children: [
                  Flexible(
                    child: Text(
                      blog.authorName,
                      style: theme.textTheme.bodySmall,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Icon(Icons.favorite_border, size: 16, semanticLabel: 'Lượt thích', color: theme.colorScheme.outline),
                  Text(' ${blog.likeCount}', style: theme.textTheme.bodySmall),
                  const SizedBox(width: 8),
                  Icon(
                    Icons.chat_bubble_outline,
                    size: 16,
                    semanticLabel: blog.isQuestion ? 'Trả lời' : 'Bình luận',
                    color: theme.colorScheme.outline,
                  ),
                  Text(' ${blog.commentCount}', style: theme.textTheme.bodySmall),
                  const Spacer(),
                  _unsaveButton(blog),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _guideCard(SavedGuide guide) {
    final theme = Theme.of(context);
    final saved = guide.savedAt;
    final summary = guide.summary;
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: InkWell(
        onTap: () => _open(GuideDetailScreen(guideId: guide.id)),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 4, 4),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(
                spacing: 6,
                runSpacing: 4,
                children: [
                  if (guide.stageName.isNotEmpty) _badge(guide.stageName),
                  if (guide.topicName.isNotEmpty && guide.topicName != guide.stageName) _badge(guide.topicName),
                ],
              ),
              const SizedBox(height: 6),
              Text(guide.title, style: theme.textTheme.titleMedium, maxLines: 2, overflow: TextOverflow.ellipsis),
              if (summary != null && summary.isNotEmpty)
                Text(summary, style: theme.textTheme.bodySmall, maxLines: 3, overflow: TextOverflow.ellipsis),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      saved == null ? '' : 'Đã lưu: ${formatTimeAgo(saved)}',
                      style: theme.textTheme.bodySmall,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  _unsaveButton(guide),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _badge(String text, {bool ok = false, bool warn = false}) {
    final scheme = Theme.of(context).colorScheme;
    final background = warn ? scheme.errorContainer : (ok ? scheme.primaryContainer : scheme.secondaryContainer);
    final foreground = warn ? scheme.onErrorContainer : (ok ? scheme.onPrimaryContainer : scheme.onSecondaryContainer);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(color: background, borderRadius: BorderRadius.circular(999)),
      child: Text(
        text,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: Theme.of(context).textTheme.labelMedium?.copyWith(color: foreground),
      ),
    );
  }

  /// Mở màn chi tiết; quay về thì tải lại, vì người dùng có thể đã bỏ lưu ở đó.
  Future<void> _open(Widget screen) async {
    await Navigator.push(context, MaterialPageRoute<void>(builder: (_) => screen));
    if (mounted && context.read<AuthController>().isSignedIn) {
      await context.read<SavedController>().load();
    }
  }

  Future<void> _unsave(SavedItem item) async {
    final saved = context.read<SavedController>();
    final messenger = ScaffoldMessenger.of(context);
    final removed = await saved.unsave(item);
    final text = saved.takeMessage();
    if (text == null) {
      return;
    }
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(text),
          // Có nút thì SnackBar mặc định không tự tắt; ở đây vẫn cho tự tắt sau vài giây
          persist: false,
          action: removed ? SnackBarAction(label: 'Hoàn tác', onPressed: () => _undo(saved, messenger)) : null,
        ),
      );
  }

  /// Gọi được cả khi màn hình đã đóng, nên chỉ dùng Controller và ScaffoldMessenger đã lấy sẵn.
  static Future<void> _undo(SavedController saved, ScaffoldMessengerState messenger) async {
    await saved.undoUnsave();
    final text = saved.takeMessage();
    if (text != null) {
      messenger
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(text)));
    }
  }
}
