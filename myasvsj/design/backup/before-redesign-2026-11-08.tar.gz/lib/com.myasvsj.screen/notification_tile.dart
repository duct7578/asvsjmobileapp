import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/app_notification.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';

/// Một dòng của màn hình "Thông báo": biểu tượng theo loại, nội dung (in đậm khi chưa đọc), thời gian, chấm chưa đọc.
class NotificationTile extends StatelessWidget {
  const NotificationTile({super.key, required this.notification, this.onTap});

  final AppNotification notification;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final n = notification;
    final (icon, color) = _look(n.type, scheme);
    return ListTile(
      onTap: onTap,
      tileColor: n.read ? null : scheme.primaryContainer.withValues(alpha: 0.25),
      leading: CircleAvatar(backgroundColor: color.withValues(alpha: 0.15), foregroundColor: color, child: Icon(icon)),
      title: Text(
        n.content,
        maxLines: 4,
        overflow: TextOverflow.ellipsis,
        style: n.read ? null : const TextStyle(fontWeight: FontWeight.bold),
      ),
      subtitle: n.createdAt == null ? null : Text(formatTimeAgo(n.createdAt!)),
      trailing: n.read
          ? null
          : Semantics(
              label: 'Chưa đọc',
              child: Icon(Icons.circle, size: 10, color: scheme.primary),
            ),
    );
  }

  /// Biểu tượng và màu của từng loại thông báo (như KINDS của trang web).
  static (IconData, Color) _look(String type, ColorScheme scheme) => switch (type) {
    'CONTENT_PUBLISHED' => (Icons.check_circle_outline, scheme.primary),
    'CONTENT_REJECTED' => (Icons.block, scheme.error),
    'NEW_COMMENT' => (Icons.chat_bubble_outline, scheme.secondary),
    'BEST_ANSWER' => (Icons.workspace_premium_outlined, scheme.tertiary),
    _ when type.startsWith('TAG_') => (Icons.sell_outlined, scheme.primary),
    _ when type.startsWith('PIN_') || type.startsWith('PLACE_') => (Icons.place_outlined, scheme.secondary),
    _ => (Icons.notifications_none, scheme.primary),
  };
}
