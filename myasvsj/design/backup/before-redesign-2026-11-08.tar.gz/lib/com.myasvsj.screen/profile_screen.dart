import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/profile_controller.dart';
import 'package:myasvsj/com.myasvsj.model/profile_rank.dart';
import 'package:myasvsj/com.myasvsj.model/profile_stage.dart';
import 'package:myasvsj/com.myasvsj.model/user_profile.dart';
import 'package:myasvsj/com.myasvsj.screen/area_stage_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/change_password_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';
import 'package:myasvsj/com.myasvsj.screen/delete_account_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/interest_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/media_image.dart';
import 'package:myasvsj/com.myasvsj.screen/my_guides_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/point_history_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/profile_sign_in_prompt.dart';
import 'package:myasvsj/com.myasvsj.screen/profile_tag_chip.dart';
import 'package:myasvsj/com.myasvsj.screen/profile_user_watcher.dart';
import 'package:myasvsj/com.myasvsj.screen/saved_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/tag_request_screen.dart';

/// Trang "Tôi": tên, tag, điểm và cấp bậc, hạn mức tài khoản mới, khu vực và giai đoạn, chủ đề quan tâm,
/// Đã lưu, và các việc với tài khoản (đổi mật khẩu, đăng xuất, xóa tài khoản). Khách thấy lời mời đăng nhập.
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> with ProfileUserWatcher {
  /// Cách đăng nhập theo nhà cung cấp đã liên kết, như trang web.
  static const _providerNames = {'GOOGLE': 'Google', 'FACEBOOK': 'Facebook'};

  @override
  void onUserChanged(int? userId) {
    final profiles = context.read<ProfileController>();
    if (userId == null) {
      profiles.clear();
    } else {
      profiles.loadProfile();
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthController>().currentUser;
    watchUser(user?.id);
    final profiles = context.watch<ProfileController>();
    return Scaffold(
      appBar: AppBar(title: const Text('Tôi')),
      body: user == null
          ? const ProfileSignInPrompt(text: 'Đăng nhập để xem điểm, khu vực, mục đã lưu và quản lý tài khoản.')
          : _body(profiles, user.id),
    );
  }

  Widget _body(ProfileController profiles, int userId) {
    final profile = profiles.profile;
    // Hồ sơ của người khác (vừa đổi tài khoản) không bao giờ được hiện
    if (profile == null || profile.id != userId) {
      if (profiles.error != null && !profiles.isLoading) {
        return ErrorView(message: profiles.error!, onRetry: profiles.loadProfile);
      }
      return const LoadingView();
    }
    return RefreshIndicator(
      onRefresh: profiles.loadProfile,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
        children: [
          if (profiles.error != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Text(profiles.error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ),
          _header(profile),
          const SizedBox(height: 16),
          _pointsCard(profile),
          if (profile.newAccount) _newAccountCard(profile),
          const SizedBox(height: 8),
          _menu(profiles, profile),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------- Tên, tag, cách đăng nhập

  Widget _header(UserProfile profile) {
    final theme = Theme.of(context);
    final methods = [
      if (profile.hasPassword) 'Email và mật khẩu',
      for (final p in profile.linkedProviders) _providerNames[p] ?? p,
    ];
    final avatarUrl = profile.avatarUrl;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CircleAvatar(
          radius: 28,
          child: avatarUrl == null || avatarUrl.isEmpty
              ? Text(
                  profile.displayName.isEmpty ? '?' : profile.displayName.characters.first.toUpperCase(),
                  style: theme.textTheme.titleLarge,
                )
              : MediaImage(url: avatarUrl, width: 56, height: 56, radius: 28),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                profile.displayName,
                style: theme.textTheme.titleLarge,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (final tag in profile.tags) ProfileTagChip(name: tag.name, color: tag.color),
                  if (profile.tags.isEmpty) Text('Chưa có tag định danh', style: theme.textTheme.bodySmall),
                  if (!profile.isMember) _badge(profile.roleLabel),
                  if (profile.reportMutedUntil != null)
                    _badge('Bị khóa báo cáo đến ${formatDate(profile.reportMutedUntil!)}', error: true),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                '${profile.email}${methods.isEmpty ? '' : ' · Đăng nhập bằng: ${methods.join(', ')}'}',
                style: theme.textTheme.bodySmall,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _badge(String text, {bool error = false}) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: error ? scheme.errorContainer : scheme.secondaryContainer,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        style: Theme.of(
          context,
        ).textTheme.labelMedium?.copyWith(color: error ? scheme.onErrorContainer : scheme.onSecondaryContainer),
      ),
    );
  }

  // ---------------------------------------------------------------- Điểm và cấp bậc

  Widget _pointsCard(UserProfile profile) {
    final theme = Theme.of(context);
    final current = profile.currentRank;
    final next = profile.nextRank;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 8,
              runSpacing: 4,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                Text('${profile.points} điểm', style: theme.textTheme.titleLarge),
                if (current != null)
                  Chip(
                    avatar: const Icon(Icons.military_tech, size: 18),
                    label: Text(current.name),
                    visualDensity: VisualDensity.compact,
                  ),
              ],
            ),
            Text(
              next == null ? 'Hạng cao nhất' : 'Còn ${profile.pointsToNextRank} điểm nữa lên ${next.name}',
              style: theme.textTheme.bodySmall,
            ),
            const SizedBox(height: 8),
            LinearProgressIndicator(value: profile.rankProgress, semanticsLabel: 'Tiến độ lên cấp'),
            const SizedBox(height: 12),
            for (var i = 0; i < profile.ranks.length; i++) _rank(profile.ranks[i], reached: i <= profile.rankIndex),
            const SizedBox(height: 8),
            Text(
              'Review +10 · Ghim được duyệt +15 · Câu trả lời hay nhất +5 · Bài bị gỡ −20 · '
              'Tự xóa bài thì điểm của bài đó được thu lại',
              style: theme.textTheme.bodySmall,
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () => _open(const PointHistoryScreen(), reload: false),
              icon: const Icon(Icons.history),
              label: const Text('Lịch sử điểm'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _rank(ProfileRank rank, {required bool reached}) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 8,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              Text(rank.name, style: theme.textTheme.titleSmall),
              Text('từ ${rank.minPoints} điểm', style: theme.textTheme.bodySmall),
              if (reached)
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.check, size: 16, color: theme.colorScheme.primary),
                    Text('Đã đạt', style: theme.textTheme.labelMedium?.copyWith(color: theme.colorScheme.primary)),
                  ],
                ),
            ],
          ),
          for (final perk in rank.perks) Text('• $perk', style: theme.textTheme.bodySmall),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------- Tài khoản mới

  Widget _newAccountCard(UserProfile profile) {
    final theme = Theme.of(context);
    final today = profile.today;
    final age = profile.accountAgeDays == 0 ? 'hôm nay' : '${profile.accountAgeDays} ngày trước';
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 8,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                Text('Tài khoản mới', style: theme.textTheme.titleMedium),
                _badge('Tạo $age'),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              'Trong ${profile.newAccountDays} ngày đầu, mỗi ngày bạn đăng được tối đa ${today.maxPosts} bài viết '
              'hoặc review, ${today.maxPins} ghim mới và ${today.maxVideos} video. Giới hạn này giúp chống spam.',
              style: theme.textTheme.bodySmall,
            ),
            const SizedBox(height: 4),
            Text(
              'Hôm nay: ${today.posts}/${today.maxPosts} bài viết và review · ${today.pins}/${today.maxPins} ghim · '
              '${today.videos}/${today.maxVideos} video',
              style: theme.textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------- Các mục

  Widget _menu(ProfileController profiles, UserProfile profile) {
    final stage = ProfileStage.labelOf(profile.stage);
    final interests = profiles.chosenInterests.map((t) => t.name).join(', ');
    final error = Theme.of(context).colorScheme.error;
    return Column(
      children: [
        if (profile.pendingTag != null)
          _tile(
            Icons.hourglass_top,
            'Yêu cầu tag ${profile.pendingTag} đang chờ duyệt',
            'Ảnh minh chứng tự xóa sau 14 ngày nếu chưa được duyệt.',
            () => _open(const TagRequestScreen()),
          )
        else
          _tile(Icons.verified_outlined, 'Xin tag định danh', null, () => _open(const TagRequestScreen())),
        _tile(
          Icons.person_pin_circle_outlined,
          'Khu vực và giai đoạn',
          '${stage ?? 'Chưa chọn giai đoạn'} · ${profile.areaName ?? 'Chưa chọn khu vực'}',
          () => _open(const AreaStageScreen()),
        ),
        if (profile.isMember) ...[
          _tile(
            Icons.interests_outlined,
            'Chủ đề quan tâm',
            interests.isEmpty ? 'Chưa chọn' : interests,
            () => _open(const InterestScreen()),
          ),
          _tile(Icons.menu_book_outlined, 'Cẩm nang của tôi', null, () => _open(const MyGuidesScreen())),
        ],
        _tile(Icons.bookmarks_outlined, 'Đã lưu (${profile.savedCount})', null, () => _open(const SavedScreen())),
        const Divider(),
        _tile(
          Icons.password,
          profile.hasPassword ? 'Đổi mật khẩu' : 'Tạo mật khẩu',
          null,
          () => _open(const ChangePasswordScreen()),
        ),
        _tile(Icons.logout, 'Đăng xuất', null, _logout),
        ListTile(
          leading: Icon(Icons.delete_outline, color: error),
          title: Text('Xóa tài khoản', style: TextStyle(color: error)),
          onTap: () => _open(const DeleteAccountScreen()),
        ),
      ],
    );
  }

  Widget _tile(IconData icon, String title, String? subtitle, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      subtitle: subtitle == null ? null : Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis),
      trailing: const Icon(Icons.chevron_right),
      onTap: onTap,
    );
  }

  /// Mở một màn hình; quay về thì tải lại hồ sơ (điểm, khu vực, tag, số mục đã lưu có thể đã đổi).
  Future<void> _open(Widget screen, {bool reload = true}) async {
    await Navigator.push(context, MaterialPageRoute<void>(builder: (_) => screen));
    if (reload && mounted && context.read<AuthController>().isSignedIn) {
      await context.read<ProfileController>().loadProfile();
    }
  }

  Future<void> _logout() async {
    final navigator = Navigator.of(context);
    final auth = context.read<AuthController>();
    context.read<ProfileController>().clear();
    await auth.logout();
    navigator.popUntil((route) => route.isFirst);
  }
}
