import 'package:flutter/material.dart';

/// Một dòng thông tin có biểu tượng (ngày, nơi tổ chức, chi phí), cắt bớt khi quá dài.
class EventInfoLine extends StatelessWidget {
  const EventInfoLine({super.key, required this.icon, required this.text, this.maxLines = 1});

  final IconData icon;
  final String text;
  final int maxLines;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 16, color: theme.colorScheme.onSurfaceVariant),
          const SizedBox(width: 6),
          Expanded(
            child: Text(text, style: theme.textTheme.bodyMedium, maxLines: maxLines, overflow: TextOverflow.ellipsis),
          ),
        ],
      ),
    );
  }
}
