import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/chat_controller.dart';
import 'package:myasvsj/com.myasvsj.model/chat_conversation.dart';
import 'package:myasvsj/com.myasvsj.model/chat_message.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/chat_avatar.dart';
import 'package:myasvsj/com.myasvsj.screen/chat_bubble.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';
import 'package:myasvsj/com.myasvsj.screen/empty_view.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/report_dialog.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// Một cuộc trò chuyện (trang `/messages/{id}` và `/messages?to={userId}` của web): tin nhắn văn bản, lời mời
/// (Chấp nhận / Từ chối / Chặn), "Đã xem", "đang soạn tin", sửa / thu hồi / báo cáo tin, chặn / bỏ chặn, xóa
/// cuộc trò chuyện. Hội thoại đã mã hóa đầu cuối trên web: hiện thông báo và khóa ô soạn tin.
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, this.conversationId, this.withUserId, this.title = 'Tin nhắn'});

  /// Mở hội thoại đã có [conversationId], hoặc nhắn cho người dùng [withUserId] (từ bài viết, bình luận).
  final int? conversationId;
  final int? withUserId;
  final String title;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  static const String _safety =
      'Senpai ơi không bao giờ hỏi mật khẩu hay mã OTP. Đừng gửi ảnh thẻ cư trú, hộ '
      'chiếu, số tài khoản hay chuyển tiền cho người bạn chưa gặp. Thấy đáng ngờ, hãy nhấn giữ tin nhắn đó rồi chọn '
      'Báo cáo.';

  final _text = TextEditingController();
  late final ChatController _chat;
  int? _openedFor;
  bool _wasVisible = true;

  @override
  void initState() {
    super.initState();
    _chat = context.read<ChatController>();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Quay lại màn hình này sau khi một màn hình khác che kín nó (bấm thông báo tin nhắn khác, mở trang khác):
    // tải lại vì cuộc trò chuyện đang mở có thể đã đổi. Hộp thoại, bảng chọn không che kín nên không tải lại.
    final visible = TickerMode.valuesOf(context).enabled;
    if (visible && !_wasVisible && _openedFor != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _open());
    }
    _wasVisible = visible;
  }

  @override
  void dispose() {
    _chat.closeRoom(this);
    _text.dispose();
    super.dispose();
  }

  void _open() {
    if (mounted) {
      _chat.openRoom(conversationId: widget.conversationId, withUserId: widget.withUserId, owner: this);
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    final chat = context.watch<ChatController>();
    final userId = auth.currentUser?.id;
    if (userId != null && userId != _openedFor) {
      _openedFor = userId;
      WidgetsBinding.instance.addPostFrameCallback((_) => _open());
    }
    // Chỉ hiện cuộc trò chuyện màn hình này đã mở (một ChatScreen khác có thể đang mở chồng lên)
    final mine = auth.isSignedIn && chat.ownsRoom(this);
    final room = mine ? chat.room : null;
    return Scaffold(
      appBar: AppBar(titleSpacing: 0, title: _title(chat, room), actions: [if (room != null) _menu(room)]),
      body: !auth.isSignedIn ? _guest() : _body(chat, room),
    );
  }

  Widget _title(ChatController chat, ChatConversation? room) {
    final name = room?.peer.displayName ?? widget.title;
    final tags = room?.peer.tags.map((t) => t.name).join(' · ') ?? '';
    final subtitle = room != null && chat.peerTyping ? 'đang soạn tin…' : tags;
    return Row(
      children: [
        if (room != null) ...[
          ChatAvatar(name: room.peer.displayName, url: room.peer.avatarUrl, radius: 18),
          const SizedBox(width: 10),
        ],
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
              if (subtitle.isNotEmpty)
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _menu(ChatConversation room) {
    final status = room.status;
    return PopupMenuButton<String>(
      tooltip: 'Tùy chọn',
      onSelected: (action) => switch (action) {
        'block' => _block(room),
        'unblock' => _unblock(),
        _ => _delete(room),
      },
      itemBuilder: (_) => [
        if (status.noticeCode != 'DELETED')
          status.blockedByMe
              ? const PopupMenuItem(value: 'unblock', child: Text('Bỏ chặn'))
              : const PopupMenuItem(value: 'block', child: Text('Chặn')),
        if (room.id != null) const PopupMenuItem(value: 'delete', child: Text('Xóa cuộc trò chuyện')),
      ],
    );
  }

  Widget _guest() => Center(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const EmptyView(text: 'Đăng nhập để nhắn tin với thành viên khác.', icon: Icons.forum_outlined),
        FilledButton(onPressed: () => requireSignIn(context), child: const Text('Đăng nhập')),
      ],
    ),
  );

  Widget _body(ChatController chat, ChatConversation? room) {
    if (room == null) {
      if (chat.roomError != null && chat.ownsRoom(this)) {
        return ErrorView(message: chat.roomError!, onRetry: _open);
      }
      return const LoadingView();
    }
    return Column(
      children: [
        Expanded(child: _thread(chat, room)),
        if (chat.peerTyping)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                '${room.peer.displayName} đang soạn tin…',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(fontStyle: FontStyle.italic),
              ),
            ),
          ),
        if (room.status.noticeCode != null) _notice(room),
        if (room.status.isEncrypted && chat.editing == null) _encrypted() else _composer(chat, room),
      ],
    );
  }

  // ---------------------------------------------------------------- Tin nhắn

  Widget _thread(ChatController chat, ChatConversation room) {
    final rows = <Widget>[
      _SafetyNote(text: _safety),
      if (room.hasOlder)
        Center(
          child: TextButton(
            onPressed: chat.isLoadingOlder ? null : _loadOlder,
            child: Text(chat.isLoadingOlder ? 'Đang tải…' : 'Xem tin cũ hơn'),
          ),
        ),
    ];
    DateTime? day;
    final byId = {for (final m in room.messages) m.id: m};
    for (final m in room.messages) {
      final date = DateUtils.dateOnly(m.createdAt);
      if (date != day) {
        day = date;
        rows.add(_DayLabel(text: _dayText(date)));
      }
      final quoted = m.replyToId == null ? null : byId[m.replyToId];
      rows.add(
        ChatBubble(
          key: ValueKey('msg-${m.id}'),
          message: m,
          quoted: quoted,
          quotedName: quoted == null ? '' : (quoted.mine ? 'Bạn' : room.peer.displayName),
          delivery: chat.deliveryOf(m),
          onLongPress: () => _actions(chat, room, m),
        ),
      );
    }
    // Danh sách lật ngược: mở ra đã ở tin mới nhất, tin mới đến thì hiện ngay ở cuối
    return ListView.builder(
      reverse: true,
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: rows.length,
      itemBuilder: (_, i) => rows[rows.length - 1 - i],
    );
  }

  String _dayText(DateTime date) {
    final today = DateUtils.dateOnly(DateTime.now());
    if (date == today) {
      return 'Hôm nay';
    }
    if (date == today.subtract(const Duration(days: 1))) {
      return 'Hôm qua';
    }
    return formatDate(date);
  }

  Future<void> _loadOlder() async {
    await _chat.loadOlder();
    if (mounted) {
      showMessage(context, _chat.takeMessage());
    }
  }

  /// Nhấn giữ một tin: Sao chép, Sửa, Thu hồi, Báo cáo (chỉ những gì làm được lúc này).
  Future<void> _actions(ChatController chat, ChatConversation room, ChatMessage m) async {
    final canCopy = !m.recalled && (m.content ?? '').isNotEmpty;
    final canEdit = chat.canEdit(m);
    final canRecall = chat.canRecall(m);
    final canReport = chat.canReport(m);
    if (!canCopy && !canEdit && !canRecall && !canReport) {
      return;
    }
    final action = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (canCopy)
              ListTile(
                leading: const Icon(Icons.content_copy),
                title: const Text('Sao chép'),
                onTap: () => Navigator.pop(sheetContext, 'copy'),
              ),
            if (canEdit)
              ListTile(
                leading: const Icon(Icons.edit_outlined),
                title: const Text('Sửa'),
                onTap: () => Navigator.pop(sheetContext, 'edit'),
              ),
            if (canRecall)
              ListTile(
                leading: const Icon(Icons.undo),
                title: const Text('Thu hồi'),
                onTap: () => Navigator.pop(sheetContext, 'recall'),
              ),
            if (canReport)
              ListTile(
                leading: const Icon(Icons.flag_outlined),
                title: const Text('Báo cáo'),
                onTap: () => Navigator.pop(sheetContext, 'report'),
              ),
          ],
        ),
      ),
    );
    if (!mounted || action == null) {
      return;
    }
    switch (action) {
      case 'copy':
        await Clipboard.setData(ClipboardData(text: m.content ?? ''));
        if (mounted) {
          showMessage(context, 'Đã sao chép tin nhắn.');
        }
      case 'edit':
        _chat.startEdit(m);
        _text.text = m.content ?? '';
        _text.selection = TextSelection.collapsed(offset: _text.text.length);
      case 'recall':
        await _recall(m);
      case 'report':
        await _report(room, m);
    }
  }

  Future<void> _recall(ChatMessage m) async {
    final ok = await _confirm('Thu hồi tin nhắn này?', 'Cả hai bạn sẽ thấy “Tin nhắn đã được thu hồi”.', 'Thu hồi');
    if (!ok || !mounted) {
      return;
    }
    final editingThis = _chat.editing?.id == m.id;
    await _chat.recallMessage(m);
    if (!mounted) {
      return;
    }
    if (editingThis) {
      _text.clear();
    }
    showMessage(context, _chat.takeMessage());
  }

  Future<void> _report(ChatConversation room, ChatMessage m) async {
    final choice = await showReportDialog(context, reasons: room.reportReasons, title: 'Báo cáo tin nhắn');
    if (choice == null || !mounted) {
      return;
    }
    await _chat.reportMessage(m, reasonId: choice.reasonId, note: choice.note);
    if (mounted) {
      showMessage(context, _chat.takeMessage());
    }
  }

  // ---------------------------------------------------------------- Thông báo trên ô soạn tin

  Widget _notice(ChatConversation room) {
    final status = room.status;
    final scheme = Theme.of(context).colorScheme;
    final critical = status.isCutOff;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(12, 4, 12, 4),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: critical ? scheme.errorContainer : scheme.secondaryContainer,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            status.noticeText,
            style: TextStyle(color: critical ? scheme.onErrorContainer : scheme.onSecondaryContainer),
          ),
          if (status.isRequest)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  FilledButton.icon(onPressed: _accept, icon: const Icon(Icons.check), label: const Text('Chấp nhận')),
                  OutlinedButton(onPressed: () => _decline(room), child: const Text('Từ chối')),
                  TextButton.icon(
                    onPressed: () => _block(room),
                    icon: const Icon(Icons.block),
                    label: const Text('Chặn'),
                  ),
                ],
              ),
            ),
          if (status.noticeCode == 'BLOCKED_BY_ME')
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: OutlinedButton.icon(
                onPressed: _unblock,
                icon: const Icon(Icons.lock_open),
                label: const Text('Bỏ chặn'),
              ),
            ),
        ],
      ),
    );
  }

  Widget _encrypted() {
    final scheme = Theme.of(context).colorScheme;
    return SafeArea(
      top: false,
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.all(12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: scheme.surfaceContainerHighest, borderRadius: BorderRadius.circular(12)),
        child: Row(
          children: [
            Icon(Icons.lock_outline, color: scheme.primary),
            const SizedBox(width: 8),
            const Expanded(child: Text(ChatController.encryptedNotice)),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------- Ô soạn tin

  Widget _composer(ChatController chat, ChatConversation room) {
    final editing = chat.editing;
    final enabled = room.status.canSend || editing != null;
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 4, 8, 8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (editing != null)
              Row(
                children: [
                  const Icon(Icons.edit_outlined, size: 18),
                  const SizedBox(width: 6),
                  const Expanded(child: Text('Đang sửa tin nhắn')),
                  IconButton(
                    tooltip: 'Hủy sửa',
                    icon: const Icon(Icons.close),
                    onPressed: () {
                      _chat.cancelEdit();
                      _text.clear();
                    },
                  ),
                ],
              ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Expanded(
                  child: TextField(
                    controller: _text,
                    enabled: enabled,
                    minLines: 1,
                    maxLines: 5,
                    maxLength: room.messageMax,
                    textCapitalization: TextCapitalization.sentences,
                    onChanged: (_) => _chat.onComposing(),
                    decoration: InputDecoration(
                      hintText: enabled
                          ? (editing != null ? 'Sửa tin nhắn…' : 'Nhập tin nhắn…')
                          : 'Bạn chưa gửi được tin nhắn',
                      errorText: chat.sendError,
                      errorMaxLines: 3,
                      counterText: '',
                      border: const OutlineInputBorder(),
                      isDense: true,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(
                  tooltip: editing != null ? 'Lưu' : 'Gửi',
                  icon: Icon(editing != null ? Icons.check : Icons.send),
                  onPressed: enabled && !chat.isSending ? _send : null,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _send() async {
    final ok = await _chat.sendMessage(_text.text);
    if (ok && mounted) {
      _text.clear();
    }
  }

  // ---------------------------------------------------------------- Lời mời, chặn, xóa

  Future<void> _accept() async {
    await _chat.acceptRequest();
    if (mounted) {
      showMessage(context, _chat.takeMessage());
    }
  }

  Future<void> _decline(ChatConversation room) async {
    final name = room.peer.displayName;
    final ok = await _confirm(
      'Từ chối lời mời?',
      'Từ chối lời mời nhắn tin của $name? Lời mời sẽ rời khỏi danh sách của bạn và $name không gửi thêm được, '
          'nhưng không được báo là bị từ chối.',
      'Từ chối',
    );
    if (!ok || !mounted) {
      return;
    }
    final done = await _chat.declineRequest();
    _afterLeave(done);
  }

  Future<void> _delete(ChatConversation room) async {
    final name = room.peer.displayName;
    final ok = await _confirm(
      'Xóa cuộc trò chuyện?',
      'Xóa cuộc trò chuyện với $name? Các tin nhắn hiện có sẽ không còn hiện với bạn; $name vẫn giữ tin nhắn của '
          'họ. Nếu có tin nhắn mới, cuộc trò chuyện sẽ hiện lại.',
      'Xóa',
    );
    if (!ok || !mounted) {
      return;
    }
    final done = await _chat.deleteConversation();
    _afterLeave(done);
  }

  /// Sau Từ chối / Xóa: hiện câu của server; thành công thì quay về danh sách.
  void _afterLeave(bool done) {
    if (!mounted) {
      return;
    }
    showMessage(context, _chat.takeMessage());
    if (done) {
      Navigator.pop(context);
    }
  }

  Future<void> _block(ChatConversation room) async {
    final name = room.peer.displayName;
    final ok = await _confirm(
      'Chặn $name?',
      'Hai bạn sẽ không nhắn tin được cho nhau cho đến khi bạn bỏ chặn. $name không được báo.',
      'Chặn',
    );
    if (!ok || !mounted) {
      return;
    }
    await _chat.blockPeer();
    if (mounted) {
      showMessage(context, _chat.takeMessage());
    }
  }

  Future<void> _unblock() async {
    await _chat.unblockPeer();
    if (mounted) {
      showMessage(context, _chat.takeMessage());
    }
  }

  Future<bool> _confirm(String title, String content, String action) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(title),
        content: Text(content),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: Text(action)),
        ],
      ),
    );
    return ok == true;
  }
}

/// Lời nhắc an toàn ở đầu cuộc trò chuyện (như trang web).
class _SafetyNote extends StatelessWidget {
  const _SafetyNote({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.shield_outlined, size: 18, color: theme.colorScheme.primary),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: theme.textTheme.bodySmall)),
        ],
      ),
    );
  }
}

/// Ngăn cách ngày ("Hôm nay", "Hôm qua", 8/11/2026).
class _DayLabel extends StatelessWidget {
  const _DayLabel({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Center(child: Text(text, style: Theme.of(context).textTheme.labelSmall)),
  );
}
