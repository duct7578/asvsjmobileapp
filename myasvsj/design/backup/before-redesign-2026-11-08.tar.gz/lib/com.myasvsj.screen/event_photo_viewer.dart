import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.screen/media_image.dart';

/// Xem ảnh lớn (album từ review, ảnh trong một review): vuốt sang trước / sau, phóng to bằng hai ngón,
/// chú thích "2/5 · Lan Anh · năm 2026".
Future<void> showEventPhotos(
  BuildContext context, {
  required List<({String url, String caption})> photos,
  int initialIndex = 0,
}) {
  return showDialog<void>(
    context: context,
    builder: (_) => Dialog.fullscreen(
      child: EventPhotoViewer(photos: photos, initialIndex: initialIndex),
    ),
  );
}

class EventPhotoViewer extends StatefulWidget {
  const EventPhotoViewer({super.key, required this.photos, this.initialIndex = 0});

  final List<({String url, String caption})> photos;
  final int initialIndex;

  @override
  State<EventPhotoViewer> createState() => _EventPhotoViewerState();
}

class _EventPhotoViewerState extends State<EventPhotoViewer> {
  late final PageController _pages = PageController(initialPage: widget.initialIndex);
  late int _index = widget.initialIndex;

  @override
  void dispose() {
    _pages.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final photo = widget.photos[_index];
    final caption = ['${_index + 1}/${widget.photos.length}', if (photo.caption.isNotEmpty) photo.caption].join(' · ');
    return Scaffold(
      appBar: AppBar(
        title: Text(caption, maxLines: 1, overflow: TextOverflow.ellipsis),
        leading: IconButton(tooltip: 'Đóng', icon: const Icon(Icons.close), onPressed: () => Navigator.pop(context)),
      ),
      body: Column(
        children: [
          Expanded(
            child: PageView.builder(
              controller: _pages,
              itemCount: widget.photos.length,
              onPageChanged: (i) => setState(() => _index = i),
              itemBuilder: (_, i) => InteractiveViewer(
                child: Center(
                  child: MediaImage(url: widget.photos[i].url, fit: BoxFit.contain, radius: 0),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                TextButton.icon(
                  onPressed: _index == 0 ? null : () => _go(_index - 1),
                  icon: const Icon(Icons.chevron_left),
                  label: const Text('Trước'),
                ),
                const Spacer(),
                TextButton.icon(
                  onPressed: _index == widget.photos.length - 1 ? null : () => _go(_index + 1),
                  icon: const Icon(Icons.chevron_right),
                  label: const Text('Sau'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _go(int index) =>
      _pages.animateToPage(index, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
}
