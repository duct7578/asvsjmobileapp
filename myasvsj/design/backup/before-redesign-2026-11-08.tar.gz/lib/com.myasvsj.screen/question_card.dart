import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/question.dart';
import 'package:myasvsj/com.myasvsj.screen/question_author_row.dart';
import 'package:myasvsj/com.myasvsj.screen/question_badge.dart';
import 'package:myasvsj/com.myasvsj.screen/question_detail_screen.dart';

/// Một câu hỏi trong danh sách Hỏi-Đáp: số câu trả lời, nhãn trạng thái, câu hỏi, đoạn trích, chủ đề,
/// người hỏi và lượt thích. Bấm vào mở màn chi tiết.
class QuestionCard extends StatelessWidget {
  const QuestionCard({super.key, required this.question, this.onTopicTap});

  final Question question;

  /// Bấm một chủ đề trên thẻ: lọc danh sách theo chủ đề đó. null = chủ đề chỉ để xem.
  final ValueChanged<int>? onTopicTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final q = question;
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: q.id == null
            ? null
            : () => Navigator.push(
                context,
                MaterialPageRoute<void>(builder: (_) => QuestionDetailScreen(questionId: q.id!)),
              ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _AnswerCount(question: q),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: [
                        if (q.pinned) const QuestionBadge(label: 'Đã ghim', icon: Icons.push_pin_outlined),
                        if (q.isSolved)
                          QuestionBadge(
                            label: 'Đã giải quyết',
                            icon: Icons.check_circle_outline,
                            background: scheme.primaryContainer,
                            foreground: scheme.onPrimaryContainer,
                          )
                        else if (q.unanswered)
                          QuestionBadge(
                            label: 'Chưa ai trả lời',
                            icon: Icons.hourglass_empty,
                            background: scheme.tertiaryContainer,
                            foreground: scheme.onTertiaryContainer,
                          ),
                        if (q.status == 'PROCESSING')
                          QuestionBadge(
                            label: 'Đang quét ảnh/video',
                            icon: Icons.hourglass_top,
                            background: scheme.errorContainer,
                            foreground: scheme.onErrorContainer,
                          ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(q.title, maxLines: 3, overflow: TextOverflow.ellipsis, style: theme.textTheme.titleMedium),
                    if (q.content.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(q.content, maxLines: 2, overflow: TextOverflow.ellipsis, style: theme.textTheme.bodyMedium),
                    ],
                    if (q.topics.isNotEmpty || q.places.isNotEmpty) ...[
                      const SizedBox(height: 6),
                      Wrap(
                        spacing: 6,
                        runSpacing: 4,
                        children: [
                          for (final t in q.topics)
                            InkWell(
                              onTap: onTopicTap == null ? null : () => onTopicTap!(t.id),
                              borderRadius: BorderRadius.circular(12),
                              child: QuestionBadge(label: t.name, icon: Icons.sell_outlined),
                            ),
                          for (final p in q.places) QuestionBadge(label: p.name, icon: Icons.location_on_outlined),
                        ],
                      ),
                    ],
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: QuestionAuthorRow(author: q.author, createdAt: q.createdAt, showRank: false),
                        ),
                        Icon(Icons.favorite_border, size: 16, color: scheme.outline),
                        const SizedBox(width: 2),
                        Text('${q.likeCount}', semanticsLabel: '${q.likeCount} lượt thích'),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Ô số câu trả lời bên trái thẻ, như web: xanh khi đã giải quyết, viền khi đã có trả lời.
class _AnswerCount extends StatelessWidget {
  const _AnswerCount({required this.question});

  final Question question;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final solved = question.isSolved;
    final answered = question.answerCount > 0;
    final fg = solved ? scheme.onPrimary : (answered ? scheme.primary : scheme.onSurfaceVariant);
    return Semantics(
      label: solved ? 'Đã giải quyết, ${question.answerCount} câu trả lời' : '${question.answerCount} câu trả lời',
      excludeSemantics: true,
      child: Container(
        width: 52,
        padding: const EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(
          color: solved ? scheme.primary : null,
          border: Border.all(color: solved || answered ? scheme.primary : scheme.outlineVariant),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          children: [
            if (solved) Icon(Icons.check, size: 14, color: fg),
            Text(
              '${question.answerCount}',
              style: TextStyle(fontWeight: FontWeight.bold, color: fg),
            ),
            Text('trả lời', style: Theme.of(context).textTheme.labelSmall?.copyWith(color: fg)),
          ],
        ),
      ),
    );
  }
}
