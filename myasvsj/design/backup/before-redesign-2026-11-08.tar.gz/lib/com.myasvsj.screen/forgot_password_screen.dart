import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/auth_notice.dart';
import 'package:myasvsj/com.myasvsj.screen/password_field.dart';
import 'package:myasvsj/com.myasvsj.screen/password_rules.dart';

/// Quên mật khẩu (UC-U05) gộp hai trang /forgot-password và /reset-password của web:
/// 1. nhập email để nhận liên kết → 2. dán đường link trong email (app chưa mở được link) → 3. đặt mật khẩu mới.
/// Đặt xong thì đóng và trả về true; câu của server nằm ở AuthController.message.
class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key, this.initialEmail = ''});

  /// Email đã gõ ở màn Đăng nhập, điền sẵn vào ô.
  final String initialEmail;

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  late final _email = TextEditingController(text: widget.initialEmail);
  final _link = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<AuthController>().startForgotPassword());
  }

  @override
  void dispose() {
    _email.dispose();
    _link.dispose();
    _password.dispose();
    _confirm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    return Scaffold(
      appBar: AppBar(title: Text(auth.forgotStep == 3 ? 'Đặt lại mật khẩu' : 'Quên mật khẩu')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (auth.bannerError != null) AuthNotice(text: auth.bannerError!),
          ...switch (auth.forgotStep) {
            2 => _linkStep(auth),
            3 => _passwordStep(auth),
            _ => _emailStep(auth),
          },
          const SizedBox(height: 16),
          Center(
            child: TextButton(
              onPressed: auth.isLoading ? null : () => Navigator.pop(context, false),
              child: const Text('Quay lại Đăng nhập'),
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------- Bước 1: email

  List<Widget> _emailStep(AuthController auth) => [
    const Text('Nhập email bạn dùng để đăng ký. Chúng tôi sẽ gửi liên kết đặt lại mật khẩu.'),
    const SizedBox(height: 12),
    TextField(
      controller: _email,
      keyboardType: TextInputType.emailAddress,
      autofillHints: const [AutofillHints.email],
      autocorrect: false,
      maxLength: AuthController.emailMax,
      textInputAction: TextInputAction.done,
      onSubmitted: (_) => _sendLink(),
      decoration: InputDecoration(
        labelText: 'Email',
        errorText: auth.fieldErrors['email'],
        errorMaxLines: 3,
        counterText: '',
      ),
    ),
    const SizedBox(height: 16),
    FilledButton(
      onPressed: auth.isLoading ? null : _sendLink,
      child: Text(auth.isLoading ? 'Đang gửi…' : 'Gửi liên kết'),
    ),
    const SizedBox(height: 8),
    TextButton(
      onPressed: auth.isLoading ? null : () => auth.goToForgotStep(2),
      child: const Text('Tôi đã có đường link trong email'),
    ),
  ];

  Future<void> _sendLink() => context.read<AuthController>().sendResetLink(_email.text);

  // ---------------------------------------------------------------- Bước 2: dán đường link

  List<Widget> _linkStep(AuthController auth) => [
    if (auth.forgotNotice != null) AuthNotice(text: auth.forgotNotice!, isError: false),
    const Text(
      'Mở email "Đặt lại mật khẩu", sao chép đường link trong thư rồi dán vào ô dưới đây. '
      'Đường link chỉ dùng được một lần.',
    ),
    const SizedBox(height: 12),
    TextField(
      controller: _link,
      keyboardType: TextInputType.url,
      autocorrect: false,
      minLines: 1,
      maxLines: 3,
      decoration: InputDecoration(
        labelText: 'Đường link trong email',
        hintText: 'http://…/reset-password?token=…',
        errorText: auth.fieldErrors['token'],
        errorMaxLines: 3,
        suffixIcon: IconButton(tooltip: 'Dán', icon: const Icon(Icons.content_paste), onPressed: _paste),
      ),
    ),
    const SizedBox(height: 16),
    FilledButton(
      onPressed: auth.isLoading ? null : _checkLink,
      child: Text(auth.isLoading ? 'Đang kiểm tra…' : 'Tiếp tục'),
    ),
    const SizedBox(height: 8),
    TextButton(onPressed: auth.isLoading ? null : () => auth.goToForgotStep(1), child: const Text('Gửi lại liên kết')),
  ];

  Future<void> _paste() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text;
    if (text != null && text.isNotEmpty && mounted) {
      _link.text = text.trim();
    }
  }

  Future<void> _checkLink() async {
    final ok = await context.read<AuthController>().checkResetLink(_link.text);
    if (ok && mounted) {
      _password.clear();
      _confirm.clear();
    }
  }

  // ---------------------------------------------------------------- Bước 3: mật khẩu mới

  List<Widget> _passwordStep(AuthController auth) => [
    Text('Đặt mật khẩu mới cho tài khoản ${auth.resetEmail ?? ''}.'),
    const SizedBox(height: 12),
    PasswordField(
      controller: _password,
      label: 'Mật khẩu mới',
      isNewPassword: true,
      errorText: auth.fieldErrors['password'],
      textInputAction: TextInputAction.next,
    ),
    const SizedBox(height: 4),
    PasswordRules(controller: _password),
    const SizedBox(height: 12),
    PasswordField(
      controller: _confirm,
      label: 'Nhập lại mật khẩu',
      isNewPassword: true,
      errorText: auth.fieldErrors['confirmPassword'],
      textInputAction: TextInputAction.done,
      onSubmitted: (_) => _reset(),
    ),
    const SizedBox(height: 16),
    FilledButton(
      onPressed: auth.isLoading ? null : _reset,
      child: Text(auth.isLoading ? 'Đang lưu…' : 'Đặt lại mật khẩu'),
    ),
  ];

  Future<void> _reset() async {
    final auth = context.read<AuthController>();
    final ok = await auth.resetPassword(_password.text, _confirm.text);
    if (!mounted) {
      return;
    }
    if (ok) {
      TextInput.finishAutofillContext();
      // "Đã đặt lại mật khẩu. Hãy đăng nhập bằng mật khẩu mới."
      showMessage(context, auth.takeMessage());
      Navigator.pop(context, true);
    } else if (auth.forgotStep == 2) {
      // Liên kết vừa hết hạn hoặc đã dùng: câu lỗi hiện dưới ô dán link
      _link.clear();
    }
  }
}
