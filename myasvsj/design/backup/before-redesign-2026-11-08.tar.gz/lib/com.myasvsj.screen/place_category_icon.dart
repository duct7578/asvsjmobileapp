import 'package:flutter/material.dart';

/// Biểu tượng của danh mục địa điểm. Server gửi tên Material Symbols của web (`icon` của danh mục, ví dụ
/// "restaurant", "train"); tên lạ hiện biểu tượng địa điểm chung.
IconData placeCategoryIcon(String? name) => switch (name) {
  'local_convenience_store' => Icons.local_convenience_store,
  'restaurant' => Icons.restaurant,
  'train' => Icons.train,
  'shopping_cart' => Icons.shopping_cart,
  'account_balance' => Icons.account_balance,
  'local_hospital' => Icons.local_hospital,
  'local_post_office' => Icons.local_post_office,
  'local_pharmacy' => Icons.local_pharmacy,
  'school' => Icons.school,
  'local_laundry_service' => Icons.local_laundry_service,
  'park' => Icons.park,
  'temple_buddhist' => Icons.temple_buddhist,
  'smartphone' => Icons.smartphone,
  'home_work' => Icons.home_work,
  'celebration' => Icons.celebration,
  _ => Icons.place,
};
