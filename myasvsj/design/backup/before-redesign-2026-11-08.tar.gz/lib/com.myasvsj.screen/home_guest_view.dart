import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/home_guest.dart';
import 'package:myasvsj/com.myasvsj.model/home_quote.dart';
import 'package:myasvsj/com.myasvsj.screen/event_list_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/home_format.dart';
import 'package:myasvsj/com.myasvsj.screen/home_phrase_card.dart';
import 'package:myasvsj/com.myasvsj.screen/home_search_box.dart';
import 'package:myasvsj/com.myasvsj.screen/home_tag_chips.dart';
import 'package:myasvsj/com.myasvsj.screen/legal_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/map_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/phrase_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/question_list_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/register_screen.dart';

/// Trang chủ của khách (câu chữ theo home.js của web): lời mời, ô tìm kiếm, số liệu, "Senpai nói gì",
/// các tính năng, câu tiếng Nhật hôm nay và liên kết điều khoản.
class HomeGuestView extends StatelessWidget {
  const HomeGuestView({super.key, required this.home, this.banner});

  final HomeGuest home;

  /// Báo lỗi khi tải lại (giữ trang cũ); null khi không có.
  final Widget? banner;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        ?banner,
        _hero(context, theme),
        const SizedBox(height: 16),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: _Tile(value: home.placesWithReviews, label: 'địa điểm đã có review'),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _Tile(value: home.reviewCount, label: 'review của người Việt'),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _Tile(value: home.phraseCount, label: 'mẫu câu theo địa điểm'),
            ),
          ],
        ),
        if (home.quotes.isNotEmpty) ...[
          const SizedBox(height: 20),
          Text('Senpai nói gì', style: theme.textTheme.titleLarge),
          const SizedBox(height: 8),
          for (final quote in home.quotes) _QuoteCard(quote: quote),
        ],
        const SizedBox(height: 20),
        _Feature(
          icon: Icons.location_on_outlined,
          title: 'Bản đồ có review',
          text: 'Nơi nào đã có review sẽ nở hoa trên bản đồ.',
          open: () => pushScreen<void>(context, const MapScreen()),
        ),
        _Feature(
          icon: Icons.school_outlined,
          title: 'Học tiếng Nhật theo chủ đề',
          text: 'Thanh toán, hỏi đường, khám bệnh… học đúng câu mình sắp dùng.',
          open: () => pushScreen<void>(context, const PhraseScreen()),
        ),
        _Feature(
          icon: Icons.contact_support_outlined,
          title: 'Hỏi senpai',
          text: 'Đặt câu hỏi, Mentor trả lời, bạn chọn câu hay nhất.',
          open: () => pushScreen<void>(context, const QuestionListScreen()),
        ),
        _Feature(
          icon: Icons.celebration_outlined,
          title: 'Lễ hội gần bạn',
          text: 'Sự kiện đang và sắp diễn ra hiện ngay trên bản đồ.',
          open: () => pushScreen<void>(context, const EventListScreen()),
        ),
        if (home.phrase != null) ...[const SizedBox(height: 12), HomePhraseCard(phrase: home.phrase!)],
        const SizedBox(height: 12),
        Wrap(
          alignment: WrapAlignment.center,
          children: [
            TextButton(
              onPressed: () => pushScreen<void>(context, const LegalScreen(type: 'terms')),
              child: const Text('Điều khoản sử dụng'),
            ),
            TextButton(
              onPressed: () => pushScreen<void>(context, const LegalScreen(type: 'privacy')),
              child: const Text('Chính sách bảo mật'),
            ),
            TextButton(
              onPressed: () => pushScreen<void>(context, const LegalScreen(type: 'community')),
              child: const Text('Quy tắc cộng đồng'),
            ),
          ],
        ),
      ],
    );
  }

  Widget _hero(BuildContext context, ThemeData theme) {
    return Card(
      color: theme.colorScheme.primaryContainer,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.local_florist_outlined, size: 18, color: theme.colorScheme.onPrimaryContainer),
                const SizedBox(width: 6),
                Flexible(
                  child: Text(
                    'Cho du học sinh Việt mới đến Nhật',
                    style: theme.textTheme.labelLarge?.copyWith(color: theme.colorScheme.onPrimaryContainer),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'Ở Nhật, bạn không đi một mình.',
              style: theme.textTheme.headlineSmall?.copyWith(color: theme.colorScheme.onPrimaryContainer),
            ),
            const SizedBox(height: 8),
            Text(
              'Các senpai đã đánh dấu sẵn chỗ ăn rẻ, ga tàu, văn phòng quận. Mở bản đồ là thấy nơi nào đã có người '
              'Việt review, kèm câu tiếng Nhật để dùng ngay tại đó.',
              style: TextStyle(color: theme.colorScheme.onPrimaryContainer),
            ),
            const SizedBox(height: 12),
            const HomeSearchBox(),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                FilledButton.icon(
                  onPressed: () => pushScreen<void>(context, const MapScreen()),
                  icon: const Icon(Icons.map_outlined),
                  label: const Text('Xem bản đồ'),
                ),
                OutlinedButton.icon(
                  onPressed: () => pushScreen<void>(context, const RegisterScreen()),
                  icon: const Icon(Icons.person_add_alt_outlined),
                  label: const Text('Đăng ký miễn phí'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'Xem bản đồ, review và từ vựng không cần tài khoản.',
              style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onPrimaryContainer),
            ),
          ],
        ),
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  const _Tile({required this.value, required this.label});

  final int value;
  final String label;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('$value', style: theme.textTheme.headlineSmall?.copyWith(color: theme.colorScheme.primary)),
            Text(label, style: theme.textTheme.bodySmall, maxLines: 3, overflow: TextOverflow.ellipsis),
          ],
        ),
      ),
    );
  }
}

class _QuoteCard extends StatelessWidget {
  const _QuoteCard({required this.quote});

  final HomeQuote quote;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('"${quote.text}"', style: theme.textTheme.bodyLarge?.copyWith(fontStyle: FontStyle.italic)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 2,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                Text(quote.authorName, style: theme.textTheme.labelLarge),
                HomeTagChips(tags: quote.authorTags),
                if (quote.placeName.isNotEmpty) Text('về ${quote.placeName}', style: theme.textTheme.bodySmall),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _Feature extends StatelessWidget {
  const _Feature({required this.icon, required this.title, required this.text, required this.open});

  final IconData icon;
  final String title;
  final String text;
  final VoidCallback open;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(icon, color: Theme.of(context).colorScheme.primary),
        title: Text(title),
        subtitle: Text(text),
        trailing: const Icon(Icons.chevron_right),
        onTap: open,
      ),
    );
  }
}
