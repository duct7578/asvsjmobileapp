import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/place_controller.dart';
import 'package:myasvsj/com.myasvsj.model/place_option.dart';
import 'package:myasvsj/com.myasvsj.screen/map_distance_text.dart';
import 'package:myasvsj/com.myasvsj.screen/place_category_icon.dart';

/// Bảng kết quả nằm dưới bản đồ: kết quả tìm, "Địa điểm quanh đây", hoặc địa điểm của một danh mục.
/// Đọc trạng thái từ [PlaceController] (`panelTitle`, `panelItems`…).
class MapResultPanel extends StatelessWidget {
  const MapResultPanel({super.key, required this.onOpen, required this.onCategory});

  /// Bấm một địa điểm.
  final ValueChanged<PlaceOption> onOpen;

  /// Bấm một danh mục khớp từ khóa tìm.
  final ValueChanged<String> onCategory;

  @override
  Widget build(BuildContext context) {
    final places = context.watch<PlaceController>();
    final theme = Theme.of(context);
    final count = places.panelItems.length;
    return Material(
      elevation: 6,
      color: theme.colorScheme.surface,
      borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
      clipBehavior: Clip.antiAlias,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 4, 0),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        places.panelTitle ?? '',
                        style: theme.textTheme.titleMedium,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      if (!places.isPanelLoading && places.panelError == null)
                        Text('$count địa điểm', style: theme.textTheme.bodySmall),
                    ],
                  ),
                ),
                IconButton(tooltip: 'Đóng danh sách', icon: const Icon(Icons.close), onPressed: places.closePanel),
              ],
            ),
          ),
          Flexible(child: _body(context, places)),
        ],
      ),
    );
  }

  Widget _body(BuildContext context, PlaceController places) {
    final theme = Theme.of(context);
    if (places.isPanelLoading) {
      return const Padding(
        padding: EdgeInsets.all(16),
        child: Center(child: CircularProgressIndicator()),
      );
    }
    if (places.panelError != null) {
      return Padding(
        padding: const EdgeInsets.all(16),
        child: Text(places.panelError!, style: TextStyle(color: theme.colorScheme.error)),
      );
    }
    final note = places.panelNote;
    return ListView(
      shrinkWrap: true,
      padding: const EdgeInsets.only(bottom: 8),
      children: [
        for (final category in places.panelCategories)
          ListTile(
            dense: true,
            leading: Icon(placeCategoryIcon(category.icon)),
            title: Text(category.name),
            subtitle: Text('Danh mục · ${category.count} địa điểm'),
            onTap: () => onCategory(category.id),
          ),
        if (places.panelItems.isEmpty && places.panelCategories.isEmpty)
          const Padding(padding: EdgeInsets.fromLTRB(16, 8, 16, 0), child: Text('Không có địa điểm nào khớp.')),
        for (final option in places.panelItems) _tile(context, places, option),
        if (note.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: Text(note, style: theme.textTheme.bodySmall),
          ),
      ],
    );
  }

  Widget _tile(BuildContext context, PlaceController places, PlaceOption option) {
    final known = option.id == null ? null : places.placeById(option.id!);
    final icon = known != null
        ? places.categoryById(known.categoryId)?.icon
        : places.categoryByName(option.category)?.icon;
    final sub = [option.category, option.address].where((s) => s.isNotEmpty).join(' · ');
    final distance = formatMapDistance(places.distanceTo(option.lat, option.lng));
    final String meta;
    if (!option.isOnSenpai) {
      meta = 'OSM';
    } else if (known != null && known.reviewCount > 0) {
      meta = '★ ${known.rating?.toStringAsFixed(1) ?? ''} · ${known.reviewCount} review';
    } else {
      meta = 'Chưa có review';
    }
    return ListTile(
      dense: true,
      leading: Icon(placeCategoryIcon(icon)),
      title: Text(option.name, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: sub.isEmpty ? null : Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis),
      trailing: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(meta, style: Theme.of(context).textTheme.bodySmall),
          if (distance.isNotEmpty) Text(distance, style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
      onTap: () => onOpen(option),
    );
  }
}
