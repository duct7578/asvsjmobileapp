import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/chat_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/notification_controller.dart';
import 'package:myasvsj/com.myasvsj.screen/conversation_list_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/global_search_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/login_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/notification_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/profile_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// Các nút trên thanh tiêu đề của 4 tab chính: Tìm kiếm, Tin nhắn, Thông báo (có số chưa đọc), Tôi / Đăng nhập.
///
/// Dùng: `AppBar(title: const Text('Blog'), actions: const [AppBarActions()])`.
class AppBarActions extends StatelessWidget {
  const AppBarActions({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    final unread = context.watch<NotificationController>().unreadCount;
    // Tin chưa đọc + lời mời mới, như số trên nút Tin nhắn của web. Test chỉ cấp NotificationController thì bỏ qua.
    final chats = _chatBadge(context);
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        IconButton(
          tooltip: 'Tìm kiếm',
          icon: const Icon(Icons.search),
          onPressed: () => _push(context, const GlobalSearchScreen()),
        ),
        IconButton(
          tooltip: 'Tin nhắn',
          icon: Badge(
            isLabelVisible: auth.isSignedIn && chats > 0,
            label: Text(chats > 99 ? '99+' : '$chats'),
            child: const Icon(Icons.chat_bubble_outline),
          ),
          onPressed: () => _pushSignedIn(context, const ConversationListScreen()),
        ),
        IconButton(
          tooltip: 'Thông báo',
          icon: Badge(
            isLabelVisible: auth.isSignedIn && unread > 0,
            label: Text(unread > 99 ? '99+' : '$unread'),
            child: const Icon(Icons.notifications_none),
          ),
          onPressed: () => _pushSignedIn(context, const NotificationScreen()),
        ),
        if (auth.isSignedIn)
          IconButton(
            tooltip: 'Tôi',
            icon: const Icon(Icons.account_circle_outlined),
            onPressed: () => _push(context, const ProfileScreen()),
          )
        else
          IconButton(
            tooltip: 'Đăng nhập',
            icon: const Icon(Icons.login),
            onPressed: () => _push(context, const LoginScreen()),
          ),
      ],
    );
  }

  static int _chatBadge(BuildContext context) {
    try {
      final counts = context.watch<ChatController>().counts;
      return counts.unread + counts.requests;
    } on ProviderNotFoundException {
      return 0;
    }
  }

  static void _push(BuildContext context, Widget screen) {
    Navigator.push(context, MaterialPageRoute<void>(builder: (_) => screen));
  }

  static Future<void> _pushSignedIn(BuildContext context, Widget screen) async {
    if (!await requireSignIn(context) || !context.mounted) {
      return;
    }
    _push(context, screen);
  }
}
