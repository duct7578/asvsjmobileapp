import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/profile_controller.dart';
import 'package:myasvsj/com.myasvsj.model/point_line.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';
import 'package:myasvsj/com.myasvsj.screen/empty_view.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/link_router.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/profile_sign_in_prompt.dart';
import 'package:myasvsj/com.myasvsj.screen/profile_user_watcher.dart';

/// "Lịch sử điểm" (UC-U10): mỗi lần cộng / trừ điểm, mới nhất trước, 20 dòng một trang, cuộn tới cuối để tải thêm.
/// Nội dung còn xem được thì bấm vào để mở.
class PointHistoryScreen extends StatefulWidget {
  const PointHistoryScreen({super.key});

  @override
  State<PointHistoryScreen> createState() => _PointHistoryScreenState();
}

class _PointHistoryScreenState extends State<PointHistoryScreen> with ProfileUserWatcher {
  @override
  void onUserChanged(int? userId) {
    if (userId != null) {
      context.read<ProfileController>().loadPoints();
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthController>().currentUser;
    watchUser(user?.id);
    return Scaffold(
      appBar: AppBar(title: const Text('Lịch sử điểm')),
      body: user == null
          ? const ProfileSignInPrompt(text: 'Đăng nhập để xem lịch sử điểm của bạn.')
          : _body(context.watch<ProfileController>()),
    );
  }

  Widget _body(ProfileController profiles) {
    final lines = profiles.pointLines;
    if (profiles.isLoadingPoints && lines.isEmpty) {
      return const LoadingView();
    }
    if (profiles.pointsError != null && lines.isEmpty) {
      return ErrorView(message: profiles.pointsError!, onRetry: profiles.loadPoints);
    }
    return RefreshIndicator(
      onRefresh: () => profiles.loadPoints(keepShown: true),
      child: NotificationListener<ScrollNotification>(
        onNotification: (n) {
          if (n.metrics.extentAfter < 300) {
            profiles.loadMorePoints();
          }
          return false;
        },
        child: ListView.separated(
          physics: const AlwaysScrollableScrollPhysics(),
          itemCount: lines.length + 2,
          separatorBuilder: (_, i) => i == 0 || i >= lines.length ? const SizedBox.shrink() : const Divider(height: 1),
          itemBuilder: (_, i) {
            if (i == 0) {
              return _summary(profiles);
            }
            if (i > lines.length) {
              return _footer(profiles);
            }
            return _line(lines[i - 1]);
          },
        ),
      ),
    );
  }

  Widget _summary(ProfileController profiles) {
    final theme = Theme.of(context);
    if (profiles.pointLines.isEmpty) {
      // Điểm có từ trước khi có lịch sử (ví dụ dữ liệu mẫu) không có dòng nào
      return EmptyView(
        icon: Icons.history,
        text: profiles.points > 0
            ? 'Bạn có ${profiles.points} điểm. Chưa có lần cộng hoặc trừ điểm nào được ghi lại.'
            : 'Bạn chưa có điểm nào. Viết review đầu tiên để nhận 10 điểm.',
      );
    }
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Text(
        'Bạn có ${profiles.points} điểm · ${profiles.pointsTotal} lần cộng / trừ',
        style: theme.textTheme.titleMedium,
      ),
    );
  }

  Widget _line(PointLine line) {
    final theme = Theme.of(context);
    final color = line.delta < 0 ? theme.colorScheme.error : theme.colorScheme.primary;
    final link = line.link;
    return ListTile(
      leading: SizedBox(
        width: 48,
        child: Text(
          '${line.delta < 0 ? '−' : '+'}${line.delta.abs()}',
          textAlign: TextAlign.center,
          style: theme.textTheme.titleMedium?.copyWith(color: color, fontWeight: FontWeight.bold),
        ),
      ),
      title: Text(line.reasonLabel, maxLines: 2, overflow: TextOverflow.ellipsis),
      subtitle: Text(
        line.title ?? 'Nội dung không còn',
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: link == null ? null : TextStyle(color: theme.colorScheme.primary),
      ),
      trailing: line.createdAt == null ? null : Text(formatDate(line.createdAt!), style: theme.textTheme.bodySmall),
      onTap: link == null ? null : () => openLink(context, link),
    );
  }

  Widget _footer(ProfileController profiles) {
    if (profiles.isLoadingMorePoints) {
      return const Padding(
        padding: EdgeInsets.all(16),
        child: Center(child: CircularProgressIndicator()),
      );
    }
    if (profiles.morePointsError != null) {
      return Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(profiles.morePointsError!, textAlign: TextAlign.center),
            TextButton(onPressed: profiles.loadMorePoints, child: const Text('Thử lại')),
          ],
        ),
      );
    }
    if (profiles.hasMorePoints) {
      return Padding(
        padding: const EdgeInsets.all(16),
        child: Center(
          child: OutlinedButton(onPressed: profiles.loadMorePoints, child: const Text('Tải thêm')),
        ),
      );
    }
    return const SizedBox(height: 24);
  }
}
