import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/phrase_controller.dart';
import 'package:myasvsj/com.myasvsj.model/phrase.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/flashcard_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/phrase_choice_chips.dart';

/// "Luyện tập" (renderPractice() của web): chọn thẻ trong cả thư viện theo "Luyện theo" (Tất cả / Chủ đề / Địa điểm
/// và chủ đề, địa điểm cụ thể), "Loại" (Cả hai / Từ vựng / Mẫu câu), "Thẻ" (Tất cả / Chưa thuộc / Đã thuộc /
/// Chưa luyện, chỉ thành viên), "Xáo trộn thứ tự thẻ", rồi "Bắt đầu (n thẻ)". Mỗi số đếm theo các lựa chọn phía trên.
/// Thư viện được đọc lại mỗi lần mở, lựa chọn được giữ trong lúc app mở.
class PhrasePracticeScreen extends StatefulWidget {
  const PhrasePracticeScreen({super.key});

  @override
  State<PhrasePracticeScreen> createState() => _PhrasePracticeScreenState();
}

class _PhrasePracticeScreenState extends State<PhrasePracticeScreen> {
  bool _started = false;
  int? _userId;

  Future<void> _load() async {
    final phrases = context.read<PhraseController>();
    if (phrases.overview == null) {
      await phrases.loadOverview();
    }
    await phrases.loadLibrary();
  }

  @override
  Widget build(BuildContext context) {
    final userId = context.select<AuthController, int?>((a) => a.currentUser?.id);
    if (!_started || userId != _userId) {
      _started = true;
      _userId = userId;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          _load();
        }
      });
    }
    final phrases = context.watch<PhraseController>();
    return Scaffold(
      appBar: AppBar(title: const Text('Luyện tập')),
      body: _body(phrases),
    );
  }

  Widget _body(PhraseController phrases) {
    if (phrases.isLoadingLibrary || (phrases.isLoadingOverview && phrases.overview == null)) {
      return const LoadingView();
    }
    final error = phrases.libraryError ?? (phrases.overview == null ? phrases.overviewError : null);
    if (error != null || phrases.library == null) {
      return ErrorView(message: error ?? 'Không tải được thư viện.', onRetry: _load);
    }
    final theme = Theme.of(context);
    final groups = phrases.practiceGroups();
    final scope = phrases.practiceScope;
    final ofKind = scope.where((p) => phrases.practiceKind.isEmpty || p.kind == phrases.practiceKind).toList();
    final pool = phrases.practicePool;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        const Text('Chọn thẻ muốn luyện. Lật thẻ rồi chọn "Chưa thuộc" hoặc "Đã thuộc".'),
        const SizedBox(height: 16),
        Text('Luyện theo', style: theme.textTheme.titleSmall),
        const SizedBox(height: 8),
        SegmentedButton<String>(
          showSelectedIcon: false,
          segments: const [
            ButtonSegment(value: '', label: Text('Tất cả')),
            ButtonSegment(value: 'topic', label: Text('Chủ đề')),
            ButtonSegment(value: 'category', label: Text('Địa điểm')),
          ],
          selected: {phrases.practiceBy},
          onSelectionChanged: (value) => phrases.choosePractice(by: value.first),
        ),
        if (phrases.practiceBy.isNotEmpty && groups.isNotEmpty) ...[
          const SizedBox(height: 8),
          DropdownButton<String>(
            isExpanded: true,
            value: groups.any((g) => g.id == phrases.practiceGroup) ? phrases.practiceGroup : null,
            hint: Text(phrases.practiceBy == 'topic' ? 'Chọn chủ đề' : 'Chọn địa điểm'),
            items: [
              for (final g in groups)
                DropdownMenuItem(
                  value: g.id,
                  child: Text('${g.name} (${g.count})', maxLines: 1, overflow: TextOverflow.ellipsis),
                ),
            ],
            onChanged: (value) => phrases.choosePractice(group: value),
          ),
        ],
        const SizedBox(height: 16),
        Text('Loại', style: theme.textTheme.titleSmall),
        const SizedBox(height: 8),
        PhraseChoiceChips(
          options: [
            ('', 'Cả hai (${scope.length})'),
            for (final k in Phrase.kinds) (k, '${Phrase.kindName(k)} (${scope.where((p) => p.kind == k).length})'),
          ],
          selected: phrases.practiceKind,
          onSelected: (value) => phrases.choosePractice(kind: value),
        ),
        if (phrases.isMember) ...[
          const SizedBox(height: 16),
          Text('Thẻ', style: theme.textTheme.titleSmall),
          const SizedBox(height: 8),
          PhraseChoiceChips(
            options: [
              ('', 'Tất cả (${ofKind.length})'),
              for (final entry in Phrase.statusNames.entries)
                (entry.key, '${entry.value} (${ofKind.where((p) => p.hasStatus(entry.key)).length})'),
            ],
            selected: phrases.practiceStatus,
            onSelected: (value) => phrases.choosePractice(status: value),
          ),
        ],
        const SizedBox(height: 8),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Xáo trộn thứ tự thẻ'),
          value: phrases.practiceShuffle,
          onChanged: (value) => phrases.choosePractice(shuffle: value),
        ),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: pool.isEmpty ? null : () => _start(phrases),
          icon: const Icon(Icons.play_arrow),
          label: Text('Bắt đầu (${pool.length} thẻ)'),
        ),
      ],
    );
  }

  void _start(PhraseController phrases) {
    phrases.startPractice();
    Navigator.pushReplacement(context, MaterialPageRoute<void>(builder: (_) => const FlashcardScreen()));
  }
}
