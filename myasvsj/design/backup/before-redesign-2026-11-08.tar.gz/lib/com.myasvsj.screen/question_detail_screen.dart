import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/question_controller.dart';
import 'package:myasvsj/com.myasvsj.model/answer.dart';
import 'package:myasvsj/com.myasvsj.model/author.dart';
import 'package:myasvsj/com.myasvsj.model/media_item.dart';
import 'package:myasvsj/com.myasvsj.model/question.dart';
import 'package:myasvsj/com.myasvsj.screen/answer_tile.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/chat_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/login_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/media_image.dart';
import 'package:myasvsj/com.myasvsj.screen/place_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/question_author_row.dart';
import 'package:myasvsj/com.myasvsj.screen/question_badge.dart';
import 'package:myasvsj/com.myasvsj.screen/question_form_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/report_dialog.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// Màn chi tiết câu hỏi (`/qa/{id}` của web): câu hỏi, ảnh, chủ đề, người hỏi, các câu trả lời (câu hay nhất ở
/// đầu, phản hồi lồng bên dưới), và các thao tác: thích, lưu, báo cáo, trả lời, phản hồi, chọn câu trả lời hay nhất,
/// sửa / xóa của mình, nhắn tin cho người viết. Khách bấm thao tác thì được đưa sang Đăng nhập.
class QuestionDetailScreen extends StatefulWidget {
  const QuestionDetailScreen({super.key, required this.questionId});

  final int questionId;

  @override
  State<QuestionDetailScreen> createState() => _QuestionDetailScreenState();
}

class _QuestionDetailScreenState extends State<QuestionDetailScreen> {
  static const _statusNotes = {
    'PROCESSING': 'Ảnh của câu hỏi đang được quét. Trong lúc này chỉ bạn thấy câu hỏi.',
    'HIDDEN': 'Câu hỏi đang tạm ẩn vì có nhiều báo cáo, chờ Moderator xem xét.',
    'REJECTED': 'Câu hỏi chưa được đăng vì vi phạm Quy tắc cộng đồng. Bạn có thể sửa rồi gửi lại.',
  };

  final _answer = TextEditingController();
  final _answerFocus = FocusNode();
  final _reply = TextEditingController();
  final _edit = TextEditingController();

  /// Câu trả lời đang mở ô phản hồi / đang sửa tại chỗ (trạng thái giao diện của riêng màn này).
  int? _replyTo;
  int? _editing;

  /// Người đang đăng nhập lần dựng trước: đổi thì tải lại, vì quyền và trạng thái thích / lưu theo người xem.
  int? _userId;
  bool _userSeen = false;

  int get _id => widget.questionId;

  QuestionController get _controller => context.read<QuestionController>();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _controller.loadQuestion(_id));
  }

  @override
  void dispose() {
    _answer.dispose();
    _answerFocus.dispose();
    _reply.dispose();
    _edit.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    final userId = auth.currentUser?.id;
    if (_userSeen && userId != _userId) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          _controller.loadQuestion(_id);
        }
      });
    }
    _userSeen = true;
    _userId = userId;

    final c = context.watch<QuestionController>();
    final q = c.questionOf(_id);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Câu hỏi'),
        actions: [
          if (q != null && q.isMine) ...[
            if (QuestionController.editableStatuses.contains(q.status))
              IconButton(
                tooltip: 'Sửa câu hỏi',
                icon: const Icon(Icons.edit_outlined),
                onPressed: () => _editQuestion(q),
              ),
            IconButton(tooltip: 'Xóa câu hỏi', icon: const Icon(Icons.delete_outline), onPressed: () => _delete(q)),
          ],
        ],
      ),
      body: _body(c, q, auth.isSignedIn),
    );
  }

  Widget _body(QuestionController c, Question? q, bool signedIn) {
    if (q == null) {
      final error = c.questionError(_id);
      if (error == null) {
        return const LoadingView();
      }
      return ErrorView(message: error, onRetry: () => c.loadQuestion(_id));
    }
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final note = _statusNotes[q.status];
    return RefreshIndicator(
      onRefresh: () => c.loadQuestion(_id),
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        children: [
          if (note != null)
            Card(
              color: q.status == 'PROCESSING' ? scheme.tertiaryContainer : scheme.errorContainer,
              child: Padding(padding: const EdgeInsets.all(12), child: Text(note)),
            ),
          Wrap(
            spacing: 6,
            runSpacing: 4,
            children: [
              const QuestionBadge(label: 'Hỏi đáp', icon: Icons.help_outline),
              if (q.isSolved)
                QuestionBadge(
                  label: 'Đã giải quyết',
                  icon: Icons.check_circle_outline,
                  background: scheme.primaryContainer,
                  foreground: scheme.onPrimaryContainer,
                )
              else if (q.isPublished)
                const QuestionBadge(label: 'Câu hỏi chờ trả lời', icon: Icons.contact_support_outlined),
              if (q.pinned) const QuestionBadge(label: 'Đã ghim', icon: Icons.push_pin_outlined),
            ],
          ),
          const SizedBox(height: 8),
          SelectableText(q.title, style: theme.textTheme.headlineSmall),
          const SizedBox(height: 8),
          QuestionAuthorRow(
            author: q.author,
            createdAt: q.createdAt,
            edited: q.edited,
            trailing: q.isMine || q.author == null
                ? null
                : TextButton.icon(
                    style: TextButton.styleFrom(visualDensity: VisualDensity.compact),
                    onPressed: () => _message(q.author!),
                    icon: const Icon(Icons.chat_outlined, size: 18),
                    label: const Text('Nhắn tin'),
                  ),
          ),
          if (q.topics.isNotEmpty || q.places.isNotEmpty) ...[
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 4,
              children: [
                for (final t in q.topics) QuestionBadge(label: t.name, icon: Icons.sell_outlined),
                for (final p in q.places)
                  ActionChip(
                    avatar: const Icon(Icons.location_on_outlined, size: 18),
                    label: Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute<void>(builder: (_) => PlaceDetailScreen(placeId: p.id)),
                    ),
                  ),
              ],
            ),
          ],
          for (final image in q.images) _image(image),
          if (q.content.isNotEmpty) ...[
            const SizedBox(height: 12),
            SelectableText(q.content, style: theme.textTheme.bodyLarge),
          ],
          const SizedBox(height: 12),
          _actionBar(q, signedIn),
          const Divider(height: 32),
          Text('Câu trả lời (${q.answerCount})', style: theme.textTheme.titleMedium),
          const SizedBox(height: 8),
          _answerForm(c, q, signedIn),
          if (q.answers.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: Text(
                'Chưa có câu trả lời. Bạn biết câu trả lời thì chia sẻ nhé.',
                style: theme.textTheme.bodyMedium,
              ),
            )
          else
            for (final a in q.answers)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: AnswerTile(
                  key: ValueKey('answer-${a.id}'),
                  answer: a,
                  question: q,
                  signedIn: signedIn,
                  replyingTo: _replyTo,
                  replyBox: _replyTo == null ? null : _replyBox(c, _replyTo!),
                  editingId: _editing,
                  editBox: _editing == null ? null : _editBox(c, _editing!),
                  onLike: _likeAnswer,
                  onReply: _openReply,
                  onEdit: _openEdit,
                  onDelete: _deleteAnswer,
                  onReport: _reportAnswer,
                  onBest: _chooseBest,
                  onMessage: (answer) => _message(answer.author!),
                ),
              ),
        ],
      ),
    );
  }

  /// Ảnh của câu hỏi; bấm để xem to, phóng to được.
  Widget _image(MediaItem image) {
    final ratio = (image.width ?? 0) > 0 && (image.height ?? 0) > 0 ? image.width! / image.height! : 4 / 3;
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: GestureDetector(
        onTap: () => showDialog<void>(
          context: context,
          builder: (dialogContext) => Dialog.fullscreen(
            backgroundColor: Theme.of(dialogContext).colorScheme.scrim,
            child: Stack(
              children: [
                Positioned.fill(
                  child: InteractiveViewer(
                    child: MediaImage(url: image.url, fit: BoxFit.contain, radius: 0),
                  ),
                ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: IconButton.filledTonal(
                    tooltip: 'Đóng',
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(dialogContext),
                  ),
                ),
              ],
            ),
          ),
        ),
        child: AspectRatio(
          aspectRatio: ratio.clamp(0.75, 2.0),
          child: MediaImage(url: image.url, width: double.infinity),
        ),
      ),
    );
  }

  /// Thích, Lưu, Trả lời, Báo cáo (người hỏi chỉ thấy số lượt thích, không báo cáo câu của mình).
  Widget _actionBar(Question q, bool signedIn) {
    final locked = signedIn && !q.canInteract;
    final scheme = Theme.of(context).colorScheme;
    return Wrap(
      spacing: 8,
      runSpacing: 4,
      children: [
        if (q.isMine)
          Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: Text('♥ ${q.likeCount} lượt thích'))
        else
          OutlinedButton.icon(
            onPressed: locked ? null : () => _like(q),
            icon: Icon(q.liked ? Icons.favorite : Icons.favorite_border, color: q.liked ? scheme.primary : null),
            label: Text('Thích · ${q.likeCount}'),
          ),
        OutlinedButton.icon(
          onPressed: locked ? null : () => _save(q),
          icon: Icon(q.saved ? Icons.bookmark_added : Icons.bookmark_border),
          label: Text(q.saved ? 'Đã lưu' : 'Lưu'),
        ),
        if (q.isPublished)
          OutlinedButton.icon(
            onPressed: locked ? null : _focusAnswer,
            icon: const Icon(Icons.chat_bubble_outline),
            label: const Text('Trả lời'),
          ),
        if (!q.isMine && q.isPublished)
          OutlinedButton.icon(
            onPressed: locked ? null : () => _report(q),
            icon: const Icon(Icons.flag_outlined),
            label: const Text('Báo cáo'),
          ),
      ],
    );
  }

  /// Ô trả lời câu hỏi; khách thấy lời mời đăng nhập.
  Widget _answerForm(QuestionController c, Question q, bool signedIn) {
    final theme = Theme.of(context);
    if (!q.isPublished) {
      return Text('Câu hỏi chưa được đăng nên chưa nhận câu trả lời.', style: theme.textTheme.bodySmall);
    }
    // App còn nhớ đăng nhập nhưng server coi là khách: phiên trên server đã hết
    final expired = signedIn && !q.signedIn;
    if (!signedIn || expired) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  expired
                      ? 'Phiên đăng nhập đã hết. Đăng nhập lại để trả lời.'
                      : 'Đăng nhập để trả lời và thích câu hỏi.',
                ),
              ),
              FilledButton.icon(
                onPressed: expired ? _signInAgain : _signedIn,
                icon: const Icon(Icons.login),
                label: const Text('Đăng nhập'),
              ),
            ],
          ),
        ),
      );
    }
    if (!q.canInteract) {
      return Text('Tài khoản của bạn chỉ xem được, không trả lời được.', style: theme.textTheme.bodySmall);
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        TextField(
          controller: _answer,
          focusNode: _answerFocus,
          minLines: 3,
          maxLines: 8,
          maxLength: QuestionController.answerMax,
          decoration: InputDecoration(
            hintText: 'Viết câu trả lời của bạn',
            border: const OutlineInputBorder(),
            errorText: c.answerErrorFor(null),
            errorMaxLines: 3,
          ),
          onChanged: (_) => c.clearAnswerError(null),
        ),
        FilledButton.icon(
          onPressed: c.isSendingAnswer ? null : _sendAnswer,
          icon: const Icon(Icons.send),
          label: Text(c.isSendingAnswer ? 'Đang gửi…' : 'Gửi'),
        ),
      ],
    );
  }

  Widget _replyBox(QuestionController c, int parentId) {
    return Padding(
      padding: const EdgeInsets.only(top: 4, bottom: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          TextField(
            controller: _reply,
            autofocus: true,
            minLines: 2,
            maxLines: 6,
            maxLength: QuestionController.answerMax,
            decoration: InputDecoration(
              hintText: 'Viết câu trả lời cho bình luận này',
              border: const OutlineInputBorder(),
              errorText: c.answerErrorFor(parentId),
              errorMaxLines: 3,
            ),
            onChanged: (_) => c.clearAnswerError(parentId),
          ),
          Wrap(
            spacing: 8,
            children: [
              TextButton(onPressed: () => setState(() => _replyTo = null), child: const Text('Hủy')),
              FilledButton.icon(
                onPressed: c.isSendingAnswer ? null : () => _sendReply(parentId),
                icon: const Icon(Icons.send),
                label: const Text('Gửi'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _editBox(QuestionController c, int answerId) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          TextField(
            controller: _edit,
            autofocus: true,
            minLines: 2,
            maxLines: 8,
            maxLength: QuestionController.answerMax,
            decoration: InputDecoration(
              labelText: 'Sửa câu trả lời',
              border: const OutlineInputBorder(),
              errorText: c.answerErrors[answerId],
              errorMaxLines: 3,
            ),
            onChanged: (_) => c.clearAnswerError(answerId),
          ),
          Wrap(
            spacing: 8,
            children: [
              TextButton(onPressed: () => setState(() => _editing = null), child: const Text('Hủy')),
              FilledButton.icon(
                onPressed: c.isSendingAnswer ? null : () => _saveEdit(answerId),
                icon: const Icon(Icons.check),
                label: const Text('Lưu'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------- Thao tác

  /// Hiện câu thông báo của Controller (của server) một lần.
  void _flush() {
    if (mounted) {
      showMessage(context, _controller.takeMessage());
    }
  }

  /// Thao tác cần tài khoản: khách được đưa sang Đăng nhập; đăng nhập xong thì tải lại câu hỏi (quyền và trạng
  /// thái thích / lưu đổi theo người xem). Trả về true khi được làm tiếp.
  Future<bool> _signedIn() async {
    if (context.read<AuthController>().isSignedIn) {
      return true;
    }
    if (!await requireSignIn(context) || !mounted) {
      return false;
    }
    _userId = context.read<AuthController>().currentUser?.id;
    await _controller.loadQuestion(_id);
    return mounted;
  }

  /// Phiên trên server đã hết dù app còn nhớ người dùng: mở màn Đăng nhập, xong thì tải lại câu hỏi.
  Future<void> _signInAgain() async {
    final ok = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
    if (ok == true && mounted) {
      await _controller.loadQuestion(_id);
    }
  }

  bool get _isGuest => !context.read<AuthController>().isSignedIn;

  Future<void> _like(Question q) async {
    final wasGuest = _isGuest;
    if (!await _signedIn()) {
      return;
    }
    final now = _controller.questionOf(_id);
    // Vừa đăng nhập: không bỏ thích câu đã thích từ trước, không thích câu của chính mình
    if (now == null || now.isMine || !now.canInteract || (wasGuest && now.liked)) {
      return;
    }
    await _controller.toggleLike(_id);
    _flush();
  }

  Future<void> _save(Question q) async {
    final wasGuest = _isGuest;
    if (!await _signedIn()) {
      return;
    }
    final now = _controller.questionOf(_id);
    if (now == null || !now.canInteract || (wasGuest && now.saved)) {
      return;
    }
    await _controller.toggleSave(_id);
    _flush();
  }

  Future<void> _focusAnswer() async {
    if (!await _signedIn()) {
      return;
    }
    _answerFocus.requestFocus();
  }

  Future<void> _report(Question q) async {
    if (!await _signedIn()) {
      return;
    }
    final now = _controller.questionOf(_id);
    if (now == null || now.isMine || !mounted) {
      return;
    }
    final choice = await showReportDialog(context, reasons: now.reportReasons, title: 'Báo cáo câu hỏi');
    if (choice == null || !mounted) {
      return;
    }
    await _controller.reportQuestion(_id, choice.reasonId, choice.note);
    _flush();
  }

  Future<void> _editQuestion(Question q) async {
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => QuestionFormScreen(questionId: q.id)),
    );
    if (saved == true) {
      _flush();
    }
  }

  Future<void> _delete(Question q) async {
    final ok = await _confirm(
      title: 'Xóa câu hỏi?',
      text: 'Bạn có chắc muốn xóa câu hỏi này? Các câu trả lời cũng bị xóa, và điểm câu hỏi đã nhận sẽ bị thu lại.',
      action: 'Xóa',
    );
    if (!ok || !mounted) {
      return;
    }
    final deleted = await _controller.deleteQuestion(_id);
    _flush();
    if (deleted && mounted) {
      Navigator.pop(context);
    }
  }

  /// Nhắn tin riêng cho người hỏi / người trả lời.
  Future<void> _message(Author author) async {
    if (!await _signedIn() || !mounted) {
      return;
    }
    if (context.read<AuthController>().currentUser?.id == author.id) {
      return;
    }
    await Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (_) => ChatScreen(withUserId: author.id, title: author.displayName),
      ),
    );
  }

  Future<void> _sendAnswer() async {
    final sent = await _controller.sendAnswer(_id, _answer.text);
    if (sent && mounted) {
      _answer.clear();
      _answerFocus.unfocus();
      _flush();
    }
  }

  Future<void> _openReply(Answer answer) async {
    if (!await _signedIn() || !mounted) {
      return;
    }
    _reply.clear();
    _controller.clearAnswerError(answer.id);
    setState(() {
      _replyTo = answer.id;
      _editing = null;
    });
  }

  Future<void> _sendReply(int parentId) async {
    final sent = await _controller.sendAnswer(_id, _reply.text, parentId: parentId);
    if (sent && mounted) {
      _reply.clear();
      setState(() => _replyTo = null);
      _flush();
    }
  }

  void _openEdit(Answer answer) {
    _edit.text = answer.content;
    _controller.clearAnswerError(answer.id);
    setState(() {
      _editing = answer.id;
      _replyTo = null;
    });
  }

  Future<void> _saveEdit(int answerId) async {
    final saved = await _controller.updateAnswer(_id, answerId, _edit.text);
    if (saved && mounted) {
      setState(() => _editing = null);
      _flush();
    }
  }

  Future<void> _deleteAnswer(Answer answer) async {
    final ok = await _confirm(title: 'Xóa bình luận?', text: 'Bạn có chắc muốn xóa bình luận này?', action: 'Xóa');
    if (!ok || !mounted) {
      return;
    }
    await _controller.deleteAnswer(_id, answer.id);
    _flush();
  }

  Future<void> _likeAnswer(Answer answer) async {
    final wasGuest = _isGuest;
    if (!await _signedIn()) {
      return;
    }
    final now = Answer.find(_controller.questionOf(_id)?.answers ?? const [], answer.id);
    if (now == null || now.isMine || (wasGuest && now.liked)) {
      return;
    }
    await _controller.toggleAnswerLike(_id, answer.id);
    _flush();
  }

  Future<void> _reportAnswer(Answer answer) async {
    if (!await _signedIn() || !mounted) {
      return;
    }
    final q = _controller.questionOf(_id);
    final now = Answer.find(q?.answers ?? const [], answer.id);
    if (q == null || now == null || now.isMine) {
      return;
    }
    final choice = await showReportDialog(context, reasons: q.reportReasons, title: 'Báo cáo câu trả lời');
    if (choice == null || !mounted) {
      return;
    }
    await _controller.reportAnswer(_id, answer.id, choice.reasonId, choice.note);
    _flush();
  }

  Future<void> _chooseBest(Answer answer) async {
    final name = answer.author?.displayName ?? 'người trả lời';
    final ok = await _confirm(
      title: 'Chọn câu trả lời hay nhất?',
      text: 'Câu trả lời của $name sẽ hiện đầu tiên với nhãn “Câu trả lời hay nhất”. Người trả lời được +5 điểm.',
      action: 'Chọn',
    );
    if (!ok || !mounted) {
      return;
    }
    await _controller.chooseBest(_id, answer.id);
    _flush();
  }

  Future<bool> _confirm({required String title, required String text, required String action}) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(title),
        content: Text(text),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: Text(action)),
        ],
      ),
    );
    return ok == true;
  }
}
