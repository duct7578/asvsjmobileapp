import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// Lời mời đăng nhập cho các màn hình cá nhân khi người xem là khách (Tôi, Đã lưu, Lịch sử điểm…).
/// Đăng nhập xong, màn hình tự tải dữ liệu vì nó theo dõi AuthController.
class ProfileSignInPrompt extends StatelessWidget {
  const ProfileSignInPrompt({super.key, this.text = 'Đăng nhập để dùng mục này.'});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.account_circle_outlined, size: 48, color: Theme.of(context).colorScheme.outline),
            const SizedBox(height: 12),
            Text(text, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: () => requireSignIn(context),
              icon: const Icon(Icons.login),
              label: const Text('Đăng nhập'),
            ),
          ],
        ),
      ),
    );
  }
}
