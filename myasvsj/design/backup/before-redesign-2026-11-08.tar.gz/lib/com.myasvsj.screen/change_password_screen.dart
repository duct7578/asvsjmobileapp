import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/auth_notice.dart';
import 'package:myasvsj/com.myasvsj.screen/auth_required_view.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/password_field.dart';
import 'package:myasvsj/com.myasvsj.screen/password_rules.dart';

/// "Đổi mật khẩu" (UC-U06) ở trang Tôi; tài khoản tạo bằng Google/Facebook chưa có mật khẩu thì là "Tạo mật khẩu".
/// Lưu xong thì đóng, trả về true và hiện câu của server ("Đã đổi mật khẩu.").
class ChangePasswordScreen extends StatefulWidget {
  const ChangePasswordScreen({super.key});

  @override
  State<ChangePasswordScreen> createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  final _current = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();

  /// Người dùng đã hỏi trạng thái mật khẩu; đổi khi vừa đăng nhập (từ nút "Đăng nhập" của màn này).
  int? _loadedFor;

  void _load() {
    if (!mounted) {
      return;
    }
    final auth = context.read<AuthController>();
    if (auth.isSignedIn) {
      auth.loadPasswordStatus();
    }
  }

  @override
  void dispose() {
    _current.dispose();
    _password.dispose();
    _confirm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    final userId = auth.currentUser?.id;
    if (userId != null && userId != _loadedFor) {
      _loadedFor = userId;
      // Gọi sau khung hình: notifyListeners() không được chạy giữa lúc đang dựng giao diện
      WidgetsBinding.instance.addPostFrameCallback((_) => _load());
    }
    return Scaffold(
      appBar: AppBar(title: Text(auth.hasPassword == false ? 'Tạo mật khẩu' : 'Đổi mật khẩu')),
      body: _body(auth),
    );
  }

  Widget _body(AuthController auth) {
    if (!auth.isSignedIn) {
      return const AuthRequiredView(text: 'Bạn cần đăng nhập để đổi mật khẩu.');
    }
    final hasPassword = auth.hasPassword;
    if (hasPassword == null) {
      if (auth.error != null && !auth.isLoading) {
        return ErrorView(message: auth.error!, onRetry: _load);
      }
      return const LoadingView();
    }
    final errors = auth.fieldErrors;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(
          hasPassword
              ? 'Đổi mật khẩu sẽ đăng xuất bạn khỏi các thiết bị khác.'
              : 'Tài khoản này đăng nhập bằng Google/Facebook. Tạo mật khẩu để đăng nhập được cả bằng email.',
        ),
        const SizedBox(height: 16),
        if (auth.bannerError != null) AuthNotice(text: auth.bannerError!),
        if (hasPassword) ...[
          PasswordField(
            controller: _current,
            label: 'Mật khẩu hiện tại',
            errorText: errors['currentPassword'],
            textInputAction: TextInputAction.next,
          ),
          const SizedBox(height: 12),
        ],
        PasswordField(
          controller: _password,
          label: 'Mật khẩu mới',
          isNewPassword: true,
          errorText: errors['password'],
          textInputAction: TextInputAction.next,
        ),
        const SizedBox(height: 4),
        PasswordRules(controller: _password),
        const SizedBox(height: 12),
        PasswordField(
          controller: _confirm,
          label: 'Nhập lại mật khẩu mới',
          isNewPassword: true,
          errorText: errors['confirmPassword'],
          textInputAction: TextInputAction.done,
          onSubmitted: (_) => _save(),
        ),
        const SizedBox(height: 16),
        FilledButton(
          onPressed: auth.isLoading ? null : _save,
          child: Text(auth.isLoading ? 'Đang lưu…' : 'Lưu mật khẩu'),
        ),
      ],
    );
  }

  Future<void> _save() async {
    final auth = context.read<AuthController>();
    final ok = await auth.changePassword(
      currentPassword: _current.text,
      password: _password.text,
      confirmPassword: _confirm.text,
    );
    if (ok && mounted) {
      showMessage(context, auth.takeMessage());
      Navigator.pop(context, true);
    }
  }
}
