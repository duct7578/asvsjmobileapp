import 'package:flutter/material.dart';

/// Ô viết bình luận ở cuối màn chi tiết bài. Khi đang trả lời một bình luận, hiện "Đang trả lời Tên" có nút hủy.
/// Lỗi của server (ví dụ "Bạn bình luận hơi nhanh…") hiện ngay dưới ô, chữ đang viết vẫn được giữ.
class BlogCommentBar extends StatelessWidget {
  const BlogCommentBar({
    super.key,
    required this.controller,
    required this.focusNode,
    required this.onSend,
    required this.onCancelReply,
    this.replyName,
    this.isSending = false,
    this.error,
    this.maxLength = 2000,
    this.onChanged,
  });

  final TextEditingController controller;
  final FocusNode focusNode;
  final VoidCallback onSend;
  final VoidCallback onCancelReply;

  /// Tên người được trả lời; null khi viết bình luận mới.
  final String? replyName;
  final bool isSending;
  final String? error;
  final int maxLength;
  final ValueChanged<String>? onChanged;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Material(
      elevation: 3,
      color: theme.colorScheme.surfaceContainer,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 6, 4, 6),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (replyName != null)
                Row(
                  children: [
                    const Icon(Icons.reply, size: 16),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        'Đang trả lời $replyName',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.bodySmall,
                      ),
                    ),
                    IconButton(
                      tooltip: 'Hủy trả lời',
                      visualDensity: VisualDensity.compact,
                      icon: const Icon(Icons.close, size: 18),
                      onPressed: onCancelReply,
                    ),
                  ],
                ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: TextField(
                      controller: controller,
                      focusNode: focusNode,
                      minLines: 1,
                      maxLines: 4,
                      maxLength: maxLength,
                      onChanged: onChanged,
                      textCapitalization: TextCapitalization.sentences,
                      decoration: InputDecoration(
                        hintText: replyName != null
                            ? 'Viết câu trả lời cho bình luận này'
                            : 'Chia sẻ thêm kinh nghiệm hoặc góp ý',
                        counterText: '',
                        isDense: true,
                        border: const OutlineInputBorder(),
                        errorText: error,
                        errorMaxLines: 3,
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Gửi bình luận',
                    onPressed: isSending ? null : onSend,
                    icon: isSending
                        ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.send),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
