import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/blog.dart';
import 'package:myasvsj/com.myasvsj.model/topic.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_author_line.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_badge.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';

/// Một bài trong danh sách Blog; bấm vào mở màn chi tiết.
///
/// [onTopicTap]: bấm chủ đề trên thẻ để lọc theo chủ đề đó (màn danh sách Blog); null thì chủ đề chỉ để xem.
class BlogCard extends StatelessWidget {
  const BlogCard({super.key, required this.blog, this.onTopicTap});

  final Blog blog;
  final ValueChanged<Topic>? onTopicTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final muted = theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant);
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: blog.id == null
            ? null
            : () =>
                  Navigator.push(context, MaterialPageRoute<void>(builder: (_) => BlogDetailScreen(blogId: blog.id!))),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  if (blog.pinned) ...[
                    const BlogBadge(icon: Icons.push_pin_outlined, label: 'Đã ghim'),
                    const SizedBox(width: 6),
                  ],
                  if (blog.isProcessing) ...[
                    const Flexible(
                      child: BlogBadge(icon: Icons.hourglass_top, label: 'Đang quét ảnh', warning: true),
                    ),
                    const SizedBox(width: 6),
                  ],
                  const Spacer(),
                  if (blog.createdAt != null) Text(formatTimeAgo(blog.createdAt!), style: muted),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                blog.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
              ),
              if (blog.content.isNotEmpty) ...[
                const SizedBox(height: 4),
                Text(blog.content, maxLines: 3, overflow: TextOverflow.ellipsis, style: theme.textTheme.bodyMedium),
              ],
              if (blog.topics.isNotEmpty || blog.places.isNotEmpty) ...[
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    for (final topic in blog.topics) _topicChip(context, topic),
                    for (final place in blog.places)
                      _smallChip(context, icon: Icons.location_on_outlined, label: place.name),
                  ],
                ),
              ],
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(child: BlogAuthorLine(author: blog.author, dense: true)),
                  const SizedBox(width: 8),
                  Icon(Icons.favorite_border, size: 16, color: theme.colorScheme.onSurfaceVariant),
                  const SizedBox(width: 2),
                  Text('${blog.likeCount}', style: muted),
                  const SizedBox(width: 10),
                  Icon(Icons.chat_bubble_outline, size: 16, color: theme.colorScheme.onSurfaceVariant),
                  const SizedBox(width: 2),
                  Text('${blog.commentCount}', style: muted),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _topicChip(BuildContext context, Topic topic) {
    final chip = _smallChip(context, icon: Icons.sell_outlined, label: topic.name);
    final onTap = onTopicTap;
    if (onTap == null) {
      return chip;
    }
    return Tooltip(
      message: 'Lọc theo chủ đề này',
      child: InkWell(borderRadius: BorderRadius.circular(12), onTap: () => onTap(topic), child: chip),
    );
  }

  static Widget _smallChip(BuildContext context, {required IconData icon, required String label}) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: scheme.surfaceContainerHigh, borderRadius: BorderRadius.circular(12)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: scheme.onSurfaceVariant),
          const SizedBox(width: 3),
          Flexible(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.labelSmall,
            ),
          ),
        ],
      ),
    );
  }
}
