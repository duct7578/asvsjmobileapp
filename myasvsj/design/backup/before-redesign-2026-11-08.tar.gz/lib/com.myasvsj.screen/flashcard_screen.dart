import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/phrase_controller.dart';
import 'package:myasvsj/com.myasvsj.model/phrase.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/empty_view.dart';
import 'package:myasvsj/com.myasvsj.screen/phrase_list_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// "Thẻ ghi nhớ": lượt thẻ PhraseController đã bắt đầu (startFlash / startPractice). Bấm thẻ để lật, rồi chọn
/// "Chưa thuộc" hoặc "Đã thuộc". Thành viên được lưu câu trả lời; khách lật được nhưng không lưu (có nút Đăng nhập).
/// Hết lượt: "Xong n thẻ", "Luyện lại N thẻ chưa thuộc", "Xem danh sách Chưa thuộc".
class FlashcardScreen extends StatefulWidget {
  const FlashcardScreen({super.key, this.fromLearningList = false});

  /// Mở từ danh sách "Chưa thuộc": cuối lượt không cần nút "Xem danh sách Chưa thuộc".
  final bool fromLearningList;

  @override
  State<FlashcardScreen> createState() => _FlashcardScreenState();
}

class _FlashcardScreenState extends State<FlashcardScreen> {
  late final PhraseController _phrases;
  int? _userId;

  @override
  void initState() {
    super.initState();
    _phrases = context.read<PhraseController>();
    _userId = context.read<AuthController>().currentUser?.id;
  }

  @override
  void dispose() {
    _phrases.stopSpeaking();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Khách vừa đăng nhập ở giữa lượt: đọc lại trang đầu để biết đã là thành viên, các thẻ sau được lưu
    final userId = context.select<AuthController, int?>((a) => a.currentUser?.id);
    if (userId != _userId) {
      _userId = userId;
      WidgetsBinding.instance.addPostFrameCallback((_) => _phrases.loadOverview());
    }
    final phrases = context.watch<PhraseController>();
    final card = phrases.currentCard;
    final total = phrases.flashCards.length;
    return Scaffold(
      appBar: AppBar(title: Text(card == null ? 'Thẻ ghi nhớ' : 'Thẻ ghi nhớ · ${phrases.flashIndex + 1}/$total')),
      body: total == 0
          ? const EmptyView(text: 'Không có thẻ nào để luyện.', icon: Icons.style_outlined)
          : card == null
          ? _done(phrases)
          : _card(phrases, card),
    );
  }

  Widget _card(PhraseController phrases, Phrase card) {
    final theme = Theme.of(context);
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            LinearProgressIndicator(value: phrases.flashIndex / phrases.flashCards.length),
            if (!phrases.isMember) ...[const SizedBox(height: 12), _guestNote(context)],
            const SizedBox(height: 16),
            Expanded(
              child: Card(
                clipBehavior: Clip.antiAlias,
                child: InkWell(
                  onTap: phrases.flip,
                  child: Center(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        children: [
                          Text(
                            card.japanese,
                            locale: const Locale('ja'),
                            textAlign: TextAlign.center,
                            style: theme.textTheme.headlineLarge,
                          ),
                          const SizedBox(height: 16),
                          if (phrases.isFlipped) ...[
                            if (card.romaji.isNotEmpty)
                              Text(
                                card.romaji,
                                textAlign: TextAlign.center,
                                style: theme.textTheme.titleMedium?.copyWith(color: theme.colorScheme.outline),
                              ),
                            const SizedBox(height: 8),
                            Text(card.meaningVi, textAlign: TextAlign.center, style: theme.textTheme.titleLarge),
                          ] else
                            Text(
                              'Bấm để lật thẻ',
                              style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.outline),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Wrap(
              alignment: WrapAlignment.center,
              crossAxisAlignment: WrapCrossAlignment.center,
              spacing: 12,
              children: [
                if (card.learned)
                  const Chip(avatar: Icon(Icons.check_circle_outline), label: Text('Đã thuộc'))
                else if (card.learning)
                  const Chip(avatar: Icon(Icons.replay), label: Text('Chưa thuộc')),
                OutlinedButton.icon(
                  onPressed: () => _speak(card),
                  icon: const Icon(Icons.volume_up_outlined),
                  label: const Text('Nghe'),
                ),
              ],
            ),
            if (phrases.isFlipped) ...[
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: phrases.isAnswering ? null : () => _answer(learned: false),
                      icon: const Icon(Icons.replay),
                      label: const Text('Chưa thuộc'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: phrases.isAnswering ? null : () => _answer(learned: true),
                      icon: const Icon(Icons.task_alt),
                      label: const Text('Đã thuộc'),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  /// Khách: lật được nhưng không lưu; nói rõ và mời đăng nhập.
  Widget _guestNote(BuildContext context) {
    final signedIn = context.select<AuthController, bool>((a) => a.isSignedIn);
    return Card(
      color: Theme.of(context).colorScheme.surfaceContainerHighest,
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
        child: Row(
          children: [
            const Icon(Icons.info_outline),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                signedIn
                    ? 'Kết quả không được lưu với tài khoản này.'
                    : 'Bạn đang luyện với tư cách khách: kết quả lật thẻ không được lưu.',
              ),
            ),
            if (!signedIn) TextButton(onPressed: () => requireSignIn(context), child: const Text('Đăng nhập')),
          ],
        ),
      ),
    );
  }

  Widget _done(PhraseController phrases) {
    final theme = Theme.of(context);
    final learning = phrases.learningIds.length;
    final signedIn = context.select<AuthController, bool>((a) => a.isSignedIn);
    final String note;
    if (phrases.isMember) {
      note = 'Đã lưu vào danh sách "Chưa thuộc" và "Đã thuộc" của bạn.';
    } else if (signedIn) {
      note = 'Kết quả không được lưu với tài khoản này.';
    } else {
      note = 'Đăng nhập để lưu kết quả lần sau.';
    }
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Icon(Icons.celebration_outlined, size: 56, color: theme.colorScheme.primary),
        const SizedBox(height: 12),
        Text(
          'Xong ${phrases.flashCards.length} thẻ',
          textAlign: TextAlign.center,
          style: theme.textTheme.headlineSmall,
        ),
        const SizedBox(height: 8),
        Text(
          'Đã thuộc: ${phrases.learnedIds.length} · Chưa thuộc: $learning',
          textAlign: TextAlign.center,
          style: theme.textTheme.titleMedium,
        ),
        const SizedBox(height: 8),
        Text(note, textAlign: TextAlign.center),
        if (!signedIn)
          Center(
            child: TextButton(onPressed: () => requireSignIn(context), child: const Text('Đăng nhập')),
          ),
        const SizedBox(height: 24),
        if (learning > 0)
          FilledButton.icon(
            onPressed: phrases.againLearning,
            icon: const Icon(Icons.replay),
            label: Text('Luyện lại $learning thẻ chưa thuộc'),
          ),
        if (phrases.isMember && learning > 0 && !widget.fromLearningList) ...[
          const SizedBox(height: 8),
          OutlinedButton(onPressed: _openLearningList, child: const Text('Xem danh sách Chưa thuộc')),
        ],
        const SizedBox(height: 8),
        OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('Xong')),
      ],
    );
  }

  Future<void> _answer({required bool learned}) async {
    await _phrases.answer(learned: learned);
    if (mounted) {
      showMessage(context, _phrases.takeMessage());
    }
  }

  Future<void> _speak(Phrase card) async {
    final spoken = await _phrases.speak(card.japanese);
    if (!spoken && mounted) {
      showMessage(context, _phrases.takeMessage());
    }
  }

  void _openLearningList() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute<void>(builder: (_) => const PhraseListScreen(mine: 'learning')),
    );
  }
}
