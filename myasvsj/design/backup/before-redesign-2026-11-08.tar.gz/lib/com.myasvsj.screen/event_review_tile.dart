import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/event_review.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';
import 'package:myasvsj/com.myasvsj.screen/event_photo_viewer.dart';
import 'package:myasvsj/com.myasvsj.screen/event_stars.dart';
import 'package:myasvsj/com.myasvsj.screen/media_image.dart';

/// Một review sự kiện: tác giả, tag, cấp bậc, năm, số sao, nội dung, ảnh và các nút.
///
/// - [canAct]: hiện "Thích" và "Báo cáo" (review đã đăng của người khác; khách cũng thấy, bấm thì đăng nhập).
/// - Review của chính mình ([EventReview.mine]) có "Sửa" (khi [canEdit]) và "Xóa", kèm câu trạng thái khi
///   review chưa hiện với người khác.
class EventReviewTile extends StatelessWidget {
  const EventReviewTile({
    super.key,
    required this.review,
    this.canAct = false,
    this.canEdit = false,
    this.liking = false,
    this.onLike,
    this.onReport,
    this.onEdit,
    this.onDelete,
  });

  final EventReview review;
  final bool canAct;
  final bool canEdit;

  /// Đang chờ server trả lời lượt thích: khóa nút.
  final bool liking;
  final VoidCallback? onLike;
  final VoidCallback? onReport;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final author = review.author;
    final name = author?.displayName ?? 'Người dùng';
    final note = review.mine ? review.statusNote : null;
    final images = review.images;
    final created = review.createdAt;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (note != null)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: theme.colorScheme.tertiaryContainer,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(note, style: TextStyle(color: theme.colorScheme.onTertiaryContainer)),
            ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(radius: 18, child: Text(name.isEmpty ? '?' : name.characters.first.toUpperCase())),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name, style: theme.textTheme.titleSmall, maxLines: 1, overflow: TextOverflow.ellipsis),
                    Wrap(
                      spacing: 6,
                      runSpacing: 2,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        for (final tag in author?.tagNames ?? const <String>[]) _label(context, tag),
                        if (author != null && author.rankName.isNotEmpty) _label(context, author.rankName),
                        _label(context, 'Năm ${review.year}'),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              EventStars(rating: review.rating.toDouble()),
              if (created != null) Text(formatTimeAgo(created), style: theme.textTheme.bodySmall),
              if (review.edited) Text('· đã sửa', style: theme.textTheme.bodySmall),
            ],
          ),
          const SizedBox(height: 6),
          Text(review.content, style: theme.textTheme.bodyMedium),
          if (images.isNotEmpty) ...[
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                for (var i = 0; i < images.length; i++)
                  InkWell(
                    onTap: () => showEventPhotos(
                      context,
                      photos: [for (final m in images) (url: m.url, caption: name)],
                      initialIndex: i,
                    ),
                    child: MediaImage(url: images[i].url, width: 88, height: 88),
                  ),
              ],
            ),
          ],
          const SizedBox(height: 4),
          Wrap(
            spacing: 4,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              if (canAct) ...[
                TextButton.icon(
                  onPressed: liking ? null : onLike,
                  icon: Icon(review.liked ? Icons.thumb_up : Icons.thumb_up_outlined, size: 18),
                  label: Text('Thích · ${review.likeCount}'),
                ),
                TextButton.icon(
                  onPressed: onReport,
                  icon: const Icon(Icons.flag_outlined, size: 18),
                  label: const Text('Báo cáo'),
                ),
              ] else
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.thumb_up_outlined, size: 16, color: theme.colorScheme.onSurfaceVariant),
                      const SizedBox(width: 4),
                      Text('${review.likeCount}', style: theme.textTheme.bodySmall),
                    ],
                  ),
                ),
              if (review.mine) ...[
                if (canEdit)
                  TextButton.icon(
                    onPressed: onEdit,
                    icon: const Icon(Icons.edit_outlined, size: 18),
                    label: const Text('Sửa'),
                  ),
                TextButton.icon(
                  onPressed: onDelete,
                  icon: Icon(Icons.delete_outline, size: 18, color: theme.colorScheme.error),
                  label: Text('Xóa', style: TextStyle(color: theme.colorScheme.error)),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }

  Widget _label(BuildContext context, String text) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
      decoration: BoxDecoration(color: theme.colorScheme.secondaryContainer, borderRadius: BorderRadius.circular(6)),
      child: Text(text, style: theme.textTheme.labelSmall?.copyWith(color: theme.colorScheme.onSecondaryContainer)),
    );
  }
}
