import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/chat_controller.dart';
import 'package:myasvsj/com.myasvsj.model/conversation_item.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/chat_avatar.dart';
import 'package:myasvsj/com.myasvsj.screen/chat_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/conversation_tile.dart';
import 'package:myasvsj/com.myasvsj.screen/empty_view.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// Màn hình "Tin nhắn" (trang `/messages` của web): hai hộp "Tin nhắn" và "Lời mời", kéo xuống làm mới, tự cập nhật
/// khi có tin mới (luồng tức thì). Nút "Người đã chặn" mở danh sách để bỏ chặn.
class ConversationListScreen extends StatefulWidget {
  const ConversationListScreen({super.key});

  @override
  State<ConversationListScreen> createState() => _ConversationListScreenState();
}

class _ConversationListScreenState extends State<ConversationListScreen> {
  int? _loadedFor;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    final chat = context.watch<ChatController>();
    final userId = auth.currentUser?.id;
    if (userId != null && userId != _loadedFor) {
      _loadedFor = userId;
      WidgetsBinding.instance.addPostFrameCallback((_) => _loadBoth());
    }
    if (!auth.isSignedIn) {
      return Scaffold(
        appBar: AppBar(title: const Text('Tin nhắn')),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const EmptyView(text: 'Đăng nhập để nhắn tin với thành viên khác.', icon: Icons.forum_outlined),
              FilledButton(onPressed: () => requireSignIn(context), child: const Text('Đăng nhập')),
            ],
          ),
        ),
      );
    }
    final requests = chat.counts.requests;
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Tin nhắn'),
          actions: [IconButton(tooltip: 'Người đã chặn', icon: const Icon(Icons.block), onPressed: _openBlocks)],
          bottom: TabBar(
            tabs: [
              const Tab(text: 'Tin nhắn'),
              Tab(
                child: Badge(
                  isLabelVisible: requests > 0,
                  label: Text(requests > 99 ? '99+' : '$requests'),
                  offset: const Offset(14, -4),
                  child: const Text('Lời mời'),
                ),
              ),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _BoxView(box: ChatController.inbox, onOpen: _openConversation),
            _BoxView(box: ChatController.requests, onOpen: _openConversation),
          ],
        ),
      ),
    );
  }

  void _loadBoth() {
    if (!mounted) {
      return;
    }
    final chat = context.read<ChatController>();
    chat.loadConversations(ChatController.inbox);
    chat.loadConversations(ChatController.requests);
  }

  Future<void> _openConversation(ConversationItem item) async {
    await Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (_) => ChatScreen(conversationId: item.id, title: item.peer.displayName),
      ),
    );
    // Quay về: số chưa đọc, lời mời đã trả lời, cuộc trò chuyện đã xóa
    _loadBoth();
  }

  void _openBlocks() {
    context.read<ChatController>().loadBlocks();
    showModalBottomSheet<void>(context: context, showDragHandle: true, builder: (_) => const _BlocksSheet());
  }
}

/// Một hộp thư: danh sách, trạng thái chờ / lỗi / rỗng, "Xem thêm".
class _BoxView extends StatelessWidget {
  const _BoxView({required this.box, required this.onOpen});

  final String box;
  final ValueChanged<ConversationItem> onOpen;

  @override
  Widget build(BuildContext context) {
    final chat = context.watch<ChatController>();
    final items = chat.conversationsOf(box);
    final error = chat.errorOf(box);
    if (chat.isLoadingOf(box) && items.isEmpty) {
      return const LoadingView();
    }
    if (error != null && items.isEmpty) {
      return ErrorView(message: error, onRetry: () => chat.loadConversations(box));
    }
    final hasMore = chat.hasMoreOf(box);
    return RefreshIndicator(
      onRefresh: () => chat.loadConversations(box),
      child: items.isEmpty
          ? ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [EmptyView(text: _emptyText(chat), icon: Icons.forum_outlined)],
            )
          : ListView.separated(
              physics: const AlwaysScrollableScrollPhysics(),
              itemCount: items.length + (hasMore ? 1 : 0),
              separatorBuilder: (_, _) => const Divider(height: 1, indent: 72),
              itemBuilder: (context, i) {
                if (i < items.length) {
                  return ConversationTile(item: items[i], onTap: () => onOpen(items[i]));
                }
                return Padding(
                  padding: const EdgeInsets.all(16),
                  child: Center(
                    child: OutlinedButton(
                      onPressed: chat.isLoadingMoreOf(box) ? null : () => _loadMore(context, chat),
                      child: Text(chat.isLoadingMoreOf(box) ? 'Đang tải…' : 'Xem thêm'),
                    ),
                  ),
                );
              },
            ),
    );
  }

  Future<void> _loadMore(BuildContext context, ChatController chat) async {
    await chat.loadMoreConversations(box);
    if (context.mounted) {
      showMessage(context, chat.takeMessage());
    }
  }

  /// Câu "chưa có gì" của trang web.
  String _emptyText(ChatController chat) {
    if (box == ChatController.requests) {
      return 'Không có lời mời nhắn tin nào. Tin nhắn đầu tiên của người chưa từng trò chuyện với bạn sẽ nằm ở đây.';
    }
    final requests = chat.counts.requests;
    return requests > 0
        ? 'Chưa có cuộc trò chuyện nào. Bạn có $requests lời mời nhắn tin đang chờ ở mục “Lời mời”.'
        : 'Chưa có cuộc trò chuyện nào. Muốn hỏi thêm ai đó, bấm “Nhắn tin” cạnh tên họ ở Blog hoặc Hỏi-Đáp.';
  }
}

/// "Người đã chặn" với nút "Bỏ chặn".
class _BlocksSheet extends StatelessWidget {
  const _BlocksSheet();

  @override
  Widget build(BuildContext context) {
    final chat = context.watch<ChatController>();
    final Widget content;
    if (chat.isLoadingBlocks && chat.blocked.isEmpty) {
      content = const Padding(padding: EdgeInsets.all(24), child: LoadingView());
    } else if (chat.blocksError != null) {
      content = ErrorView(message: chat.blocksError!, onRetry: chat.loadBlocks);
    } else if (chat.blocked.isEmpty) {
      content = const EmptyView(text: 'Bạn chưa chặn ai.', icon: Icons.block);
    } else {
      content = ListView(
        shrinkWrap: true,
        children: [
          for (final member in chat.blocked)
            ListTile(
              leading: ChatAvatar(name: member.peer.displayName, url: member.peer.avatarUrl),
              title: Text(member.peer.displayName, maxLines: 1, overflow: TextOverflow.ellipsis),
              trailing: OutlinedButton(
                onPressed: () async {
                  await chat.unblock(member);
                  if (context.mounted) {
                    showMessage(context, chat.takeMessage());
                  }
                },
                child: const Text('Bỏ chặn'),
              ),
            ),
        ],
      );
    }
    return SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Text('Người đã chặn', style: Theme.of(context).textTheme.titleMedium),
          ),
          Flexible(child: content),
        ],
      ),
    );
  }
}
