import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/event.dart';
import 'package:myasvsj/com.myasvsj.screen/media_image.dart';

/// Ảnh bìa của sự kiện, có nhãn trạng thái ("Đang diễn ra", "Còn 12 ngày", "Đã qua") ở góc.
/// Sự kiện không có ảnh bìa hiện ô màu theme với biểu tượng lễ hội (web vẽ hình minh họa).
class EventCover extends StatelessWidget {
  const EventCover({super.key, required this.event, this.height = 140, this.radius = 0, this.showState = true});

  final Event event;
  final double height;
  final double radius;
  final bool showState;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final cover = event.coverUrl;
    return SizedBox(
      height: height,
      width: double.infinity,
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (cover != null && cover.isNotEmpty)
            MediaImage(url: cover, height: height, radius: radius)
          else
            ClipRRect(
              borderRadius: BorderRadius.circular(radius),
              child: ColoredBox(
                color: scheme.primaryContainer,
                child: Icon(Icons.festival_outlined, size: height / 2.5, color: scheme.onPrimaryContainer),
              ),
            ),
          if (showState)
            Positioned(
              left: 8,
              top: 8,
              child: Chip(
                visualDensity: VisualDensity.compact,
                avatar: Icon(event.isNow ? Icons.celebration : Icons.schedule, size: 16),
                label: Text(event.stateLabel),
                backgroundColor: event.isNow ? scheme.secondaryContainer : scheme.surface,
              ),
            ),
        ],
      ),
    );
  }
}
