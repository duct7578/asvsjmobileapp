import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/blog_place.dart';

/// Ô "Địa điểm liên quan" của form viết bài: tìm địa điểm (Senpai ơi và OpenStreetMap), bấm kết quả để gắn,
/// tối đa [max] địa điểm; địa điểm đã gắn hiện thành chip có nút bỏ.
class BlogPlacePicker extends StatefulWidget {
  const BlogPlacePicker({
    super.key,
    required this.selected,
    required this.results,
    required this.onSearch,
    required this.onAdd,
    required this.onRemove,
    this.max = 5,
    this.isSearching = false,
    this.message,
    this.errorText,
  });

  final List<BlogPlace> selected;
  final List<BlogPlace> results;
  final ValueChanged<String> onSearch;
  final ValueChanged<BlogPlace> onAdd;
  final ValueChanged<BlogPlace> onRemove;
  final int max;
  final bool isSearching;

  /// Câu dưới ô tìm, ví dụ "Không tìm thấy địa điểm nào." hoặc lỗi của server.
  final String? message;

  /// Lỗi theo ô từ server (`placeIds`).
  final String? errorText;

  @override
  State<BlogPlacePicker> createState() => _BlogPlacePickerState();
}

class _BlogPlacePickerState extends State<BlogPlacePicker> {
  final _query = TextEditingController();

  @override
  void dispose() {
    _query.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final full = widget.selected.length >= widget.max;
    final chosen = {for (final p in widget.selected) p.key};
    final results = [
      for (final p in widget.results)
        if (!chosen.contains(p.key)) p,
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Địa điểm liên quan (${widget.selected.length}/${widget.max})', style: theme.textTheme.titleSmall),
        if (widget.selected.isNotEmpty)
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              for (final place in widget.selected)
                InputChip(
                  avatar: Icon(place.isNew ? Icons.travel_explore : Icons.location_on_outlined, size: 18),
                  label: Text(place.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                  deleteButtonTooltipMessage: 'Bỏ địa điểm ${place.name}',
                  onDeleted: () => widget.onRemove(place),
                ),
            ],
          ),
        const SizedBox(height: 4),
        TextField(
          controller: _query,
          enabled: !full,
          maxLength: 100,
          textInputAction: TextInputAction.search,
          onSubmitted: widget.onSearch,
          decoration: InputDecoration(
            hintText: full ? 'Đã chọn đủ ${widget.max} địa điểm' : 'Tìm địa điểm (không bắt buộc)',
            prefixIcon: const Icon(Icons.location_on_outlined),
            counterText: '',
            isDense: true,
            errorText: widget.errorText,
            suffixIcon: IconButton(
              tooltip: 'Tìm địa điểm',
              icon: const Icon(Icons.search),
              onPressed: full ? null : () => widget.onSearch(_query.text),
            ),
          ),
        ),
        if (widget.isSearching) const LinearProgressIndicator(),
        if (widget.message != null && !widget.isSearching)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(widget.message!, style: theme.textTheme.bodySmall),
          ),
        if (!full)
          for (final place in results)
            ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              leading: Icon(place.isNew ? Icons.travel_explore : Icons.location_on_outlined),
              title: Text(place.name, maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text(
                [if (place.isNew) 'OpenStreetMap', place.detail].where((s) => s.isNotEmpty).join(' · '),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              trailing: const Icon(Icons.add),
              onTap: () {
                _query.clear();
                widget.onAdd(place);
              },
            ),
      ],
    );
  }
}
