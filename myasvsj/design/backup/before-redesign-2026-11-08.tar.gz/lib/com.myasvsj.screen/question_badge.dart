import 'package:flutter/material.dart';

/// Nhãn nhỏ có biểu tượng trên câu hỏi / câu trả lời: "Đã giải quyết", "Chưa ai trả lời", "Đã ghim",
/// "Câu trả lời hay nhất", tag và cấp bậc của người viết…
///
/// Màu lấy từ theme: [background] / [foreground] mặc định là màu nền phụ của theme.
class QuestionBadge extends StatelessWidget {
  const QuestionBadge({super.key, required this.label, this.icon, this.background, this.foreground});

  final String label;
  final IconData? icon;
  final Color? background;
  final Color? foreground;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final fg = foreground ?? scheme.onSurfaceVariant;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: background ?? scheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[Icon(icon, size: 14, color: fg), const SizedBox(width: 4)],
          Flexible(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.labelSmall?.copyWith(color: fg),
            ),
          ),
        ],
      ),
    );
  }
}
