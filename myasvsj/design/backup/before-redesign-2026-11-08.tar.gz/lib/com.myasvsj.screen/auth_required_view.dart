import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.screen/login_screen.dart';

/// Thân màn hình khi việc này cần đăng nhập mà người dùng là khách (hoặc phiên vừa hết): câu giải thích và nút
/// "Đăng nhập".
class AuthRequiredView extends StatelessWidget {
  const AuthRequiredView({super.key, required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.lock_outline, size: 40, color: Theme.of(context).colorScheme.outline),
            const SizedBox(height: 12),
            Text(text, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute<bool>(builder: (_) => const LoginScreen())),
              child: const Text('Đăng nhập'),
            ),
          ],
        ),
      ),
    );
  }
}
