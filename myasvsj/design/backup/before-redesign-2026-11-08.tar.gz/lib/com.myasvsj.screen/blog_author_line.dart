import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/author.dart';

/// Người viết bài hoặc bình luận: chữ cái đầu, tên, tag định danh và (khi [showRank]) cấp bậc.
///
/// [dense]: một dòng, chỉ tag đầu tiên (thẻ trong danh sách); ngược lại xuống dòng khi hẹp (màn chi tiết).
class BlogAuthorLine extends StatelessWidget {
  const BlogAuthorLine({super.key, required this.author, this.dense = false, this.showRank = false});

  final Author? author;
  final bool dense;
  final bool showRank;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final name = author?.displayName ?? '';
    final shown = name.isEmpty ? 'Tài khoản đã xóa' : name;
    final avatar = CircleAvatar(
      radius: dense ? 11 : 14,
      child: Text(shown.characters.first.toUpperCase(), style: TextStyle(fontSize: dense ? 11 : 13)),
    );
    final nameText = Text(
      shown,
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: (dense ? theme.textTheme.bodySmall : theme.textTheme.bodyMedium)?.copyWith(fontWeight: FontWeight.w600),
    );
    final tags = author?.tagNames ?? const [];
    if (dense) {
      return Row(
        children: [
          avatar,
          const SizedBox(width: 6),
          Flexible(child: nameText),
          if (tags.isNotEmpty) ...[const SizedBox(width: 6), Flexible(child: _Tag(text: tags.first))],
        ],
      );
    }
    final rank = author?.rankName ?? '';
    return Wrap(
      spacing: 6,
      runSpacing: 4,
      crossAxisAlignment: WrapCrossAlignment.center,
      children: [
        avatar,
        nameText,
        for (final tag in tags) _Tag(text: tag),
        if (showRank && rank.isNotEmpty) _Tag(text: rank, icon: Icons.workspace_premium_outlined),
      ],
    );
  }
}

class _Tag extends StatelessWidget {
  const _Tag({required this.text, this.icon});

  final String text;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
      decoration: BoxDecoration(
        border: Border.all(color: scheme.outlineVariant),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[Icon(icon, size: 12, color: scheme.primary), const SizedBox(width: 2)],
          Flexible(
            child: Text(
              text,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.labelSmall?.copyWith(color: scheme.primary),
            ),
          ),
        ],
      ),
    );
  }
}
