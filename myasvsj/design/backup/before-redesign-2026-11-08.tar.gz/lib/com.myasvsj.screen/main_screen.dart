import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.screen/blog_list_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/home_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/map_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/more_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/question_list_screen.dart';

/// Khung điều hướng của app: thanh tab dưới cùng giống web và prototype
/// (Trang chủ · Bản đồ · Blog · Hỏi-Đáp · Thêm).
///
/// Mỗi tab chỉ được dựng lần đầu khi người dùng mở tới nó (bản đồ không tải khi chưa cần), rồi được giữ lại
/// để quay về vẫn đúng chỗ đang xem.
class MainScreen extends StatefulWidget {
  const MainScreen({super.key, this.initialTab = 0});

  final int initialTab;

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  late int _index = widget.initialTab;
  late final Set<int> _opened = {widget.initialTab};

  static Widget _tab(int index) => switch (index) {
        0 => const HomeScreen(),
        1 => const MapScreen(),
        2 => const BlogListScreen(),
        3 => const QuestionListScreen(),
        _ => const MoreScreen(),
      };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: [
          for (var i = 0; i < 5; i++) _opened.contains(i) ? _tab(i) : const SizedBox.shrink(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() {
          _index = i;
          _opened.add(i);
        }),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Trang chủ'),
          NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'Bản đồ'),
          NavigationDestination(icon: Icon(Icons.article_outlined), selectedIcon: Icon(Icons.article), label: 'Blog'),
          NavigationDestination(
              icon: Icon(Icons.question_answer_outlined), selectedIcon: Icon(Icons.question_answer), label: 'Hỏi-Đáp'),
          NavigationDestination(icon: Icon(Icons.menu), label: 'Thêm'),
        ],
      ),
    );
  }
}
