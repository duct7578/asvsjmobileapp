import 'package:flutter/material.dart';

/// Một hàng lựa chọn của Nhật ngữ ("Từ vựng (4) / Mẫu câu (7)", "Tất cả / Chưa thuộc / Đã thuộc / Chưa luyện"):
/// các ChoiceChip tự xuống dòng nên không tràn trên màn hẹp. [options] là (giá trị, nhãn), chọn đúng một.
class PhraseChoiceChips extends StatelessWidget {
  const PhraseChoiceChips({super.key, required this.options, required this.selected, required this.onSelected});

  final List<(String, String)> options;
  final String selected;
  final ValueChanged<String> onSelected;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 4,
      children: [
        for (final (value, label) in options)
          ChoiceChip(label: Text(label), selected: value == selected, onSelected: (_) => onSelected(value)),
      ],
    );
  }
}
