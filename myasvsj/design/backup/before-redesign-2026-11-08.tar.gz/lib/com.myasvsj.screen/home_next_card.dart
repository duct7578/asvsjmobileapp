import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/home_guide_progress.dart';
import 'package:myasvsj/com.myasvsj.screen/guide_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/guide_list_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/home_format.dart';
import 'package:myasvsj/com.myasvsj.screen/my_guides_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/place_detail_screen.dart';

/// Thẻ "Việc tiếp theo": đã xong bao nhiêu cẩm nang của giai đoạn, rồi cẩm nang nên mở tiếp (server chọn)
/// kèm phần còn lại của nó. Số đã xong mở "Cẩm nang của tôi".
class HomeNextCard extends StatelessWidget {
  const HomeNextCard({super.key, required this.guide});

  final HomeGuideProgress guide;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final next = guide.next;
    final whole = OutlinedButton(
      onPressed: () => pushScreen<void>(context, GuideListScreen(stage: guide.stageCode)),
      child: const Text('Cả giai đoạn'),
    );
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.menu_book_outlined, color: theme.colorScheme.primary),
                const SizedBox(width: 8),
                Text('Việc tiếp theo', style: theme.textTheme.titleMedium),
              ],
            ),
            InkWell(
              onTap: () => pushScreen<void>(context, const MyGuidesScreen()),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Text(
                  '${guide.done}/${guide.total} · ${guide.stageTitle}',
                  style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.primary),
                ),
              ),
            ),
            LinearProgressIndicator(value: guide.progress, semanticsLabel: 'Cẩm nang đã xong'),
            const SizedBox(height: 8),
            if (next != null) ...[
              InkWell(
                onTap: () => pushScreen<void>(context, GuideDetailScreen(guideId: next.guideId, openChecklist: true)),
                child: Text(next.title, style: theme.textTheme.titleSmall),
              ),
              const SizedBox(height: 4),
              Text(
                next.checklist
                    ? '${next.tasksDone}/${next.tasksTotal} việc'
                          '${(next.nextTask ?? '').isNotEmpty ? ' · Tiếp theo: ${next.nextTask}' : ''}'
                    : 'Đọc xong thì bấm “Đánh dấu đã xong” trong cẩm nang.',
                style: theme.textTheme.bodySmall,
              ),
              if ((next.dueNote ?? '').isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Row(
                    children: [
                      Icon(Icons.schedule, size: 16, color: theme.colorScheme.error),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(next.dueNote!, style: TextStyle(color: theme.colorScheme.error)),
                      ),
                    ],
                  ),
                ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  if (next.placeId != null && (next.placeName ?? '').isNotEmpty)
                    OutlinedButton.icon(
                      onPressed: () => pushScreen<void>(context, PlaceDetailScreen(placeId: next.placeId!)),
                      icon: const Icon(Icons.location_on_outlined),
                      label: Text(next.placeName!),
                    ),
                  FilledButton.icon(
                    onPressed: () => pushScreen<void>(context, GuideDetailScreen(guideId: next.guideId, openChecklist: true)),
                    icon: const Icon(Icons.menu_book_outlined),
                    label: const Text('Mở cẩm nang này'),
                  ),
                  whole,
                ],
              ),
            ] else if (guide.total > 0) ...[
              const Text('Bạn đã xong giai đoạn này.'),
              const SizedBox(height: 4),
              whole,
            ] else
              const Text('Cẩm nang cho giai đoạn này đang được biên soạn.'),
          ],
        ),
      ),
    );
  }
}
