import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/answer.dart';
import 'package:myasvsj/com.myasvsj.model/question.dart';
import 'package:myasvsj/com.myasvsj.screen/question_author_row.dart';
import 'package:myasvsj/com.myasvsj.screen/question_badge.dart';

/// Một câu trả lời (và các phản hồi lồng bên dưới, thụt vào tối đa 3 bậc như web) ở màn chi tiết câu hỏi.
///
/// Chỉ vẽ và báo sự kiện bấm ra ngoài; màn hình QuestionDetailScreen quyết định (đăng nhập, hỏi xác nhận, gọi
/// Controller). Khách cũng thấy các nút; bấm vào thì màn hình đưa sang Đăng nhập.
class AnswerTile extends StatelessWidget {
  const AnswerTile({
    super.key,
    required this.answer,
    required this.question,
    this.depth = 0,
    this.signedIn = false,
    this.replyingTo,
    this.replyBox,
    this.editingId,
    this.editBox,
    this.onLike,
    this.onReply,
    this.onEdit,
    this.onDelete,
    this.onReport,
    this.onBest,
    this.onMessage,
  });

  /// Thụt vào tối đa ngần này bậc; sâu hơn vẫn hiện ở bậc cuối.
  static const int maxIndent = 3;

  final Answer answer;

  /// Câu hỏi chứa câu trả lời: quyền của người xem (người hỏi, được tương tác) và trạng thái đăng.
  final Question question;
  final int depth;

  /// Người xem đã đăng nhập trên app (khách không thấy nút "Nhắn tin" ở từng câu trả lời, như web).
  final bool signedIn;

  /// Câu trả lời đang mở ô phản hồi, và ô đó.
  final int? replyingTo;
  final Widget? replyBox;

  /// Câu trả lời đang sửa tại chỗ, và ô sửa (thay cho nội dung).
  final int? editingId;
  final Widget? editBox;

  final ValueChanged<Answer>? onLike;
  final ValueChanged<Answer>? onReply;
  final ValueChanged<Answer>? onEdit;
  final ValueChanged<Answer>? onDelete;
  final ValueChanged<Answer>? onReport;
  final ValueChanged<Answer>? onBest;
  final ValueChanged<Answer>? onMessage;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final a = answer;
    final children = <Widget>[];

    if (a.removed) {
      children.add(
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(
            children: [
              Icon(Icons.delete_outline, size: 16, color: scheme.outline),
              const SizedBox(width: 4),
              Text('Bình luận đã bị xóa.', style: theme.textTheme.bodySmall),
            ],
          ),
        ),
      );
    } else {
      children.addAll(_content(context));
    }
    if (replyingTo == a.id && replyBox != null) {
      children.add(replyBox!);
    }
    for (final reply in a.replies) {
      children.add(
        AnswerTile(
          key: ValueKey('answer-${reply.id}'),
          answer: reply,
          question: question,
          depth: depth + 1,
          signedIn: signedIn,
          replyingTo: replyingTo,
          replyBox: replyBox,
          editingId: editingId,
          editBox: editBox,
          onLike: onLike,
          onReply: onReply,
          onEdit: onEdit,
          onDelete: onDelete,
          onReport: onReport,
          onBest: onBest,
          onMessage: onMessage,
        ),
      );
    }

    // Phản hồi nằm trong cột của câu cha nên mỗi bậc tự thụt thêm; quá maxIndent bậc thì không thụt nữa
    final nested = depth > 0 && depth <= maxIndent;
    return Container(
      margin: EdgeInsets.only(left: nested ? 12 : 0, top: 4),
      padding: EdgeInsets.only(left: nested ? 8 : 0),
      decoration: BoxDecoration(
        border: nested ? Border(left: BorderSide(color: scheme.outlineVariant, width: 2)) : null,
      ),
      child: Container(
        padding: a.best ? const EdgeInsets.all(8) : EdgeInsets.zero,
        decoration: a.best
            ? BoxDecoration(
                color: scheme.primaryContainer.withValues(alpha: 0.35),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: scheme.primary),
              )
            : null,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
      ),
    );
  }

  List<Widget> _content(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final a = answer;
    final published = question.isPublished;
    // Đã đăng nhập nhưng tài khoản không tương tác được (staff, câu hỏi chưa đăng): nút bị khóa
    final locked = signedIn && !question.canInteract;
    final editable = a.isMine && question.canInteract && published;
    final canChooseBest = question.isMine && question.canInteract && depth == 0 && !a.isMine && !a.best;
    final actions = <Widget>[
      // Không thích được câu của chính mình, chỉ thấy số lượt thích
      if (!a.isMine)
        _action(
          icon: a.liked ? Icons.favorite : Icons.favorite_border,
          label: a.likeCount > 0 ? 'Thích · ${a.likeCount}' : 'Thích',
          onPressed: locked || onLike == null ? null : () => onLike!(a),
          color: a.liked ? scheme.primary : null,
        )
      else if (a.likeCount > 0)
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
          child: Text('♥ ${a.likeCount}', style: theme.textTheme.bodySmall),
        ),
      if (published)
        _action(icon: Icons.reply, label: 'Trả lời', onPressed: locked || onReply == null ? null : () => onReply!(a)),
      if (a.isMine) ...[
        if (editable)
          _action(icon: Icons.edit_outlined, label: 'Sửa', onPressed: onEdit == null ? null : () => onEdit!(a)),
        _action(icon: Icons.delete_outline, label: 'Xóa', onPressed: onDelete == null ? null : () => onDelete!(a)),
      ] else ...[
        if (signedIn && a.author != null)
          _action(
            icon: Icons.chat_outlined,
            label: 'Nhắn tin',
            onPressed: locked || onMessage == null ? null : () => onMessage!(a),
          ),
        _action(
          icon: Icons.flag_outlined,
          label: 'Báo cáo',
          onPressed: locked || onReport == null ? null : () => onReport!(a),
        ),
      ],
      if (canChooseBest)
        _action(
          icon: Icons.verified_outlined,
          label: 'Chọn là câu trả lời hay nhất',
          onPressed: onBest == null ? null : () => onBest!(a),
          color: scheme.primary,
        ),
    ];
    return [
      if (a.best)
        Padding(
          padding: const EdgeInsets.only(bottom: 4),
          child: QuestionBadge(
            label: 'Câu trả lời hay nhất',
            icon: Icons.verified,
            background: scheme.primary,
            foreground: scheme.onPrimary,
          ),
        ),
      QuestionAuthorRow(author: a.author, createdAt: a.createdAt, edited: a.edited),
      const SizedBox(height: 4),
      if (editingId == a.id && editBox != null)
        editBox!
      else ...[
        SelectableText(a.content, style: theme.textTheme.bodyMedium),
        Wrap(children: actions),
      ],
    ];
  }

  Widget _action({required IconData icon, required String label, VoidCallback? onPressed, Color? color}) {
    return TextButton.icon(
      style: TextButton.styleFrom(
        visualDensity: VisualDensity.compact,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        foregroundColor: color,
      ),
      onPressed: onPressed,
      icon: Icon(icon, size: 18),
      label: Text(label),
    );
  }
}
