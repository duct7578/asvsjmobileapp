import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/tag_request_controller.dart';
import 'package:myasvsj/com.myasvsj.model/tag_compose.dart';
import 'package:myasvsj/com.myasvsj.model/tag_option.dart';
import 'package:myasvsj/com.myasvsj.model/tag_pending_request.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/photo_picker.dart';
import 'package:myasvsj/com.myasvsj.screen/profile_sign_in_prompt.dart';
import 'package:myasvsj/com.myasvsj.screen/profile_tag_chip.dart';
import 'package:myasvsj/com.myasvsj.screen/profile_user_watcher.dart';

/// "Xin tag định danh" (UC-U09): chọn tag (tag đã có không chọn được), loại minh chứng (tag "Người Nhật" chỉ cần
/// ảnh chân dung), một ảnh và ô đồng ý cho Kiểm duyệt viên xem ảnh. Đang có yêu cầu chờ duyệt thì màn hình hiện
/// yêu cầu đó thay cho form.
class TagRequestScreen extends StatefulWidget {
  const TagRequestScreen({super.key});

  @override
  State<TagRequestScreen> createState() => _TagRequestScreenState();
}

class _TagRequestScreenState extends State<TagRequestScreen> with ProfileUserWatcher {
  @override
  void onUserChanged(int? userId) {
    if (userId != null) {
      context.read<TagRequestController>().open();
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthController>().currentUser;
    watchUser(user?.id);
    return Scaffold(
      appBar: AppBar(title: const Text('Xin tag định danh')),
      body: user == null
          ? const ProfileSignInPrompt(text: 'Đăng nhập để xin tag định danh.')
          : _body(context.watch<TagRequestController>()),
    );
  }

  Widget _body(TagRequestController tags) {
    final compose = tags.compose;
    if (tags.isLoading) {
      return const LoadingView();
    }
    if (compose == null) {
      return ErrorView(message: tags.error ?? 'Không tải được danh sách tag.', onRetry: tags.open);
    }
    final pending = compose.pending;
    if (pending != null) {
      return ListView(padding: const EdgeInsets.all(16), children: [_pendingCard(pending, compose)]);
    }
    return _form(tags, compose);
  }

  Widget _pendingCard(TagPendingRequest pending, TagCompose compose) {
    final theme = Theme.of(context);
    final submitted = pending.submittedAt;
    final expires = pending.expiresAt;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.hourglass_top, color: theme.colorScheme.primary),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                'Yêu cầu tag ${pending.tagName} đang chờ duyệt'
                '${submitted == null ? '' : ' (gửi ngày ${formatDate(submitted)})'}. '
                'Ảnh minh chứng tự xóa sau ${compose.keepDays} ngày nếu chưa được duyệt'
                '${expires == null ? '' : ' (ngày ${formatDate(expires)})'}. '
                'Bạn gửi được yêu cầu mới khi có kết quả.',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _form(TagRequestController tags, TagCompose compose) {
    final theme = Theme.of(context);
    final errors = tags.fieldErrors;
    final tag = tags.selectedTag;
    // Lỗi chung chỉ hiện riêng khi nó không phải lỗi của một ô (lỗi ô đã hiện dưới ô đó)
    final formError = tags.formError != null && !errors.containsValue(tags.formError) ? tags.formError : null;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
      children: [
        Text(
          'Tag cho mọi người biết bạn là ai (đang du học, đã đi làm, giáo viên…). '
          'Moderator đối chiếu ảnh minh chứng rồi mới cấp tag.',
          style: theme.textTheme.bodySmall,
        ),
        const SizedBox(height: 16),
        Text('Chọn tag', style: theme.textTheme.titleMedium),
        RadioGroup<int>(
          groupValue: tags.tagId,
          onChanged: tags.selectTag,
          child: Column(children: [for (final option in compose.tags) _tagTile(option)]),
        ),
        if (errors['tagId'] != null) _error(errors['tagId']!),
        if (tag != null) ..._details(tags, compose, tag),
        if (formError != null) _error(formError),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: tags.isSubmitting ? null : () => _submit(tags),
          icon: const Icon(Icons.send),
          label: Text(tags.isSubmitting ? 'Đang gửi…' : 'Gửi yêu cầu'),
        ),
      ],
    );
  }

  Widget _tagTile(TagOption option) {
    return RadioListTile<int>(
      value: option.id,
      enabled: !option.owned,
      contentPadding: EdgeInsets.zero,
      title: Wrap(
        spacing: 8,
        runSpacing: 4,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          ProfileTagChip(name: option.name, color: option.color),
          if (option.owned)
            const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.check, size: 16), Text(' Đã có')]),
        ],
      ),
      subtitle: option.description.isEmpty ? null : Text(option.description),
    );
  }

  /// Phần sau khi đã chọn tag: loại minh chứng, ảnh, ô đồng ý.
  List<Widget> _details(TagRequestController tags, TagCompose compose, TagOption tag) {
    final theme = Theme.of(context);
    final errors = tags.fieldErrors;
    return [
      const SizedBox(height: 12),
      if (tag.selfieOnly)
        Row(
          children: [
            const Icon(Icons.face_outlined),
            const SizedBox(width: 8),
            const Expanded(child: Text('Tag này chỉ cần một ảnh chân dung của bạn.')),
          ],
        )
      else
        DropdownButtonFormField<int>(
          key: ValueKey('proof-${tag.id}'),
          initialValue: tags.proofTypeId,
          isExpanded: true,
          decoration: InputDecoration(labelText: 'Loại minh chứng', errorText: errors['proofTypeId']),
          hint: const Text('Chọn loại minh chứng'),
          items: [
            for (final proof in tag.proofTypes)
              DropdownMenuItem(
                value: proof.id,
                child: Text(proof.name, maxLines: 1, overflow: TextOverflow.ellipsis),
              ),
          ],
          onChanged: tags.selectProofType,
        ),
      const SizedBox(height: 16),
      PhotoPicker(
        paths: tags.photoPaths,
        onChanged: tags.setPhotos,
        max: 1,
        label: tag.selfieOnly ? 'Ảnh chân dung' : 'Ảnh minh chứng',
      ),
      const SizedBox(height: 4),
      Text('JPG, PNG hoặc HEIC, tối đa ${compose.photoMaxMb} MB.', style: theme.textTheme.bodySmall),
      if (!tag.selfieOnly)
        Text(
          'Có thể che số thẻ và thông tin không cần thiết, chỉ cần thấy tên và loại giấy tờ.',
          style: theme.textTheme.bodySmall,
        ),
      if (errors['photo'] != null) _error(errors['photo']!),
      const SizedBox(height: 8),
      CheckboxListTile(
        value: tags.consent,
        onChanged: (value) => tags.setConsent(value ?? false),
        controlAffinity: ListTileControlAffinity.leading,
        contentPadding: EdgeInsets.zero,
        title: Text(
          'Tôi đồng ý cho Kiểm duyệt viên xem ảnh này. Ảnh sẽ bị xóa sau khi duyệt hoặc sau ${compose.keepDays} ngày.',
        ),
        subtitle: errors['consent'] == null
            ? null
            : Text(errors['consent']!, style: TextStyle(color: theme.colorScheme.error)),
      ),
    ];
  }

  Widget _error(String text) => Padding(
    padding: const EdgeInsets.only(top: 4),
    child: Text(text, style: TextStyle(color: Theme.of(context).colorScheme.error)),
  );

  Future<void> _submit(TagRequestController tags) async {
    final sent = await tags.submit();
    if (sent && mounted) {
      showMessage(context, tags.takeMessage());
    }
  }
}
