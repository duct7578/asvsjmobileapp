import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/conversation_item.dart';
import 'package:myasvsj/com.myasvsj.screen/chat_avatar.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';

/// Một dòng của danh sách "Tin nhắn" / "Lời mời": ảnh, tên, tin cuối (một dòng), thời gian, số tin chưa đọc.
class ConversationTile extends StatelessWidget {
  const ConversationTile({super.key, required this.item, this.onTap});

  final ConversationItem item;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final last = item.lastMessage;
    final unread = item.unread > 0;
    return ListTile(
      onTap: onTap,
      leading: ChatAvatar(name: item.peer.displayName, url: item.peer.avatarUrl),
      title: Row(
        children: [
          Flexible(
            child: Text(
              item.peer.displayName,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: unread ? const TextStyle(fontWeight: FontWeight.bold) : null,
            ),
          ),
          if (item.blockedByMe) ...[
            const SizedBox(width: 6),
            Text('Đã chặn', style: theme.textTheme.labelSmall?.copyWith(color: scheme.error)),
          ],
        ],
      ),
      subtitle: last == null
          ? null
          : Text(
              preview(item),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: unread ? TextStyle(fontWeight: FontWeight.w600, color: scheme.onSurface) : null,
            ),
      trailing: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (last != null) Text(formatTimeAgo(last.createdAt), style: theme.textTheme.labelSmall),
          if (unread) ...[const SizedBox(height: 4), Badge(label: Text(item.unread > 99 ? '99+' : '${item.unread}'))],
        ],
      ),
    );
  }

  /// Tin cuối trên một dòng, như trang web: "Bạn: …", thu hồi, tin mã hóa, tệp đính kèm.
  static String preview(ConversationItem item) {
    final last = item.lastMessage;
    if (last == null) {
      return '';
    }
    if (last.recalled) {
      return last.mine ? 'Bạn đã thu hồi một tin nhắn' : 'Tin nhắn đã được thu hồi';
    }
    final who = last.mine ? 'Bạn: ' : '';
    if (last.isEncrypted) {
      return '$who🔒 Tin nhắn đã mã hóa';
    }
    final text = last.content ?? '';
    return '$who${text.isEmpty && last.hasFiles ? '📎 Tệp đính kèm' : text}';
  }
}
