import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/blog.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_badge.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_detail_screen.dart';

/// "Bài nổi bật tuần này / tháng này": các bài được chọn tự động theo lượt thích và bình luận, cuộn ngang.
class BlogFeaturedList extends StatelessWidget {
  const BlogFeaturedList({super.key, required this.period, required this.posts});

  /// WEEK hoặc MONTH.
  final String? period;
  final List<Blog> posts;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: Row(
            children: [
              Icon(Icons.local_florist_outlined, size: 20, color: theme.colorScheme.primary),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  'Bài nổi bật ${period == 'MONTH' ? 'tháng này' : 'tuần này'}',
                  style: theme.textTheme.titleMedium,
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 2, 16, 4),
          child: Text('Tự động chọn theo lượt thích và bình luận', style: theme.textTheme.bodySmall),
        ),
        SizedBox(
          height: 128,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: posts.length,
            separatorBuilder: (_, _) => const SizedBox(width: 4),
            itemBuilder: (context, i) => _FeaturedTile(blog: posts[i], rank: i + 1),
          ),
        ),
      ],
    );
  }
}

class _FeaturedTile extends StatelessWidget {
  const _FeaturedTile({required this.blog, required this.rank});

  final Blog blog;
  final int rank;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final muted = theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant);
    return SizedBox(
      width: 250,
      child: Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () =>
              Navigator.push(context, MaterialPageRoute<void>(builder: (_) => BlogDetailScreen(blogId: blog.id!))),
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                BlogBadge(icon: Icons.star_outline, label: '#$rank'),
                const SizedBox(height: 4),
                Expanded(
                  child: Text(
                    blog.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.titleSmall,
                  ),
                ),
                Row(
                  children: [
                    Expanded(
                      child: Text(blog.authorName, maxLines: 1, overflow: TextOverflow.ellipsis, style: muted),
                    ),
                    Icon(Icons.favorite_border, size: 14, color: theme.colorScheme.onSurfaceVariant),
                    Text(' ${blog.likeCount}  ', style: muted),
                    Icon(Icons.chat_bubble_outline, size: 14, color: theme.colorScheme.onSurfaceVariant),
                    Text(' ${blog.commentCount}', style: muted),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
