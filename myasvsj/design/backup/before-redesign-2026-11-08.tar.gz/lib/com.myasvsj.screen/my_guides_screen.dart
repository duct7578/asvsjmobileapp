import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/guide_controller.dart';
import 'package:myasvsj/com.myasvsj.model/guide_activity.dart';
import 'package:myasvsj/com.myasvsj.model/guide_my_progress.dart';
import 'package:myasvsj/com.myasvsj.model/guide_stage_progress.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';
import 'package:myasvsj/com.myasvsj.screen/empty_view.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/guide_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/guide_list_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// "Cẩm nang của tôi" (`GET /api/me/guides/progress`, chỉ thành viên): tiến độ 4 giai đoạn, checklist đang làm dở,
/// cẩm nang vừa xong. Bấm một cẩm nang để mở chi tiết; quay về thì tải lại vì tiến độ có thể đã đổi.
/// Khách thấy lời mời đăng nhập.
class MyGuidesScreen extends StatefulWidget {
  const MyGuidesScreen({super.key});

  @override
  State<MyGuidesScreen> createState() => _MyGuidesScreenState();
}

class _MyGuidesScreenState extends State<MyGuidesScreen> {
  /// Người đã tải tiến độ cho; đổi tài khoản thì tải lại.
  int? _loadedFor;

  /// Đang tải lần đầu cho tài khoản này: chưa hiện dữ liệu cũ (của lần mở trước hay của tài khoản khác).
  bool _firstLoad = true;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    final guides = context.watch<GuideController>();
    final userId = auth.currentUser?.id;
    if (userId != null && userId != _loadedFor) {
      _loadedFor = userId;
      _firstLoad = true;
      WidgetsBinding.instance.addPostFrameCallback((_) => _loadFirst(guides));
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Cẩm nang của tôi')),
      body: userId == null ? _guest() : _body(guides),
    );
  }

  Future<void> _loadFirst(GuideController guides) async {
    if (!mounted) {
      return;
    }
    await guides.loadMyProgress();
    if (mounted) {
      setState(() => _firstLoad = false);
    }
  }

  Widget _guest() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const EmptyView(
            text: 'Đăng nhập để theo dõi tiến độ cẩm nang của bạn qua từng giai đoạn.',
            icon: Icons.checklist,
          ),
          FilledButton(onPressed: () => requireSignIn(context), child: const Text('Đăng nhập')),
        ],
      ),
    );
  }

  Widget _body(GuideController guides) {
    final data = guides.myProgress;
    if (_firstLoad || (guides.isLoadingMy && data == null)) {
      return const LoadingView();
    }
    if (guides.myError != null) {
      return ErrorView(message: guides.myError!, onRetry: guides.loadMyProgress);
    }
    if (data == null) {
      return const LoadingView();
    }
    final theme = Theme.of(context);
    return RefreshIndicator(
      onRefresh: guides.loadMyProgress,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        children: [
          Text(
            'Cẩm nang có danh sách chuẩn bị xong khi bạn đánh dấu hết các việc; cẩm nang khác xong khi bạn bấm '
            '“Đánh dấu đã xong”.',
            style: theme.textTheme.bodySmall,
          ),
          const SizedBox(height: 8),
          for (final stage in data.stages) _stageTile(stage),
          ..._lists(data),
          const SizedBox(height: 16),
          Center(
            child: OutlinedButton.icon(
              onPressed: () => _openList(null),
              icon: const Icon(Icons.menu_book_outlined),
              label: const Text('Mở Cẩm nang'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _stageTile(GuideStageProgress stage) {
    final theme = Theme.of(context);
    return ListTile(
      contentPadding: EdgeInsets.zero,
      onTap: () => _openList(stage.code),
      title: Text(stage.title, maxLines: 2, overflow: TextOverflow.ellipsis),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (stage.current)
            Container(
              margin: const EdgeInsets.only(top: 4),
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: theme.colorScheme.secondaryContainer,
                borderRadius: BorderRadius.circular(6),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.flag_outlined, size: 14, color: theme.colorScheme.onSecondaryContainer),
                  const SizedBox(width: 4),
                  Flexible(
                    child: Text(
                      'Giai đoạn của bạn',
                      style: theme.textTheme.labelSmall?.copyWith(color: theme.colorScheme.onSecondaryContainer),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 6),
          LinearProgressIndicator(value: stage.ratio, semanticsLabel: 'Tiến độ ${stage.title}'),
        ],
      ),
      trailing: Text(stage.total == 0 ? 'Chưa có' : '${stage.done}/${stage.total}', style: theme.textTheme.bodyMedium),
    );
  }

  List<Widget> _lists(GuideMyProgress data) {
    final theme = Theme.of(context);
    if (!data.hasActivity) {
      return [
        const SizedBox(height: 16),
        Text(
          'Bạn chưa bắt đầu cẩm nang nào. Mở Cẩm nang để xem việc cần làm ở từng giai đoạn.',
          style: theme.textTheme.bodyMedium,
        ),
      ];
    }
    return [
      if (data.inProgress.isNotEmpty) ...[
        const SizedBox(height: 16),
        Text('Đang làm dở', style: theme.textTheme.titleMedium),
        for (final g in data.inProgress)
          ListTile(
            contentPadding: EdgeInsets.zero,
            onTap: () => _openGuide(g, checklist: true),
            title: Text(g.title, maxLines: 2, overflow: TextOverflow.ellipsis),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (g.stageTitle != null) Text(g.stageTitle!, maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 4),
                LinearProgressIndicator(value: g.percent / 100),
                const SizedBox(height: 4),
                Text(
                  '${g.tasksDone}/${g.tasksTotal} việc${g.nextTask != null ? ' · Tiếp theo: ${g.nextTask}' : ''}',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
      ],
      if (data.recentlyDone.isNotEmpty) ...[
        const SizedBox(height: 16),
        Text('Đã xong gần đây', style: theme.textTheme.titleMedium),
        for (final g in data.recentlyDone)
          ListTile(
            contentPadding: EdgeInsets.zero,
            onTap: () => _openGuide(g),
            leading: Icon(Icons.check_circle, color: theme.colorScheme.primary),
            title: Text(g.title, maxLines: 2, overflow: TextOverflow.ellipsis),
            subtitle: Text(
              [if (g.stageTitle != null) g.stageTitle!, if (g.at != null) 'Xong ngày ${formatDate(g.at!)}'].join(' · '),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
      ],
    ];
  }

  Future<void> _openGuide(GuideActivity guide, {bool checklist = false}) async {
    await Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (_) => GuideDetailScreen(guideId: guide.id, openChecklist: checklist),
      ),
    );
    if (mounted) {
      context.read<GuideController>().loadMyProgress();
    }
  }

  Future<void> _openList(String? stage) async {
    await Navigator.push(context, MaterialPageRoute<void>(builder: (_) => GuideListScreen(stage: stage)));
    if (mounted) {
      context.read<GuideController>().loadMyProgress();
    }
  }
}
