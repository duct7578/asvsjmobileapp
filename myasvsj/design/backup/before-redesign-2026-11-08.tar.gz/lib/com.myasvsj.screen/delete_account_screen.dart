import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/auth_notice.dart';
import 'package:myasvsj/com.myasvsj.screen/auth_required_view.dart';

/// "Xóa tài khoản" ở trang Tôi: giải thích hậu quả như web, hỏi xác nhận, rồi xóa.
/// Xóa xong app về trạng thái khách và quay về màn hình gốc.
class DeleteAccountScreen extends StatefulWidget {
  const DeleteAccountScreen({super.key});

  /// Hậu quả của việc xóa, chép từ trang Tôi của web.
  static const consequences = [
    'Hồ sơ, điểm và tag bị xóa; yêu cầu tag đang chờ và ảnh minh chứng bị hủy.',
    'Bạn sẽ bị đăng xuất và không thể khôi phục.',
    'Bài viết, câu hỏi, bình luận, câu trả lời và tin nhắn của bạn sẽ bị ẩn với mọi người; '
        'review của bạn được xóa hoặc ẩn danh.',
  ];

  @override
  State<DeleteAccountScreen> createState() => _DeleteAccountScreenState();
}

class _DeleteAccountScreenState extends State<DeleteAccountScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<AuthController>().clearForm());
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    final user = auth.currentUser;
    return Scaffold(
      appBar: AppBar(title: const Text('Xóa tài khoản')),
      body: user == null
          ? const AuthRequiredView(text: 'Bạn cần đăng nhập để xóa tài khoản.')
          : _body(context, auth, user.email),
    );
  }

  Widget _body(BuildContext context, AuthController auth, String email) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Icon(Icons.warning_amber_rounded, size: 48, color: scheme.error),
        const SizedBox(height: 8),
        Text('Xóa tài khoản?', style: theme.textTheme.titleLarge, textAlign: TextAlign.center),
        const SizedBox(height: 4),
        Text(email, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis),
        const SizedBox(height: 16),
        for (final line in DeleteAccountScreen.consequences)
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(Icons.remove_circle_outline, color: scheme.error),
            title: Text(line),
          ),
        const SizedBox(height: 16),
        if (auth.bannerError != null) AuthNotice(text: auth.bannerError!),
        FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: scheme.error, foregroundColor: scheme.onError),
          icon: const Icon(Icons.delete_forever_outlined),
          label: Text(auth.isLoading ? 'Đang xóa…' : 'Xóa tài khoản'),
          onPressed: auth.isLoading ? null : () => _confirmAndDelete(context, email),
        ),
        const SizedBox(height: 8),
        OutlinedButton(onPressed: auth.isLoading ? null : () => Navigator.pop(context), child: const Text('Hủy')),
      ],
    );
  }

  Future<void> _confirmAndDelete(BuildContext context, String email) async {
    final scheme = Theme.of(context).colorScheme;
    final yes = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Xóa tài khoản?'),
        content: Text('Tài khoản $email sẽ bị xóa và không thể khôi phục.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Hủy')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: scheme.error, foregroundColor: scheme.onError),
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Xóa tài khoản'),
          ),
        ],
      ),
    );
    if (yes != true || !context.mounted) {
      return;
    }
    final auth = context.read<AuthController>();
    final deleted = await auth.deleteAccount();
    if (deleted && context.mounted) {
      // "Đã xóa tài khoản."
      showMessage(context, auth.takeMessage());
      Navigator.popUntil(context, (route) => route.isFirst);
    }
  }
}
