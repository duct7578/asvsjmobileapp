import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/map_place.dart';
import 'package:myasvsj/com.myasvsj.model/place_option.dart';
import 'package:myasvsj/com.myasvsj.screen/place_category_icon.dart';
import 'package:myasvsj/com.myasvsj.screen/place_directions_button.dart';
import 'package:myasvsj/com.myasvsj.screen/place_rating_stars.dart';

/// Bảng dưới (bottom sheet) khi bấm một ghim: tóm tắt địa điểm, "Xem chi tiết" và "Chỉ đường".
///
/// Địa điểm OpenStreetMap chưa có trên Senpai ơi ([PlaceSummarySheet.option] không có id) có "Viết review đầu
/// tiên" thay cho "Xem chi tiết", giống bảng "chưa có trên Senpai ơi" của web.
class PlaceSummarySheet extends StatelessWidget {
  const PlaceSummarySheet({
    super.key,
    required this.name,
    this.subtitle = '',
    this.categoryName = '',
    this.categoryIcon = 'place',
    this.reviewCount = 0,
    this.rating,
    this.closed = false,
    this.scam = false,
    this.pending = false,
    this.onSenpai = true,
    this.distanceText = '',
    required this.directionsUrl,
    this.onOpenDetail,
    this.onWriteFirst,
  });

  /// Ghim của Senpai ơi.
  PlaceSummarySheet.place(
    MapPlace place, {
    Key? key,
    String categoryName = '',
    String categoryIcon = 'place',
    String distanceText = '',
    VoidCallback? onOpenDetail,
  }) : this(
         key: key,
         name: place.name,
         subtitle: [place.nameJa, place.nameEn].where((s) => s.isNotEmpty).join(' · '),
         categoryName: categoryName,
         categoryIcon: categoryIcon,
         reviewCount: place.reviewCount,
         rating: place.rating,
         closed: place.closed,
         scam: place.scam,
         pending: place.isPending,
         distanceText: distanceText,
         directionsUrl: place.directionsUrl,
         onOpenDetail: onOpenDetail,
       );

  /// Kết quả tìm kiếm / quanh đây chưa có ghim (địa điểm OpenStreetMap).
  PlaceSummarySheet.option(
    PlaceOption option, {
    Key? key,
    String categoryIcon = 'place',
    String distanceText = '',
    VoidCallback? onOpenDetail,
    VoidCallback? onWriteFirst,
  }) : this(
         key: key,
         name: option.name,
         subtitle: [
           if (option.nameJa != option.name) option.nameJa,
           option.address,
         ].where((s) => s.isNotEmpty).join(' · '),
         categoryName: option.category,
         categoryIcon: categoryIcon,
         onSenpai: option.isOnSenpai,
         distanceText: distanceText,
         directionsUrl: option.directionsUrl,
         onOpenDetail: onOpenDetail,
         onWriteFirst: onWriteFirst,
       );

  final String name;

  /// Tên tiếng Nhật, tiếng Anh, địa chỉ.
  final String subtitle;
  final String categoryName;
  final String categoryIcon;
  final int reviewCount;
  final double? rating;
  final bool closed;
  final bool scam;
  final bool pending;

  /// false: địa điểm OpenStreetMap chưa có trên Senpai ơi.
  final bool onSenpai;

  /// Khoảng cách từ vị trí của tôi, ví dụ "350 m"; rỗng khi chưa biết.
  final String distanceText;
  final String directionsUrl;
  final VoidCallback? onOpenDetail;
  final VoidCallback? onWriteFirst;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                if (categoryName.isNotEmpty)
                  Chip(
                    avatar: Icon(placeCategoryIcon(categoryIcon), size: 18),
                    label: Text(categoryName),
                    visualDensity: VisualDensity.compact,
                  ),
                if (!onSenpai) const Chip(label: Text('OpenStreetMap'), visualDensity: VisualDensity.compact),
                if (pending) const Chip(label: Text('Chờ Moderator duyệt'), visualDensity: VisualDensity.compact),
                if (closed) const Chip(label: Text('Đã đóng cửa'), visualDensity: VisualDensity.compact),
              ],
            ),
            const SizedBox(height: 4),
            Text(name, style: theme.textTheme.titleLarge, maxLines: 2, overflow: TextOverflow.ellipsis),
            if (subtitle.isNotEmpty)
              Text(subtitle, style: theme.textTheme.bodySmall, maxLines: 2, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 8),
            Row(
              children: [
                if (!onSenpai)
                  const Text('Chưa có review')
                else if (reviewCount > 0 && rating != null) ...[
                  PlaceRatingStars(rating: rating!),
                  const SizedBox(width: 6),
                  Text('${rating!.toStringAsFixed(1)} · $reviewCount review'),
                ] else
                  const Text('Chưa có review'),
                const Spacer(),
                if (distanceText.isNotEmpty) Text(distanceText, style: theme.textTheme.bodySmall),
              ],
            ),
            if (scam)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Row(
                  children: [
                    Icon(Icons.warning_amber, color: scheme.error, size: 20),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text('Có cảnh báo lừa đảo', style: TextStyle(color: scheme.error)),
                    ),
                  ],
                ),
              ),
            if (!onSenpai)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  'Địa điểm này có trên OpenStreetMap nhưng chưa có trên Senpai ơi. Địa điểm sẽ được thêm khi có '
                  'người viết review, lưu, hoặc gắn vào bài viết.',
                  style: theme.textTheme.bodySmall,
                ),
              ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                if (onOpenDetail != null)
                  FilledButton.icon(
                    onPressed: onOpenDetail,
                    icon: const Icon(Icons.info_outline),
                    label: const Text('Xem chi tiết'),
                  ),
                if (onWriteFirst != null)
                  FilledButton.icon(
                    onPressed: onWriteFirst,
                    icon: const Icon(Icons.rate_review_outlined),
                    label: const Text('Viết review đầu tiên'),
                  ),
                PlaceDirectionsButton(url: directionsUrl),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
