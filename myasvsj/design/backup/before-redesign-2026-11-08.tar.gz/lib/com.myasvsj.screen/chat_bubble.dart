import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/chat_message.dart';

/// Một tin nhắn trong cuộc trò chuyện: tin của mình bên phải, của người kia bên trái. Nhấn giữ để mở các thao tác
/// (Sao chép, Sửa, Thu hồi, Báo cáo).
class ChatBubble extends StatelessWidget {
  const ChatBubble({
    super.key,
    required this.message,
    this.quoted,
    this.quotedName = '',
    this.delivery,
    this.onLongPress,
  });

  final ChatMessage message;

  /// Tin được trả lời (đã tải), nếu có.
  final ChatMessage? quoted;

  /// Tên người viết tin được trả lời ("Bạn" hoặc tên người kia).
  final String quotedName;

  /// "Đã xem" / "Đã gửi" dưới tin mới nhất của mình.
  final String? delivery;
  final VoidCallback? onLongPress;

  static const String recalledMine = 'Bạn đã thu hồi một tin nhắn';
  static const String recalledTheirs = 'Tin nhắn đã được thu hồi';
  static const String encryptedText = 'Tin nhắn đã mã hóa. Mở Senpai ơi trên web để đọc.';

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final m = message;
    final background = m.mine ? scheme.primaryContainer : scheme.surfaceContainerHighest;
    final foreground = m.mine ? scheme.onPrimaryContainer : scheme.onSurface;
    final muted = TextStyle(color: foreground.withValues(alpha: 0.7), fontStyle: FontStyle.italic);
    final hh = m.createdAt.hour.toString().padLeft(2, '0');
    final mm = m.createdAt.minute.toString().padLeft(2, '0');
    final meta = ['$hh:$mm', if (m.edited && !m.recalled) 'đã sửa', ?delivery].join(' · ');

    return Align(
      alignment: m.mine ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: MediaQuery.sizeOf(context).width * 0.78),
        child: GestureDetector(
          onLongPress: onLongPress,
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(color: background, borderRadius: BorderRadius.circular(16)),
            child: Column(
              crossAxisAlignment: m.mine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                if (m.replyToId != null && !m.recalled) _quote(theme, foreground),
                _body(m, foreground, muted),
                if (m.reactions.isNotEmpty && !m.recalled)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Wrap(
                      spacing: 4,
                      children: [
                        for (final r in m.reactions)
                          Text('${r.emoji} ${r.count}', style: theme.textTheme.labelSmall?.copyWith(color: foreground)),
                      ],
                    ),
                  ),
                const SizedBox(height: 2),
                Text(meta, style: theme.textTheme.labelSmall?.copyWith(color: foreground.withValues(alpha: 0.7))),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _body(ChatMessage m, Color foreground, TextStyle muted) {
    if (m.recalled) {
      return Text(m.mine ? recalledMine : recalledTheirs, style: muted);
    }
    if (m.isEncrypted) {
      return Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.lock_outline, size: 16, color: foreground),
          const SizedBox(width: 4),
          Flexible(child: Text(encryptedText, style: muted)),
        ],
      );
    }
    final text = m.content ?? '';
    if (text.isEmpty && m.hasFiles) {
      return Text('📎 Tệp đính kèm (app chưa hiển thị được)', style: muted);
    }
    return Text(text, style: TextStyle(color: foreground));
  }

  Widget _quote(ThemeData theme, Color foreground) {
    final q = quoted;
    final text = q == null
        ? 'Tin nhắn cũ'
        : q.recalled
        ? recalledTheirs
        : (q.isEncrypted ? 'Tin nhắn đã mã hóa' : (q.content ?? ''));
    return Container(
      margin: const EdgeInsets.only(bottom: 4),
      padding: const EdgeInsets.only(left: 8),
      decoration: BoxDecoration(
        border: Border(left: BorderSide(color: foreground.withValues(alpha: 0.5), width: 3)),
      ),
      child: Text(
        quotedName.isEmpty ? text : '$quotedName: $text',
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: theme.textTheme.bodySmall?.copyWith(color: foreground.withValues(alpha: 0.8)),
      ),
    );
  }
}
