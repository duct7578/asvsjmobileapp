import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';

/// Các điều kiện của mật khẩu mới ("Từ 8 ký tự", "Có chữ", "Có số"), tự đánh dấu khi đang gõ như trang web.
class PasswordRules extends StatelessWidget {
  const PasswordRules({super.key, required this.controller, this.minLength = AuthController.defaultPasswordMinLength});

  /// Ô mật khẩu đang theo dõi.
  final TextEditingController controller;
  final int minLength;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ListenableBuilder(
      listenable: controller,
      builder: (context, _) => Wrap(
        spacing: 16,
        runSpacing: 4,
        children: [
          for (final rule in AuthController.passwordChecklist(controller.text, minLength: minLength))
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  rule.ok ? Icons.check_circle : Icons.radio_button_unchecked,
                  size: 16,
                  color: rule.ok ? theme.colorScheme.primary : theme.colorScheme.outline,
                ),
                const SizedBox(width: 4),
                Text(rule.label, style: theme.textTheme.bodySmall),
              ],
            ),
        ],
      ),
    );
  }
}
