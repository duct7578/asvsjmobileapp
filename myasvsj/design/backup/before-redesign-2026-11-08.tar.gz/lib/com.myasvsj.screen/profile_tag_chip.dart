import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/profile_tag.dart';

/// Nhãn tag định danh như trên web: chữ và viền mang màu của tag (server gửi), nền trong suốt.
class ProfileTagChip extends StatelessWidget {
  const ProfileTagChip({super.key, required this.name, this.color = ''});

  final String name;

  /// Mã màu web, ví dụ "#2E7D5B"; sai hoặc trống thì dùng màu chính của theme.
  final String color;

  @override
  Widget build(BuildContext context) {
    final value = ProfileTag.parseColor(color);
    final tint = value == null ? Theme.of(context).colorScheme.primary : Color(value);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        border: Border.all(color: tint),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        name,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: Theme.of(context).textTheme.labelMedium?.copyWith(color: tint, fontWeight: FontWeight.w600),
      ),
    );
  }
}
