import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/blog_comment.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_author_line.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';

/// Thao tác trên một bình luận; màn chi tiết bài quyết định làm gì (khách thì đưa sang đăng nhập).
enum BlogCommentAction { like, reply, edit, delete, report, message }

/// Một bình luận và các câu trả lời lồng bên dưới (thụt vào tối đa 3 bậc, như web).
///
/// Bình luận của mình: Sửa, Xóa. Của người khác: Thích, Nhắn tin (khi đã đăng nhập), Báo cáo.
/// [canReply]: bài đã đăng nên nhận trả lời; [canEdit]: người xem được sửa bình luận của mình.
class BlogCommentTile extends StatelessWidget {
  const BlogCommentTile({
    super.key,
    required this.comment,
    required this.onAction,
    this.depth = 0,
    this.canReply = true,
    this.canEdit = true,
    this.isSignedIn = false,
  });

  static const int maxIndent = 3;

  final BlogComment comment;
  final int depth;
  final bool canReply;
  final bool canEdit;
  final bool isSignedIn;
  final void Function(BlogComment comment, BlogCommentAction action) onAction;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final c = comment;
    final replies = [
      for (final reply in c.replies)
        BlogCommentTile(
          comment: reply,
          onAction: onAction,
          depth: depth + 1,
          canReply: canReply,
          canEdit: canEdit,
          isSignedIn: isSignedIn,
        ),
    ];
    final body = c.removed
        ? Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(
              children: [
                Icon(Icons.delete_outline, size: 16, color: theme.colorScheme.outline),
                const SizedBox(width: 4),
                Text('Bình luận đã bị xóa.', style: theme.textTheme.bodySmall),
              ],
            ),
          )
        : Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(child: BlogAuthorLine(author: c.author, dense: true)),
                    if (c.createdAt != null)
                      Text(
                        [formatTimeAgo(c.createdAt!), if (c.edited) 'đã sửa'].join(' · '),
                        style: theme.textTheme.bodySmall,
                      ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 28, top: 2),
                  child: SelectableText(c.content, style: theme.textTheme.bodyMedium),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 20),
                  child: Wrap(children: _actions(context)),
                ),
              ],
            ),
          );
    final column = Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [body, ...replies]);
    // Trả lời sâu hơn 3 bậc hiện thẳng hàng với bậc 3 để không bị đẩy ra ngoài màn hình hẹp
    if (depth == 0 || depth > maxIndent) {
      return column;
    }
    return Container(
      margin: const EdgeInsets.only(left: 12),
      padding: const EdgeInsets.only(left: 8),
      decoration: BoxDecoration(
        border: Border(left: BorderSide(color: theme.colorScheme.outlineVariant, width: 2)),
      ),
      child: column,
    );
  }

  List<Widget> _actions(BuildContext context) {
    final c = comment;
    final small = TextButton.styleFrom(
      visualDensity: VisualDensity.compact,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      minimumSize: const Size(0, 36),
    );
    Widget button(IconData icon, String label, BlogCommentAction action) => TextButton.icon(
      style: small,
      onPressed: () => onAction(c, action),
      icon: Icon(icon, size: 16),
      label: Text(label),
    );
    return [
      if (c.mine && c.likeCount > 0)
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          child: Text('♥ ${c.likeCount}', style: Theme.of(context).textTheme.bodySmall),
        ),
      if (!c.mine)
        button(
          c.liked ? Icons.favorite : Icons.favorite_border,
          c.likeCount > 0 ? 'Thích · ${c.likeCount}' : 'Thích',
          BlogCommentAction.like,
        ),
      if (canReply) button(Icons.reply, 'Trả lời', BlogCommentAction.reply),
      if (c.mine && canEdit && canReply) button(Icons.edit_outlined, 'Sửa', BlogCommentAction.edit),
      if (c.mine) button(Icons.delete_outline, 'Xóa', BlogCommentAction.delete),
      if (!c.mine && isSignedIn && c.author != null) button(Icons.chat_outlined, 'Nhắn tin', BlogCommentAction.message),
      if (!c.mine) button(Icons.flag_outlined, 'Báo cáo', BlogCommentAction.report),
    ];
  }
}
