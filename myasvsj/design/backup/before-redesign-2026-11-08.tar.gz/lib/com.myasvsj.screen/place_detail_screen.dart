import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/place_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/review_controller.dart';
import 'package:myasvsj/com.myasvsj.model/place_detail.dart';
import 'package:myasvsj/com.myasvsj.model/place_review.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/empty_view.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/map_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/place_category_icon.dart';
import 'package:myasvsj/com.myasvsj.screen/place_directions_button.dart';
import 'package:myasvsj/com.myasvsj.screen/place_phrase_tile.dart';
import 'package:myasvsj/com.myasvsj.screen/place_rating_stars.dart';
import 'package:myasvsj/com.myasvsj.screen/place_review_card.dart';
import 'package:myasvsj/com.myasvsj.screen/report_dialog.dart';
import 'package:myasvsj/com.myasvsj.screen/review_form_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// Chi tiết địa điểm (UC-U15): tên, danh mục, địa chỉ, điểm trung bình, cảnh báo lừa đảo, "Chỉ đường", Lưu,
/// "Báo đã đóng cửa", review (Thích / Báo cáo, hoặc Sửa / Xóa review của mình) và từ vựng, mẫu câu tiếng Nhật
/// có nút "Nghe". Khách bấm thao tác cần tài khoản thì được đưa sang Đăng nhập.
class PlaceDetailScreen extends StatefulWidget {
  const PlaceDetailScreen({super.key, required this.placeId});

  final int placeId;

  @override
  State<PlaceDetailScreen> createState() => _PlaceDetailScreenState();
}

class _PlaceDetailScreenState extends State<PlaceDetailScreen> {
  /// 0: Review, 1: Từ vựng và mẫu câu.
  int _tab = 0;
  late final PlaceController _places;

  /// Người đang đăng nhập lúc dựng lần trước: đổi thì tải lại (đã lưu, review của mình, quyền thao tác).
  int? _userId;
  bool _userSeen = false;

  int get _id => widget.placeId;

  @override
  void initState() {
    super.initState();
    _places = context.read<PlaceController>();
    // Gọi sau khung hình đầu: notifyListeners() không được chạy giữa lúc đang dựng giao diện
    WidgetsBinding.instance.addPostFrameCallback((_) => _places.loadPlace(_id));
  }

  @override
  void dispose() {
    _places.stopSpeaking();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final places = context.watch<PlaceController>();
    _watchUser(context.watch<AuthController>().currentUser?.id);
    final detail = places.detailOf(_id);
    return Scaffold(
      appBar: AppBar(
        title: Text(detail?.name ?? 'Địa điểm', maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          if (detail?.lat != null)
            IconButton(
              tooltip: 'Xem trên bản đồ',
              icon: const Icon(Icons.map_outlined),
              onPressed: () =>
                  Navigator.push(context, MaterialPageRoute<void>(builder: (_) => MapScreen(focusPlaceId: detail!.id))),
            ),
        ],
      ),
      body: _body(places, detail),
    );
  }

  void _watchUser(int? userId) {
    if (_userSeen && userId == _userId) {
      return;
    }
    final changed = _userSeen;
    _userSeen = true;
    _userId = userId;
    if (changed) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          _places.loadPlace(_id);
        }
      });
    }
  }

  Widget _body(PlaceController places, PlaceDetail? detail) {
    if (detail == null) {
      final error = places.detailErrorOf(_id);
      if (error != null && !places.isLoadingDetail(_id)) {
        return ErrorView(message: error, onRetry: () => places.loadPlace(_id));
      }
      return const LoadingView();
    }
    return RefreshIndicator(
      onRefresh: () => places.loadPlace(_id),
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ..._header(detail),
          const SizedBox(height: 12),
          _actions(detail),
          const SizedBox(height: 16),
          SegmentedButton<int>(
            segments: const [
              ButtonSegment(value: 0, label: Text('Review'), icon: Icon(Icons.rate_review_outlined)),
              ButtonSegment(value: 1, label: Text('Từ vựng và mẫu câu'), icon: Icon(Icons.translate)),
            ],
            selected: {_tab},
            showSelectedIcon: false,
            onSelectionChanged: (value) => _selectTab(places, value.first),
          ),
          const SizedBox(height: 8),
          if (_tab == 0) ..._reviews(places, detail) else ..._phrases(places),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------- thông tin

  List<Widget> _header(PlaceDetail d) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final names = [d.nameJa, d.nameEn, d.address].where((s) => s.isNotEmpty).join(' · ');
    return [
      Wrap(
        spacing: 8,
        runSpacing: 4,
        children: [
          Chip(
            avatar: Icon(placeCategoryIcon(d.categoryIcon), size: 18),
            label: Text(d.categoryName),
            visualDensity: VisualDensity.compact,
          ),
          Chip(label: Text(d.sourceLabel), visualDensity: VisualDensity.compact),
          if (d.isPending) const Chip(label: Text('Chờ Moderator duyệt'), visualDensity: VisualDensity.compact),
          if (d.closed)
            Chip(
              label: const Text('Đã đóng cửa (Moderator xác nhận)'),
              backgroundColor: scheme.errorContainer,
              visualDensity: VisualDensity.compact,
            )
          else if (d.closedWaiting)
            const Chip(
              label: Text('Nhiều người báo đã đóng cửa, đang chờ xác minh'),
              visualDensity: VisualDensity.compact,
            ),
        ],
      ),
      if (d.mergedFrom != null)
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text('Địa điểm bạn mở đã được gộp vào địa điểm này.', style: theme.textTheme.bodySmall),
        ),
      const SizedBox(height: 8),
      Text(d.name, style: theme.textTheme.headlineSmall),
      if (names.isNotEmpty) Text(names, style: theme.textTheme.bodyMedium),
      if (d.scamWarnings.isNotEmpty) _scamBox(d),
      const SizedBox(height: 12),
      Row(
        children: [
          if (d.reviewCount > 0 && d.rating != null) ...[
            PlaceRatingStars(rating: d.rating!, size: 20),
            const SizedBox(width: 6),
            Text(d.rating!.toStringAsFixed(1), style: theme.textTheme.titleMedium),
            const SizedBox(width: 8),
            Expanded(child: Text('${d.reviewCount} review từ người dùng Senpai ơi', style: theme.textTheme.bodySmall)),
          ] else
            const Expanded(child: Text('Chưa có review. Hãy là người đầu tiên.')),
        ],
      ),
    ];
  }

  Widget _scamBox(PlaceDetail d) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      margin: const EdgeInsets.only(top: 12),
      color: scheme.errorContainer,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.warning_amber, color: scheme.onErrorContainer),
                const SizedBox(width: 6),
                Text(
                  'Cảnh báo lừa đảo',
                  style: TextStyle(color: scheme.onErrorContainer, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            for (final warning in d.scamWarnings)
              TextButton(
                style: TextButton.styleFrom(
                  foregroundColor: scheme.onErrorContainer,
                  alignment: Alignment.centerLeft,
                  padding: EdgeInsets.zero,
                ),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(builder: (_) => BlogDetailScreen(blogId: warning.blogId)),
                ),
                child: Text(warning.title, maxLines: 2, overflow: TextOverflow.ellipsis),
              ),
          ],
        ),
      ),
    );
  }

  Widget _actions(PlaceDetail d) {
    final signedIn = context.read<AuthController>().isSignedIn;
    // Tài khoản staff chỉ xem: khóa nút. Khách vẫn bấm được để sang Đăng nhập.
    final staff = signedIn && !d.canAct;
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        if (d.myReviewId != null)
          FilledButton.icon(
            onPressed: () => _openForm(reviewId: d.myReviewId),
            icon: const Icon(Icons.edit),
            label: const Text('Sửa review của bạn'),
          )
        else
          FilledButton.icon(
            onPressed: staff || !d.isActive ? null : () => _openForm(),
            icon: const Icon(Icons.rate_review_outlined),
            label: const Text('Viết review'),
          ),
        OutlinedButton.icon(
          onPressed: staff ? null : _toggleSave,
          icon: Icon(d.saved ? Icons.bookmark_added : Icons.bookmark_border),
          label: Text(d.saved ? 'Đã lưu' : 'Lưu'),
        ),
        PlaceDirectionsButton(url: d.directionsUrl),
        if (!d.closed && d.isActive)
          OutlinedButton.icon(
            onPressed: staff || d.reportedClosed ? null : () => _reportClosed(d),
            icon: const Icon(Icons.block),
            label: Text(
              d.reportedClosed ? 'Bạn đã báo đóng cửa (${d.closedProgress})' : 'Báo đã đóng cửa (${d.closedProgress})',
            ),
          ),
      ],
    );
  }

  // ---------------------------------------------------------------- review, từ vựng

  List<Widget> _reviews(PlaceController places, PlaceDetail d) {
    final reviews = places.reviewsOf(_id);
    final loading = places.isLoadingReviews(_id);
    final error = places.reviewErrorOf(_id);
    final staff = context.read<AuthController>().isSignedIn && !d.canAct;
    return [
      if (reviews.isEmpty && loading)
        const Padding(
          padding: EdgeInsets.all(24),
          child: Center(child: CircularProgressIndicator()),
        )
      else if (reviews.isEmpty && error != null)
        ErrorView(message: error, onRetry: () => places.loadReviews(_id))
      else if (reviews.isEmpty)
        const EmptyView(text: 'Chưa ai viết review về địa điểm này.', icon: Icons.rate_review_outlined),
      for (final review in reviews)
        PlaceReviewCard(
          key: ValueKey('review-${review.id}'),
          review: review,
          canAct: !staff,
          onLike: () => _toggleLike(review),
          onReport: () => _report(d, review),
          onEdit: () => _openForm(reviewId: review.id),
          onDelete: () => _deleteReview(review),
        ),
      if (reviews.isNotEmpty && error != null)
        Text(error, style: TextStyle(color: Theme.of(context).colorScheme.error)),
      if (places.hasMoreReviews(_id))
        Center(
          child: OutlinedButton(
            onPressed: loading ? null : () => places.loadReviews(_id, more: true),
            child: Text(loading ? 'Đang tải…' : 'Xem thêm review'),
          ),
        ),
    ];
  }

  List<Widget> _phrases(PlaceController places) {
    final phrases = places.phrasesOf(_id);
    if (phrases == null) {
      return const [
        Padding(
          padding: EdgeInsets.all(24),
          child: Center(child: CircularProgressIndicator()),
        ),
      ];
    }
    if (phrases.isEmpty) {
      return const [EmptyView(text: 'Danh mục này chưa có từ vựng và mẫu câu.', icon: Icons.translate)];
    }
    return [for (final phrase in phrases) PlacePhraseTile(phrase: phrase, onSpeak: () => _speak(phrase.japanese))];
  }

  void _selectTab(PlaceController places, int tab) {
    setState(() => _tab = tab);
    if (tab == 1 && places.phrasesOf(_id) == null && !places.isLoadingPhrases(_id)) {
      places.loadPhrases(_id);
    }
  }

  // ---------------------------------------------------------------- thao tác

  /// Khách được đưa sang Đăng nhập; đăng nhập xong thì tải lại địa điểm để có trạng thái của người dùng.
  Future<bool> _signedIn() async {
    if (context.read<AuthController>().isSignedIn) {
      return true;
    }
    if (!await requireSignIn(context) || !mounted) {
      return false;
    }
    await _places.loadPlace(_id);
    return mounted;
  }

  void _showControllerMessage() {
    if (mounted) {
      showMessage(context, _places.takeMessage());
    }
  }

  Future<void> _toggleSave() async {
    if (!await _signedIn()) {
      return;
    }
    await _places.toggleSave(_id);
    _showControllerMessage();
  }

  Future<void> _reportClosed(PlaceDetail d) async {
    if (!await _signedIn() || !mounted) {
      return;
    }
    final current = _places.detailOf(_id) ?? d;
    if (current.reportedClosed) {
      showMessage(context, 'Bạn đã báo địa điểm này rồi.');
      return;
    }
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Báo đã đóng cửa?'),
        content: Text(
          'Bạn chắc “${current.name}” đã đóng cửa? Khi đủ ${current.closedThreshold} người báo, '
          'Moderator sẽ kiểm tra rồi mới gắn nhãn.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Gửi báo cáo')),
        ],
      ),
    );
    if (confirmed != true) {
      return;
    }
    await _places.reportClosed(_id);
    _showControllerMessage();
  }

  Future<void> _toggleLike(PlaceReview review) async {
    if (!await _signedIn()) {
      return;
    }
    // Sau khi đăng nhập, review có thể là của chính mình (server không cho tự thích)
    final fresh = _places.reviewsOf(_id).where((r) => r.id == review.id).firstOrNull;
    if (fresh == null || fresh.mine) {
      return;
    }
    await _places.toggleLike(_id, review.id);
    _showControllerMessage();
  }

  Future<void> _report(PlaceDetail d, PlaceReview review) async {
    if (!await _signedIn() || !mounted) {
      return;
    }
    final reasons = (_places.detailOf(_id) ?? d).reportReasons;
    final choice = await showReportDialog(context, reasons: reasons, title: 'Báo cáo review');
    if (choice == null) {
      return;
    }
    await _places.reportReview(_id, review.id, choice.reasonId, choice.note);
    _showControllerMessage();
  }

  Future<void> _speak(String text) async {
    await _places.speak(text);
    _showControllerMessage();
  }

  /// Viết review mới ([reviewId] null) hoặc sửa review của mình.
  Future<void> _openForm({int? reviewId}) async {
    if (!await _signedIn() || !mounted) {
      return;
    }
    final d = _places.detailOf(_id);
    if (d == null) {
      return;
    }
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => ReviewFormScreen(
          placeId: reviewId == null ? d.id : null,
          reviewId: reviewId ?? d.myReviewId,
          placeName: d.name,
        ),
      ),
    );
    if (saved == true && mounted) {
      showMessage(context, context.read<ReviewController>().takeMessage());
      await _afterReviewChanged();
    }
  }

  Future<void> _deleteReview(PlaceReview review) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Xóa review?'),
        content: const Text('Xóa review này? Điểm của review này sẽ được thu lại.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Xóa')),
        ],
      ),
    );
    if (confirmed != true || !mounted) {
      return;
    }
    final reviews = context.read<ReviewController>();
    final deleted = await reviews.deleteReview(review.id);
    if (!mounted) {
      return;
    }
    showMessage(context, reviews.takeMessage());
    if (deleted) {
      await _afterReviewChanged();
    }
  }

  /// Số review, số sao, review của mình đã đổi: tải lại địa điểm và ghim trên bản đồ.
  Future<void> _afterReviewChanged() async {
    await _places.loadPlace(_id);
    await _places.refreshMap();
  }
}
