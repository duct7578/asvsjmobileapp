import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/media_item.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_photo_viewer.dart';
import 'package:myasvsj/com.myasvsj.screen/media_image.dart';

/// Ảnh của bài ở màn chi tiết: một ảnh thì rộng hết khung, nhiều ảnh thì lưới 2 cột. Bấm ảnh để xem lớn.
/// App chưa phát video: video (đăng từ web) hiện một ô ghi chú.
class BlogMediaGrid extends StatelessWidget {
  const BlogMediaGrid({super.key, required this.media});

  final List<MediaItem> media;

  @override
  Widget build(BuildContext context) {
    final images = [
      for (final m in media)
        if (m.isImage) m,
    ];
    final videoCount = media.length - images.length;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (images.length == 1)
          _photo(context, images, 0, aspect: _aspect(images.first))
        else if (images.length > 1)
          GridView.count(
            crossAxisCount: 2,
            mainAxisSpacing: 6,
            crossAxisSpacing: 6,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            children: [for (var i = 0; i < images.length; i++) _photo(context, images, i)],
          ),
        if (videoCount > 0)
          Padding(
            padding: EdgeInsets.only(top: images.isEmpty ? 0 : 8),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Row(
                children: [
                  Icon(Icons.videocam_outlined),
                  SizedBox(width: 8),
                  Expanded(child: Text('Bài có video. App chưa phát được video, hãy xem trên trang web.')),
                ],
              ),
            ),
          ),
      ],
    );
  }

  static double _aspect(MediaItem image) {
    final w = image.width;
    final h = image.height;
    if (w == null || h == null || w <= 0 || h <= 0) {
      return 4 / 3;
    }
    // Ảnh quá dài hoặc quá dẹt bị cắt bớt cho vừa màn hình
    return (w / h).clamp(0.75, 2.0);
  }

  Widget _photo(BuildContext context, List<MediaItem> images, int index, {double aspect = 1}) {
    return Semantics(
      button: true,
      label: 'Xem ảnh ${index + 1}',
      child: GestureDetector(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute<void>(
            builder: (_) => BlogPhotoViewer(urls: [for (final m in images) m.url], initialIndex: index),
          ),
        ),
        child: AspectRatio(
          aspectRatio: aspect,
          child: MediaImage(url: images[index].url),
        ),
      ),
    );
  }
}
