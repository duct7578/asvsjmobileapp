import 'package:flutter/material.dart';

/// Một kết quả tìm kiếm: biểu tượng bên trái, tiêu đề, các dòng phụ; cả ô mở mục đó. [trailing] là nút phụ
/// (ví dụ "Nghe" của mẫu câu).
class SearchHitTile extends StatelessWidget {
  const SearchHitTile({
    super.key,
    required this.icon,
    required this.title,
    this.children = const [],
    required this.onTap,
    this.trailing,
  });

  final IconData icon;
  final Widget title;
  final List<Widget> children;
  final VoidCallback onTap;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Icon(icon, size: 20, color: theme.colorScheme.primary),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  DefaultTextStyle.merge(style: theme.textTheme.titleSmall, child: title),
                  for (final child in children) Padding(padding: const EdgeInsets.only(top: 2), child: child),
                ],
              ),
            ),
            ?trailing,
          ],
        ),
      ),
    );
  }
}
