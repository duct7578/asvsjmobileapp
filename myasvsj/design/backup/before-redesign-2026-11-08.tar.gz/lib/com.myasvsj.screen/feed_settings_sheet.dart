import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.screen/area_stage_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/home_format.dart';
import 'package:myasvsj/com.myasvsj.screen/interest_screen.dart';

/// "Điều chỉnh" gợi ý: hỏi muốn đổi khu vực và giai đoạn hay chủ đề quan tâm, rồi mở màn hình tương ứng
/// (của trang Tôi). Trả về true khi màn hình đó đã lưu (đóng bằng pop(true)), để màn hình gọi tải lại gợi ý.
Future<bool> showFeedSettings(BuildContext context) async {
  final choice = await showModalBottomSheet<int>(
    context: context,
    showDragHandle: true,
    builder: (sheet) => SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Text('Điều chỉnh gợi ý dành cho bạn', style: Theme.of(sheet).textTheme.titleMedium),
          ),
          ListTile(
            leading: const Icon(Icons.location_on_outlined),
            title: const Text('Khu vực và giai đoạn'),
            subtitle: const Text('Chỉ lưu khu vực (quận, thành phố), không lưu địa chỉ hay vị trí.'),
            onTap: () => Navigator.pop(sheet, 0),
          ),
          ListTile(
            leading: const Icon(Icons.interests_outlined),
            title: const Text('Chủ đề quan tâm'),
            subtitle: const Text('Bài thuộc chủ đề bạn chọn được ưu tiên trong gợi ý.'),
            onTap: () => Navigator.pop(sheet, 1),
          ),
        ],
      ),
    ),
  );
  if (choice == null || !context.mounted) {
    return false;
  }
  return openFeedSetting(context, areaAndStage: choice == 0);
}

/// Mở thẳng màn "Khu vực và giai đoạn" ([areaAndStage]) hoặc "Chủ đề quan tâm"; true khi đã lưu.
Future<bool> openFeedSetting(BuildContext context, {required bool areaAndStage}) async {
  final saved = await pushScreen<bool>(context, areaAndStage ? const AreaStageScreen() : const InterestScreen());
  return saved == true;
}
