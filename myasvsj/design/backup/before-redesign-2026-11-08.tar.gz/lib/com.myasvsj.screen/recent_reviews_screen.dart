import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/home_controller.dart';
import 'package:myasvsj/com.myasvsj.model/recent_review_feed.dart';
import 'package:myasvsj/com.myasvsj.screen/empty_view.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/feed_settings_sheet.dart';
import 'package:myasvsj/com.myasvsj.screen/home_format.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/map_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/recent_review_card.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// "Review mới" ("Tất cả" của thẻ "Review mới quanh …", `GET /api/home/reviews`): review địa điểm của người khác,
/// mới nhất trước, 10 mỗi lần, trong phạm vi Quanh khu vực / Cả tỉnh / Tất cả. Khách và thành viên chưa chọn khu
/// vực chỉ có "Tất cả" (kèm lời mời). Mỗi review mở địa điểm của nó.
class RecentReviewsScreen extends StatefulWidget {
  const RecentReviewsScreen({super.key});

  @override
  State<RecentReviewsScreen> createState() => _RecentReviewsScreenState();
}

class _RecentReviewsScreenState extends State<RecentReviewsScreen> {
  bool _started = false;
  int? _userId;

  @override
  Widget build(BuildContext context) {
    final userId = context.select<AuthController, int?>((auth) => auth.currentUser?.id);
    if (!_started || userId != _userId) {
      // Lần đầu, hoặc vừa đăng nhập / đăng xuất: phạm vi chọn được đã đổi, mở lại từ đầu
      _started = true;
      _userId = userId;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          context.read<HomeController>().openReviews();
        }
      });
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Review mới')),
      body: _body(context.watch<HomeController>(), signedIn: userId != null),
    );
  }

  Widget _body(HomeController home, {required bool signedIn}) {
    final feed = home.reviewFeed;
    if (feed == null) {
      if (home.reviewsError != null && !home.isLoadingReviews) {
        return ErrorView(message: home.reviewsError!, onRetry: home.openReviews);
      }
      return const LoadingView();
    }
    final theme = Theme.of(context);
    final reviews = home.reviews;
    return RefreshIndicator(
      onRefresh: home.loadReviews,
      child: NotificationListener<ScrollNotification>(
        onNotification: (n) {
          // Cuộn gần tới cuối thì tải trang sau (sau khung hình đang vẽ)
          if (n is ScrollUpdateNotification && n.metrics.extentAfter < 200) {
            Future.microtask(home.loadMoreReviews);
          }
          return false;
        },
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            Text(
              '${feed.countOf(feed.scope)} review ${_scopeText(feed, feed.scope)}, mới nhất trước. '
              'Bấm vào một review để xem địa điểm.',
              style: theme.textTheme.bodySmall,
            ),
            if ((feed.areaName ?? '').isEmpty) _areaHint(home, signedIn: signedIn),
            if (feed.scopes.length >= 2) ...[
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  for (final s in feed.scopes)
                    ChoiceChip(
                      label: Text('${_scopeName(feed, s.code)} · ${s.count}'),
                      selected: s.code == feed.scope,
                      onSelected: (_) {
                        if (s.code != feed.scope) {
                          home.loadReviews(scope: s.code);
                        }
                      },
                    ),
                ],
              ),
            ],
            const SizedBox(height: 8),
            if (home.isLoadingReviews) const LinearProgressIndicator(),
            if (home.reviewsError != null)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text(home.reviewsError!, style: TextStyle(color: theme.colorScheme.error)),
              ),
            if (reviews.isEmpty && !home.isLoadingReviews) ...[
              EmptyView(
                text: feed.scope == 'ALL'
                    ? 'Chưa có review nào. Mở Bản đồ để viết review đầu tiên.'
                    : 'Chưa có review nào ${_scopeText(feed, feed.scope)}. Mở Bản đồ để viết review đầu tiên.',
                icon: Icons.rate_review_outlined,
              ),
              Center(
                child: TextButton(
                  onPressed: () => pushScreen<void>(context, const MapScreen()),
                  child: const Text('Mở Bản đồ'),
                ),
              ),
            ],
            for (final review in reviews) RecentReviewCard(review: review),
            if (feed.hasMore)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Center(
                  child: home.isLoadingMoreReviews
                      ? const CircularProgressIndicator()
                      : OutlinedButton(onPressed: home.loadMoreReviews, child: const Text('Xem thêm review')),
                ),
              ),
          ],
        ),
      ),
    );
  }

  /// Khách và thành viên chưa chọn khu vực chỉ thấy "Tất cả": cách xem review quanh mình.
  Widget _areaHint(HomeController home, {required bool signedIn}) {
    return Card(
      margin: const EdgeInsets.only(top: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              signedIn ? 'Chọn khu vực để xem review quanh bạn.' : 'Đăng nhập và chọn khu vực để xem review quanh bạn.',
            ),
            const SizedBox(height: 4),
            signedIn
                ? TextButton(
                    onPressed: () async {
                      if (await openFeedSetting(context, areaAndStage: true)) {
                        home.openReviews();
                      }
                    },
                    child: const Text('Chọn khu vực'),
                  )
                : FilledButton(onPressed: () => requireSignIn(context), child: const Text('Đăng nhập')),
          ],
        ),
      ),
    );
  }

  /// Tên nút phạm vi: "Quanh Arakawa-ku", "Cả tỉnh Tokyo", "Tất cả".
  static String _scopeName(RecentReviewFeed feed, String code) => switch (code) {
    'AREA' => 'Quanh ${areaShort(feed.areaName)}',
    'PREFECTURE' => 'Cả tỉnh ${feed.prefectureName ?? ''}',
    _ => 'Tất cả',
  };

  /// "quanh Arakawa-ku", "trong tỉnh Tokyo", "trên Senpai ơi".
  static String _scopeText(RecentReviewFeed feed, String code) => switch (code) {
    'AREA' => 'quanh ${areaShort(feed.areaName)}',
    'PREFECTURE' => 'trong tỉnh ${feed.prefectureName ?? ''}',
    _ => 'trên Senpai ơi',
  };
}
