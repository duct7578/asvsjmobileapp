import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/author.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';
import 'package:myasvsj/com.myasvsj.screen/question_badge.dart';

/// Dòng người viết của câu hỏi / câu trả lời: chữ cái đầu, tên, tag định danh, cấp bậc, thời gian, "đã sửa".
class QuestionAuthorRow extends StatelessWidget {
  const QuestionAuthorRow({
    super.key,
    required this.author,
    this.createdAt,
    this.edited = false,
    this.showRank = true,
    this.trailing,
  });

  /// null khi tài khoản không còn.
  final Author? author;
  final DateTime? createdAt;
  final bool edited;
  final bool showRank;

  /// Nút thêm ở cuối dòng (ví dụ "Nhắn tin").
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final name = author?.displayName.isNotEmpty == true ? author!.displayName : 'Tài khoản không còn';
    final when = [if (createdAt != null) formatTimeAgo(createdAt!), if (edited) 'đã sửa'].join(' · ');
    return Wrap(
      spacing: 6,
      runSpacing: 4,
      crossAxisAlignment: WrapCrossAlignment.center,
      children: [
        CircleAvatar(
          radius: 12,
          backgroundColor: scheme.primaryContainer,
          child: Text(
            name.characters.first.toUpperCase(),
            style: theme.textTheme.labelSmall?.copyWith(color: scheme.onPrimaryContainer),
          ),
        ),
        ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 200),
          child: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: theme.textTheme.labelLarge),
        ),
        for (final tag in author?.tagNames ?? const <String>[])
          QuestionBadge(label: tag, background: scheme.secondaryContainer, foreground: scheme.onSecondaryContainer),
        if (showRank && (author?.rankName.isNotEmpty ?? false))
          QuestionBadge(label: author!.rankName, icon: Icons.workspace_premium_outlined),
        if (when.isNotEmpty) Text(when, style: theme.textTheme.bodySmall),
        ?trailing,
      ],
    );
  }
}
