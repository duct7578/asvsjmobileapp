import 'package:flutter/material.dart';

/// Hàng 5 ngôi sao cho điểm [rating] (làm tròn tới nửa sao), chỉ để xem.
class PlaceRatingStars extends StatelessWidget {
  const PlaceRatingStars({super.key, required this.rating, this.size = 16});

  final double rating;
  final double size;

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.tertiary;
    final halves = (rating * 2).round();
    return Semantics(
      label: '${rating.toStringAsFixed(rating == rating.roundToDouble() ? 0 : 1)} trên 5 sao',
      child: ExcludeSemantics(
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            for (var i = 1; i <= 5; i++)
              Icon(
                halves >= i * 2 ? Icons.star : (halves == i * 2 - 1 ? Icons.star_half : Icons.star_border),
                size: size,
                color: color,
              ),
          ],
        ),
      ),
    );
  }
}
