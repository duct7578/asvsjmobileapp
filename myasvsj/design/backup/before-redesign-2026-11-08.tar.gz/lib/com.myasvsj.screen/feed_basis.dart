import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.screen/home_format.dart';

/// "Dựa trên": những gì Senpai ơi dựa vào để gợi ý (khu vực, giai đoạn, chủ đề đã chọn, chủ đề rút ra từ những gì
/// người dùng làm), nút "Điều chỉnh" và dòng giải thích. Dùng ở trang chủ và màn "Dành cho bạn".
class FeedBasis extends StatelessWidget {
  const FeedBasis({
    super.key,
    this.areaName,
    this.stage,
    this.interests = const [],
    this.chosenInterests = const [],
    required this.onAdjust,
  });

  final String? areaName;
  final String? stage;
  final List<String> interests;
  final List<String> chosenInterests;
  final VoidCallback onAdjust;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final area = areaName ?? '';
    final stageCode = stage ?? '';
    final chosen = chosenInterests.toSet();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 6,
          runSpacing: 6,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            Text('Dựa trên', style: theme.textTheme.labelMedium),
            area.isEmpty
                ? const _BasisChip(icon: Icons.location_off_outlined, text: 'Chưa chọn khu vực', off: true)
                : _BasisChip(icon: Icons.location_on_outlined, text: areaShort(area), what: 'Khu vực'),
            stageCode.isEmpty
                ? const _BasisChip(icon: Icons.flag_outlined, text: 'Chưa chọn giai đoạn', off: true)
                : _BasisChip(icon: Icons.flag_outlined, text: stageName(stageCode), what: 'Giai đoạn'),
            for (final topic in interests)
              chosen.contains(topic)
                  ? _BasisChip(icon: Icons.interests_outlined, text: topic, what: 'Chủ đề bạn chọn')
                  : _BasisChip(icon: Icons.history, text: topic, what: 'Chủ đề bạn hay đọc', off: true),
            TextButton.icon(
              onPressed: onAdjust,
              icon: const Icon(Icons.tune, size: 18),
              label: const Text('Điều chỉnh'),
            ),
          ],
        ),
        Text(
          interestNote(interests: interests.length, chosen: chosen.length),
          style: theme.textTheme.bodySmall,
        ),
      ],
    );
  }
}

class _BasisChip extends StatelessWidget {
  const _BasisChip({required this.icon, required this.text, this.what = '', this.off = false});

  final IconData icon;
  final String text;

  /// Tên cho trình đọc màn hình, ví dụ "Khu vực: Arakawa-ku".
  final String what;

  /// Chưa chọn, hoặc chủ đề tự rút ra (nhạt hơn).
  final bool off;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final foreground = off ? scheme.onSurfaceVariant : scheme.onSecondaryContainer;
    return Semantics(
      label: what.isEmpty ? text : '$what: $text',
      excludeSemantics: true,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: off ? scheme.surfaceContainerHighest : scheme.secondaryContainer,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 14, color: foreground),
            const SizedBox(width: 4),
            Flexible(
              child: Text(
                text,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.labelMedium?.copyWith(color: foreground),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
