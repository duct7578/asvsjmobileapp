import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/global_search_controller.dart';
import 'package:myasvsj/com.myasvsj.model/search_result.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/home_format.dart';
import 'package:myasvsj/com.myasvsj.screen/map_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/question_form_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/search_result_list.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// "Tìm kiếm" chung (`GET /api/search?q=`): một từ khóa tìm cùng lúc trong địa điểm, bài viết, Hỏi-Đáp, cẩm nang,
/// sự kiện, mẫu câu và câu hỏi thường gặp. Gõ xong chờ một chút thì tìm, Enter thì tìm ngay. Ai cũng dùng được.
class GlobalSearchScreen extends StatefulWidget {
  const GlobalSearchScreen({super.key, this.initialQuery = ''});

  /// Chữ đã gõ ở ô tìm kiếm của trang chủ; rỗng thì mở với ô trống và gợi ý.
  final String initialQuery;

  @override
  State<GlobalSearchScreen> createState() => _GlobalSearchScreenState();
}

class _GlobalSearchScreenState extends State<GlobalSearchScreen> {
  /// Gõ xong chờ chừng này mới hỏi server (như web).
  static const _typingDelay = Duration(milliseconds: 300);

  late final TextEditingController _text = TextEditingController(text: _clip(widget.initialQuery));
  Timer? _typing;

  static String _clip(String text) =>
      text.length > GlobalSearchController.queryMax ? text.substring(0, GlobalSearchController.queryMax) : text;

  @override
  void initState() {
    super.initState();
    // Gọi sau khung hình đầu: notifyListeners() không được chạy giữa lúc đang dựng giao diện
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) {
        return;
      }
      context.read<GlobalSearchController>()
        ..reset()
        ..search(_text.text, always: true);
    });
  }

  @override
  void dispose() {
    _typing?.cancel();
    _text.dispose();
    super.dispose();
  }

  void _searchNow([String? text]) {
    _typing?.cancel();
    if (text != null) {
      _text.text = text;
    }
    setState(() {});
    context.read<GlobalSearchController>().search(_text.text, always: true);
  }

  @override
  Widget build(BuildContext context) {
    final search = context.watch<GlobalSearchController>();
    final isMember = context.select<AuthController, bool>((auth) => auth.currentUser?.isMember ?? false);
    return Scaffold(
      appBar: AppBar(title: const Text('Tìm kiếm')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: TextField(
              key: const ValueKey('global-search'),
              controller: _text,
              autofocus: widget.initialQuery.trim().isEmpty,
              textInputAction: TextInputAction.search,
              inputFormatters: [LengthLimitingTextInputFormatter(GlobalSearchController.queryMax)],
              onChanged: (text) {
                setState(() {});
                _typing?.cancel();
                _typing = Timer(_typingDelay, () => search.search(text));
              },
              onSubmitted: (_) => _searchNow(),
              decoration: InputDecoration(
                hintText: 'Tìm địa điểm, bài viết, sự kiện…',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _text.text.isEmpty
                    ? null
                    : IconButton(tooltip: 'Xóa', icon: const Icon(Icons.clear), onPressed: () => _searchNow('')),
                border: const OutlineInputBorder(),
                isDense: true,
              ),
            ),
          ),
          if (search.isLoading) const LinearProgressIndicator() else const SizedBox(height: 4),
          Expanded(child: _results(search, isMember)),
        ],
      ),
    );
  }

  Widget _results(GlobalSearchController search, bool isMember) {
    final asked = search.asked;
    final error = search.error;
    if (asked == null) {
      // Chưa có câu trả lời nào: đang tìm, hoặc lần tìm đầu bị lỗi
      return error == null ? const SizedBox.shrink() : ErrorView(message: error, onRetry: _searchNow);
    }
    final theme = Theme.of(context);
    final errorLine = error == null
        ? null
        : Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: Row(
              children: [
                Expanded(
                  child: Text(error, style: TextStyle(color: theme.colorScheme.error)),
                ),
                TextButton(onPressed: _searchNow, child: const Text('Thử lại')),
              ],
            ),
          );
    final result = search.result;
    final Widget body;
    if (asked.isEmpty || result == null) {
      body = _ideas(theme);
    } else if (result.tooShort) {
      body = _message('Hãy gõ ít nhất 2 chữ hoặc số (một chữ tiếng Nhật cũng được).');
    } else if (result.isEmpty) {
      body = _nothingFound(result, theme);
    } else {
      body = SearchResultList(result: result, isMember: isMember);
    }
    return Column(
      children: [
        ?errorLine,
        Expanded(child: body),
      ],
    );
  }

  Widget _message(String text) => ListView(padding: const EdgeInsets.all(16), children: [Text(text)]);

  /// Ô trống: những thứ du học sinh mới đến hay tìm.
  Widget _ideas(ThemeData theme) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text(
        'Gõ để tìm trong địa điểm, bài viết, Hỏi-Đáp, cẩm nang, sự kiện, mẫu câu tiếng Nhật và câu hỏi '
        'thường gặp.',
      ),
      const SizedBox(height: 12),
      Text('Thử tìm:', style: theme.textTheme.bodySmall),
      const SizedBox(height: 4),
      Wrap(
        spacing: 8,
        runSpacing: 4,
        children: [
          for (final idea in GlobalSearchController.ideas)
            ActionChip(label: Text(idea), onPressed: () => _searchNow(idea)),
        ],
      ),
    ],
  );

  /// Không tìm thấy gì: gợi ý viết lại, tìm trên Bản đồ, hoặc đặt câu hỏi (khách được mời đăng nhập trước).
  Widget _nothingFound(SearchResult result, ThemeData theme) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Text('Không tìm thấy kết quả nào cho “${result.q}”.'),
      const SizedBox(height: 12),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Gợi ý', style: theme.textTheme.titleSmall),
              const SizedBox(height: 4),
              const Text('• Thử từ khóa ngắn hơn hoặc viết cách khác; có dấu hay không dấu đều được.'),
              const SizedBox(height: 4),
              const Text('• Bản đồ có cả địa điểm của OpenStreetMap.'),
              TextButton.icon(
                onPressed: () => pushScreen<void>(context, const MapScreen()),
                icon: const Icon(Icons.map_outlined),
                label: const Text('Mở Bản đồ'),
              ),
              const Text('• Chưa ai hỏi điều này?'),
              TextButton.icon(
                onPressed: _ask,
                icon: const Icon(Icons.contact_support_outlined),
                label: const Text('Đặt câu hỏi cho các senpai'),
              ),
            ],
          ),
        ),
      ),
    ],
  );

  /// Đặt câu hỏi cần tài khoản: khách được đưa sang Đăng nhập trước.
  Future<void> _ask() async {
    if (!await requireSignIn(context) || !mounted) {
      return;
    }
    await pushScreen<void>(context, const QuestionFormScreen());
  }
}
