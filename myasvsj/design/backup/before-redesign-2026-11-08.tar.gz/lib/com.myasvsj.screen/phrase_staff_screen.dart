import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import 'package:myasvsj/com.myasvsj.controller/phrase_controller.dart';
import 'package:myasvsj/com.myasvsj.model/phrase.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';

/// "Đưa cho nhân viên xem": mẫu câu tiếng Nhật thật to trên cả màn hình để đưa điện thoại cho nhân viên cửa hàng,
/// kèm nghĩa và nút "Nghe phát âm". Màn hình được giữ sáng trong lúc mở và tắt giữ sáng khi rời màn.
class PhraseStaffScreen extends StatefulWidget {
  const PhraseStaffScreen({super.key, required this.phrase, this.keepScreenOn = _keepScreenOn});

  final Phrase phrase;

  /// Bật (true) / tắt (false) giữ màn hình sáng. Mặc định dùng wakelock_plus; test truyền hàm giả.
  final Future<void> Function(bool on) keepScreenOn;

  @override
  State<PhraseStaffScreen> createState() => _PhraseStaffScreenState();
}

Future<void> _keepScreenOn(bool on) async {
  try {
    await WakelockPlus.toggle(enable: on);
  } on Exception {
    // Máy không hỗ trợ giữ sáng: vẫn hiện mẫu câu như thường
  }
}

class _PhraseStaffScreenState extends State<PhraseStaffScreen> {
  late final PhraseController _phrases;

  @override
  void initState() {
    super.initState();
    _phrases = context.read<PhraseController>();
    widget.keepScreenOn(true);
  }

  @override
  void dispose() {
    widget.keepScreenOn(false);
    _phrases.stopSpeaking();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final phrase = widget.phrase;
    return Scaffold(
      appBar: AppBar(title: const Text('Đưa cho nhân viên xem')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Text(
                'Đưa màn hình này cho nhân viên',
                style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.outline),
              ),
              Expanded(
                child: Center(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Text(
                          phrase.japanese,
                          locale: const Locale('ja'),
                          textAlign: TextAlign.center,
                          style: theme.textTheme.displayMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: theme.colorScheme.onSurface,
                          ),
                        ),
                        const SizedBox(height: 24),
                        Text(phrase.meaningVi, textAlign: TextAlign.center, style: theme.textTheme.titleMedium),
                      ],
                    ),
                  ),
                ),
              ),
              Wrap(
                spacing: 12,
                runSpacing: 8,
                alignment: WrapAlignment.center,
                children: [
                  OutlinedButton.icon(
                    onPressed: _speak,
                    icon: const Icon(Icons.volume_up_outlined),
                    label: const Text('Nghe phát âm'),
                  ),
                  FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Đóng')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _speak() async {
    final spoken = await _phrases.speak(widget.phrase.japanese);
    if (!spoken && mounted) {
      showMessage(context, _phrases.takeMessage());
    }
  }
}
