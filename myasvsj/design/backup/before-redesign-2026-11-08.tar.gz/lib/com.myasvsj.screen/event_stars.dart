import 'package:flutter/material.dart';

/// Năm ngôi sao của một review hoặc điểm trung bình (làm tròn tới sao gần nhất).
class EventStars extends StatelessWidget {
  const EventStars({super.key, required this.rating, this.size = 16});

  /// 0 đến 5.
  final double rating;
  final double size;

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.tertiary;
    final full = rating.round();
    return Semantics(
      label: '${rating.toStringAsFixed(rating == rating.roundToDouble() ? 0 : 1)} trên 5 sao',
      excludeSemantics: true,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (var i = 1; i <= 5; i++) Icon(i <= full ? Icons.star : Icons.star_border, size: size, color: color),
        ],
      ),
    );
  }
}
