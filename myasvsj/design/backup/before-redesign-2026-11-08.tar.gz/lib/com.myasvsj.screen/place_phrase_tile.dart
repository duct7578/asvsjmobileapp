import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/place_phrase.dart';

/// Một từ vựng / mẫu câu tiếng Nhật dùng ở địa điểm, có nút "Nghe" (giọng ja-JP).
class PlacePhraseTile extends StatelessWidget {
  const PlacePhraseTile({super.key, required this.phrase, required this.onSpeak});

  final PlacePhrase phrase;
  final VoidCallback onSpeak;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 4, 8),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(phrase.kindLabel, style: theme.textTheme.labelSmall),
                  Text(phrase.japanese, style: theme.textTheme.titleMedium),
                  if (phrase.romaji.isNotEmpty)
                    Text(phrase.romaji, style: theme.textTheme.bodySmall?.copyWith(fontStyle: FontStyle.italic)),
                  if (phrase.meaningVi.isNotEmpty) Text(phrase.meaningVi),
                ],
              ),
            ),
            IconButton(tooltip: 'Nghe', icon: const Icon(Icons.volume_up_outlined), onPressed: onSpeak),
          ],
        ),
      ),
    );
  }
}
