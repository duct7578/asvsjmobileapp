import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/guide.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';
import 'package:myasvsj/com.myasvsj.screen/media_image.dart';

/// Thẻ một cẩm nang trong danh sách: ảnh bìa, chủ đề, tiêu đề, tóm tắt, giai đoạn và ngày tạo.
class GuideCard extends StatelessWidget {
  const GuideCard({super.key, required this.guide, this.onTap});

  final Guide guide;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final cover = guide.coverImageUrl;
    final created = guide.createdAt;
    final meta = [
      if (guide.stageName != null && guide.stageName!.isNotEmpty) guide.stageName!,
      if (created != null) formatDate(created),
    ].join(' · ');
    return Card(
      clipBehavior: Clip.antiAlias,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (cover != null && cover.isNotEmpty)
                MediaImage(url: cover, width: 88, height: 88)
              else
                Container(
                  width: 88,
                  height: 88,
                  decoration: BoxDecoration(color: scheme.primaryContainer, borderRadius: BorderRadius.circular(8)),
                  child: Icon(Icons.menu_book_outlined, color: scheme.onPrimaryContainer, size: 36),
                ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      guide.topicName ?? 'Cẩm nang',
                      style: theme.textTheme.labelMedium?.copyWith(color: scheme.primary),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(guide.title, style: theme.textTheme.titleSmall, maxLines: 2, overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 4),
                    Text(
                      guide.summary.isEmpty ? 'Hướng dẫn dành cho sinh viên Việt Nam tại Nhật Bản.' : guide.summary,
                      style: theme.textTheme.bodySmall,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    if (meta.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(
                        meta,
                        style: theme.textTheme.bodySmall?.copyWith(color: scheme.onSurfaceVariant),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
