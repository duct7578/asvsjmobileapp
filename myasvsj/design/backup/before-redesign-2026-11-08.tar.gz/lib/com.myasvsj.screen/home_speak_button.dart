import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

/// Nút "Nghe": đọc câu tiếng Nhật bằng giọng đọc có sẵn của máy (miễn phí, không gọi server).
/// [compact] là nút chỉ có biểu tượng, cho danh sách kết quả tìm kiếm.
class HomeSpeakButton extends StatefulWidget {
  const HomeSpeakButton({super.key, required this.text, this.compact = false});

  final String text;
  final bool compact;

  @override
  State<HomeSpeakButton> createState() => _HomeSpeakButtonState();
}

class _HomeSpeakButtonState extends State<HomeSpeakButton> {
  /// Chỉ tạo khi bấm lần đầu.
  FlutterTts? _tts;

  @override
  void dispose() {
    _tts?.stop();
    super.dispose();
  }

  Future<void> _speak() async {
    try {
      final tts = _tts ??= FlutterTts();
      await tts.setLanguage('ja-JP');
      await tts.setSpeechRate(0.45);
      await tts.stop();
      await tts.speak(widget.text);
    } catch (_) {
      // Máy không có giọng đọc tiếng Nhật: bỏ qua, câu vẫn hiện trên màn hình
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.compact) {
      return IconButton(tooltip: 'Nghe ${widget.text}', icon: const Icon(Icons.volume_up_outlined), onPressed: _speak);
    }
    return OutlinedButton.icon(
      onPressed: _speak,
      icon: const Icon(Icons.volume_up_outlined),
      label: const Text('Nghe'),
    );
  }
}
