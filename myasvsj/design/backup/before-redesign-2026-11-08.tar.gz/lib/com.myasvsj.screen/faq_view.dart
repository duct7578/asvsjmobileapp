import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/faq_controller.dart';
import 'package:myasvsj/com.myasvsj.screen/empty_view.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/faq_tile.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/question_form_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// Nội dung "Câu hỏi thường gặp", dùng chung cho tab thứ hai của Hỏi-Đáp và màn FaqScreen: ô tìm, chủ đề kèm số câu,
/// danh sách mở rộng tại chỗ, tải thêm, kéo xuống làm mới.
///
/// Có [faqId]: mở sẵn đúng câu đó (như `/qa?tab=faq&id=` của web), kèm nút "Xem tất cả câu hỏi thường gặp".
class FaqView extends StatefulWidget {
  const FaqView({super.key, this.faqId});

  final int? faqId;

  @override
  State<FaqView> createState() => _FaqViewState();
}

class _FaqViewState extends State<FaqView> {
  static const _searchDelay = Duration(milliseconds: 400);

  final _search = TextEditingController();
  Timer? _debounce;

  /// Đang hiện riêng câu [FaqView.faqId] thay vì cả danh sách.
  late bool _single = widget.faqId != null;

  /// Từ khóa của Controller lần cuối màn hình thấy: đổi từ nơi khác (nút "Tìm trong Câu hỏi thường gặp" của tab
  /// câu hỏi) thì chép vào ô tìm.
  String _seenQuery = '';

  @override
  void initState() {
    super.initState();
    final faq = context.read<FaqController>();
    _search.text = faq.query;
    _seenQuery = faq.query;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!faq.hasLoaded && !faq.isLoading) {
        faq.loadFaqs();
      }
      if (widget.faqId != null) {
        faq.loadEntry(widget.faqId!);
      }
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final faq = context.watch<FaqController>();
    if (faq.query != _seenQuery) {
      _seenQuery = faq.query;
      if (_search.text.trim() != faq.query) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) {
            _search.text = faq.query;
          }
        });
      }
    }
    return NotificationListener<ScrollNotification>(
      onNotification: (n) {
        // Cuộn dọc gần tới cuối: tải trang sau (bỏ qua hàng chủ đề cuộn ngang)
        if (!_single && n.metrics.axis == Axis.vertical && n.metrics.extentAfter < 300) {
          faq.loadMore();
        }
        return false;
      },
      child: RefreshIndicator(
        onRefresh: () => Future.wait([faq.loadFaqs(), if (_single) faq.loadEntry(widget.faqId!)]),
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.only(bottom: 96),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
              child: Text(
                'Những thắc mắc phổ biến được Moderator tổng hợp và kiểm tra, nhiều câu lấy từ câu trả lời hay nhất '
                'của cộng đồng.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
            _searchBox(faq),
            if (faq.topics.isNotEmpty) _topicChips(faq),
            if (_single) ..._singleEntry(faq) else ..._list(faq),
          ],
        ),
      ),
    );
  }

  Widget _searchBox(FaqController faq) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
      child: TextField(
        controller: _search,
        maxLength: 200,
        textInputAction: TextInputAction.search,
        decoration: InputDecoration(
          hintText: 'Tìm câu hỏi thường gặp, ví dụ: mua SIM, đổ rác',
          prefixIcon: const Icon(Icons.search),
          counterText: '',
          border: const OutlineInputBorder(),
          isDense: true,
          suffixIcon: _search.text.isEmpty
              ? null
              : IconButton(
                  tooltip: 'Xóa từ khóa',
                  icon: const Icon(Icons.clear),
                  onPressed: () {
                    _search.clear();
                    _runSearch(faq, '');
                  },
                ),
        ),
        onChanged: (text) {
          setState(() {});
          _debounce?.cancel();
          _debounce = Timer(_searchDelay, () => _runSearch(faq, text));
        },
        onSubmitted: (text) => _runSearch(faq, text),
      ),
    );
  }

  void _runSearch(FaqController faq, String text) {
    _debounce?.cancel();
    if (_single) {
      setState(() => _single = false);
    }
    if (text.trim() != faq.query || faq.error != null) {
      faq.search(text);
    }
  }

  Widget _topicChips(FaqController faq) {
    // "Tất cả" và các chủ đề đang có câu (khớp từ khóa), như web
    final chips = [
      (code: '', title: 'Tất cả', count: faq.allCount),
      for (final t in faq.topics)
        if (t.count > 0 || t.code == faq.topicCode) (code: t.code, title: t.title, count: t.count),
    ];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: Row(
        children: [
          for (final t in chips)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: ChoiceChip(
                label: Text('${t.title} (${t.count})'),
                selected: !_single && faq.topicCode == t.code,
                onSelected: (_) {
                  setState(() => _single = false);
                  faq.selectTopic(t.code);
                },
              ),
            ),
        ],
      ),
    );
  }

  /// Một câu mở riêng.
  List<Widget> _singleEntry(FaqController faq) {
    final id = widget.faqId!;
    final entry = faq.entryOf(id);
    final showAll = Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: OutlinedButton.icon(
        onPressed: () {
          setState(() => _single = false);
          if (faq.isFiltered) {
            _search.clear();
            faq.clearFilters();
          }
        },
        icon: const Icon(Icons.arrow_back),
        label: const Text('Xem tất cả câu hỏi thường gặp'),
      ),
    );
    if (entry == null && faq.isLoadingEntry(id)) {
      return const [Padding(padding: EdgeInsets.all(32), child: LoadingView())];
    }
    if (entry == null) {
      return [
        EmptyView(
          text: faq.entryError(id) ?? 'Câu hỏi thường gặp này không còn hoặc đã được ẩn.',
          icon: Icons.search_off,
        ),
        showAll,
      ];
    }
    return [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
        child: Text('Chủ đề: ${entry.topicName}', style: Theme.of(context).textTheme.bodySmall),
      ),
      FaqTile(entry: entry, initiallyExpanded: true, showOpenLink: false),
      showAll,
    ];
  }

  /// Danh sách theo bộ lọc.
  List<Widget> _list(FaqController faq) {
    final theme = Theme.of(context);
    final q = faq.query.trim();
    if (faq.isLoading && faq.entries.isEmpty && faq.related.isEmpty) {
      return const [Padding(padding: EdgeInsets.all(32), child: LoadingView())];
    }
    if (faq.error != null) {
      return [ErrorView(message: faq.error!, onRetry: faq.loadFaqs)];
    }
    if (faq.entries.isEmpty) {
      if (faq.related.isNotEmpty) {
        return [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: Text(
              'Không có câu nào chứa đúng “$q”${faq.topicCode.isNotEmpty ? ' trong chủ đề này' : ''}. '
              'Những câu có thể liên quan:',
              style: theme.textTheme.bodyMedium,
            ),
          ),
          for (final entry in faq.related) FaqTile(entry: entry),
          _askCard(),
        ];
      }
      return [
        EmptyView(
          text: faq.isFiltered
              ? 'Không có câu hỏi thường gặp nào khớp với lựa chọn của bạn. Chưa thấy lời giải? Hãy hỏi các senpai.'
              : 'Chưa có câu hỏi thường gặp nào.',
          icon: Icons.quiz_outlined,
        ),
        Wrap(
          alignment: WrapAlignment.center,
          spacing: 8,
          children: [
            FilledButton.icon(
              onPressed: _ask,
              icon: const Icon(Icons.contact_support_outlined),
              label: const Text('Đặt câu hỏi'),
            ),
            if (faq.isFiltered)
              OutlinedButton(
                onPressed: () {
                  _search.clear();
                  faq.clearFilters();
                },
                child: const Text('Xóa bộ lọc'),
              ),
          ],
        ),
      ];
    }
    return [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
        child: Text(
          '${faq.totalItems} câu hỏi thường gặp${faq.isFiltered ? ' phù hợp' : ''}',
          style: theme.textTheme.bodySmall,
        ),
      ),
      for (final entry in faq.entries) FaqTile(entry: entry),
      if (faq.isLoadingMore)
        const Padding(padding: EdgeInsets.all(16), child: LoadingView())
      else if (faq.hasMore)
        Center(
          child: TextButton(onPressed: faq.loadMore, child: Text(faq.moreError ?? 'Tải thêm')),
        ),
      _askCard(),
    ];
  }

  /// "Chưa thấy câu trả lời?" như cột bên của web.
  Widget _askCard() {
    final theme = Theme.of(context);
    return Card(
      margin: const EdgeInsets.fromLTRB(12, 12, 12, 0),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Chưa thấy câu trả lời?', style: theme.textTheme.titleSmall),
            const SizedBox(height: 4),
            const Text('Hỏi cộng đồng, các senpai đã trải qua sẽ trả lời bạn.'),
            const SizedBox(height: 8),
            FilledButton.tonalIcon(
              onPressed: _ask,
              icon: const Icon(Icons.contact_support_outlined),
              label: const Text('Đặt câu hỏi'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _ask() async {
    if (!await requireSignIn(context) || !mounted) {
      return;
    }
    await Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const QuestionFormScreen()));
  }
}
