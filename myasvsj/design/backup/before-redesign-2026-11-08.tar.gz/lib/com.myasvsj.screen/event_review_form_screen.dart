import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/event_controller.dart';
import 'package:myasvsj/com.myasvsj.model/event_review_form.dart';
import 'package:myasvsj/com.myasvsj.model/media_item.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/event_text.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/media_image.dart';
import 'package:myasvsj/com.myasvsj.screen/photo_picker.dart';

/// Form "Viết review" của một sự kiện (`GET /api/events/{id}/review-form`): viết review năm nay, hoặc sửa review
/// năm nay khi đã viết. Số sao + nội dung + tối đa 5 ảnh (app không gửi video).
///
/// Lưu xong thì đóng và trả về true để màn trước hiện câu thông báo của server ([EventController.takeMessage]).
class EventReviewFormScreen extends StatefulWidget {
  const EventReviewFormScreen({super.key, required this.eventId});

  final int eventId;

  @override
  State<EventReviewFormScreen> createState() => _EventReviewFormScreenState();
}

class _EventReviewFormScreenState extends State<EventReviewFormScreen> {
  final _content = TextEditingController();
  int _rating = 0;

  /// Ảnh / video đã đăng của review đang sửa, còn giữ lại.
  List<MediaItem> _kept = [];

  /// Ảnh mới chọn trên máy.
  List<String> _photos = [];

  /// Đã bắt đầu tải form: trước đó Controller có thể còn giữ form / lỗi của lần mở trước.
  bool _opened = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final events = context.read<EventController>();
    _opened = true;
    await events.openReviewForm(widget.eventId);
    final own = events.form?.review;
    if (!mounted || own == null) {
      return;
    }
    setState(() {
      _rating = own.rating;
      _content.text = own.content;
      _kept = List.of(own.media);
    });
  }

  @override
  void dispose() {
    _content.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final events = context.watch<EventController>();
    final form = _opened ? events.form : null;
    final editing = form?.isEditing ?? false;
    return Scaffold(
      appBar: AppBar(title: Text(editing ? 'Sửa review' : 'Viết review')),
      body: _body(events, form),
    );
  }

  Widget _body(EventController events, EventReviewForm? form) {
    if (!_opened || events.isLoadingForm) {
      return const LoadingView();
    }
    if (form == null) {
      // Không mở được form: sự kiện chưa bắt đầu, đã bị xóa, chưa đăng nhập…
      return ErrorView(message: events.formError ?? 'Không tải được sự kiện.', onRetry: _load);
    }
    final theme = Theme.of(context);
    final errors = events.fieldErrors;
    final event = form.event;
    final keptImages = _kept.where((m) => m.isImage).length;
    final room = form.imagesMax - keptImages;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(event.title, style: theme.textTheme.titleLarge),
        const SizedBox(height: 4),
        Text(
          'Review cho lần tổ chức năm ${event.reviewYear} · ${eventDateRange(event)}',
          style: theme.textTheme.bodySmall,
        ),
        if (form.newAccount && !form.isEditing) _quota(form),
        if (events.formError != null)
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Text(events.formError!, style: TextStyle(color: theme.colorScheme.error)),
          ),
        const SizedBox(height: 16),
        Text('Đánh giá *', style: theme.textTheme.titleSmall),
        Row(
          children: [
            for (var n = 1; n <= 5; n++)
              IconButton(
                tooltip: '$n sao',
                isSelected: n <= _rating,
                icon: Icon(n <= _rating ? Icons.star : Icons.star_border, color: theme.colorScheme.tertiary),
                onPressed: events.isSaving ? null : () => setState(() => _rating = n),
              ),
          ],
        ),
        if (errors['rating'] != null) Text(errors['rating']!, style: TextStyle(color: theme.colorScheme.error)),
        const SizedBox(height: 12),
        TextField(
          controller: _content,
          minLines: 5,
          maxLines: 12,
          maxLength: form.contentMax,
          enabled: !events.isSaving,
          decoration: InputDecoration(
            labelText: 'Nội dung *',
            hintText: 'Không khí, chi phí, nên đi giờ nào',
            alignLabelWithHint: true,
            border: const OutlineInputBorder(),
            errorText: errors['content'],
            helperText: form.canPostLinks ? null : 'Chỉ tài khoản có tag định danh mới chèn được link.',
            helperMaxLines: 2,
          ),
        ),
        if (_kept.isNotEmpty) ...[
          const SizedBox(height: 12),
          Text('Ảnh đã đăng', style: theme.textTheme.titleSmall),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [for (final m in _kept) _keptTile(m)]),
        ],
        const SizedBox(height: 12),
        PhotoPicker(
          paths: _photos,
          max: room < 0 ? 0 : room,
          label: _kept.isEmpty ? 'Ảnh' : 'Ảnh mới',
          onChanged: (paths) => setState(() => _photos = paths),
        ),
        Text(
          'Tối đa ${form.imagesMax} ảnh, mỗi ảnh không quá ${form.imageMaxMb} MB.',
          style: theme.textTheme.bodySmall,
        ),
        if (errors['images'] != null) Text(errors['images']!, style: TextStyle(color: theme.colorScheme.error)),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: events.isSaving ? null : () => _save(events),
          icon: const Icon(Icons.send),
          label: Text(events.isSaving ? 'Đang gửi…' : (form.isEditing ? 'Lưu thay đổi' : 'Đăng review')),
        ),
        const SizedBox(height: 8),
        Text(
          'Chữ được lọc từ khóa ngay. Ảnh được quét sau khi đăng; trong lúc đó review ở trạng thái '
          '“đang xử lý” và chỉ bạn thấy.',
          style: theme.textTheme.bodySmall,
        ),
      ],
    );
  }

  /// "Tài khoản mới, hôm nay: 1/3 bài viết và review · 0/2 ghim · 0/1 video." (BR-07), chỉ khi viết mới.
  Widget _quota(EventReviewForm form) {
    final scheme = Theme.of(context).colorScheme;
    final full = form.quotaFull;
    return Container(
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: full ? scheme.errorContainer : scheme.secondaryContainer,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        'Tài khoản mới, hôm nay: ${form.postsUsed}/${form.postsLimit} bài viết và review · '
        '${form.pinsUsed}/${form.pinsLimit} ghim · ${form.videosUsed}/${form.videosLimit} video.'
        '${full ? ' Bạn đã dùng hết lượt đăng hôm nay, hãy quay lại vào ngày mai.' : ''}',
        style: TextStyle(color: full ? scheme.onErrorContainer : scheme.onSecondaryContainer),
      ),
    );
  }

  Widget _keptTile(MediaItem media) {
    final scheme = Theme.of(context).colorScheme;
    return Stack(
      children: [
        if (media.isImage)
          MediaImage(url: media.url, width: 80, height: 80)
        else
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(color: scheme.surfaceContainerHighest, borderRadius: BorderRadius.circular(8)),
            child: const Icon(Icons.videocam_outlined),
          ),
        Positioned(
          right: 0,
          top: 0,
          child: InkWell(
            onTap: () => setState(() => _kept = [..._kept]..remove(media)),
            child: Tooltip(
              message: media.isImage ? 'Bỏ ảnh' : 'Bỏ video',
              child: const CircleAvatar(radius: 12, child: Icon(Icons.close, size: 16)),
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _save(EventController events) async {
    final saved = await events.saveReview(
      rating: _rating,
      content: _content.text,
      keepMediaIds: [for (final m in _kept) m.id],
      imagePaths: _photos,
    );
    if (saved && mounted) {
      Navigator.pop(context, true);
    }
  }
}
