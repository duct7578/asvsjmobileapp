import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/home_controller.dart';
import 'package:myasvsj/com.myasvsj.screen/app_bar_actions.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/home_guest_view.dart';
import 'package:myasvsj/com.myasvsj.screen/home_member_view.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';

/// Tab "Trang chủ". Khách thấy lời mời, số liệu, review "Hữu ích" và câu tiếng Nhật hôm nay (`GET /api/home`);
/// thành viên thấy "Dành cho bạn", "Việc tiếp theo", review quanh khu vực, sự kiện, mẫu câu, bài nổi bật
/// (`GET /api/me/home`). Đăng nhập hoặc đăng xuất (đổi người dùng) thì tự tải lại đúng loại trang chủ.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _started = false;

  /// Người dùng của lần tải gần nhất (null là khách).
  int? _userId;

  Future<void> _reload({String? notice}) =>
      context.read<HomeController>().loadHome(signedIn: context.read<AuthController>().isSignedIn, notice: notice);

  @override
  Widget build(BuildContext context) {
    final userId = context.select<AuthController, int?>((auth) => auth.currentUser?.id);
    if (!_started || userId != _userId) {
      _started = true;
      _userId = userId;
      // Gọi sau khung hình đầu: notifyListeners() không được chạy giữa lúc đang dựng giao diện
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          _reload();
        }
      });
    }
    final home = context.watch<HomeController>();
    return Scaffold(
      appBar: AppBar(title: const Text('Senpai ơi'), actions: const [AppBarActions()]),
      body: _body(home, signedIn: userId != null),
    );
  }

  Widget _body(HomeController home, {required bool signedIn}) {
    final member = signedIn ? home.member : null;
    final guest = signedIn ? null : home.guest;
    if (member == null && guest == null) {
      if (home.homeError != null && !home.isLoadingHome) {
        return ErrorView(message: home.homeError!, onRetry: _reload);
      }
      return const LoadingView();
    }
    // Đã có trang chủ mà tải lại bị lỗi: giữ trang cũ, báo lỗi ở đầu
    final banner = home.homeError == null
        ? null
        : Card(
            color: Theme.of(context).colorScheme.errorContainer,
            child: ListTile(
              leading: const Icon(Icons.error_outline),
              title: Text(home.homeError!),
              trailing: TextButton(onPressed: _reload, child: const Text('Thử lại')),
            ),
          );
    return RefreshIndicator(
      onRefresh: _reload,
      child: member != null
          ? HomeMemberView(
              home: member,
              banner: banner,
              notice: home.homeNotice,
              showAreaPrompt: home.showAreaPrompt,
              onHidePrompt: home.hideAreaPrompt,
              onSettingsSaved: () => _reload(notice: HomeController.savedNotice),
            )
          : HomeGuestView(home: guest!, banner: banner),
    );
  }
}
