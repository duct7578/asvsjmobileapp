import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/auth_notice.dart';
import 'package:myasvsj/com.myasvsj.screen/legal_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/login_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/password_field.dart';
import 'package:myasvsj/com.myasvsj.screen/password_rules.dart';

/// Đăng ký bằng email trong 3 bước như trang /register: 1. Email → 2. Mã xác thực → 3. Mật khẩu.
///
/// Tạo xong tài khoản, app đăng nhập luôn rồi đóng màn hình, trả về true khi đã đăng nhập.
class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key, this.fromLogin = false});

  /// Mở từ màn Đăng nhập: link "Đăng nhập" chỉ cần quay lại màn trước.
  final bool fromLogin;

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _email = TextEditingController();
  final _code = TextEditingController();
  final _displayName = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  bool _adult = false;
  bool _acceptTerms = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<AuthController>().startRegistration());
  }

  @override
  void dispose() {
    _email.dispose();
    _code.dispose();
    _displayName.dispose();
    _password.dispose();
    _confirm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    return Scaffold(
      appBar: AppBar(title: const Text('Đăng ký')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Tạo tài khoản', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 4),
          const Text('Miễn phí, dành cho người từ 18 tuổi. Chỉ mất khoảng một phút.'),
          const SizedBox(height: 16),
          _StepBar(step: auth.registerStep),
          const SizedBox(height: 16),
          if (auth.bannerError != null) AuthNotice(text: auth.bannerError!),
          ...switch (auth.registerStep) {
            2 => _codeStep(auth),
            3 => _passwordStep(auth),
            _ => _emailStep(auth),
          },
          const SizedBox(height: 16),
          Wrap(
            alignment: WrapAlignment.center,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              const Text('Đã có tài khoản?'),
              TextButton(onPressed: auth.isLoading ? null : _openLogin, child: const Text('Đăng nhập')),
            ],
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------- Bước 1: email

  List<Widget> _emailStep(AuthController auth) => [
    TextField(
      controller: _email,
      keyboardType: TextInputType.emailAddress,
      autofillHints: const [AutofillHints.email],
      autocorrect: false,
      textInputAction: TextInputAction.done,
      onSubmitted: (_) => _sendCode(),
      decoration: InputDecoration(
        labelText: 'Email',
        helperText: 'Chúng tôi sẽ gửi mã xác thực 6 số tới email này.',
        errorText: auth.fieldErrors['email'],
        errorMaxLines: 3,
      ),
    ),
    const SizedBox(height: 16),
    FilledButton(
      onPressed: auth.isLoading ? null : _sendCode,
      child: Text(auth.isLoading ? 'Đang gửi…' : 'Gửi mã xác thực'),
    ),
  ];

  Future<void> _sendCode() async {
    final auth = context.read<AuthController>();
    final sent = await auth.sendRegisterCode(_email.text);
    if (sent && mounted) {
      _code.clear();
      showMessage(context, auth.takeMessage());
    }
  }

  // ---------------------------------------------------------------- Bước 2: mã xác thực

  List<Widget> _codeStep(AuthController auth) {
    final sent = auth.registerCode;
    final wait = auth.resendSecondsLeft;
    return [
      Row(
        children: [
          const Icon(Icons.mail_outline, size: 20),
          const SizedBox(width: 8),
          Expanded(child: Text(auth.registerEmail, maxLines: 1, overflow: TextOverflow.ellipsis)),
          TextButton(onPressed: auth.isLoading ? null : auth.changeRegisterEmail, child: const Text('Đổi')),
        ],
      ),
      TextField(
        controller: _code,
        keyboardType: TextInputType.number,
        autofillHints: const [AutofillHints.oneTimeCode],
        maxLength: AuthController.codeLength,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        style: const TextStyle(letterSpacing: 6, fontSize: 20),
        onChanged: (value) {
          // Đủ 6 số thì tự gửi, như trang web
          if (value.length == AuthController.codeLength) {
            _verify();
          }
        },
        onSubmitted: (_) => _verify(),
        decoration: InputDecoration(
          labelText: 'Mã xác thực',
          helperText: 'Mã có hiệu lực trong ${sent?.expiresInMinutes ?? 10} phút. Nhớ kiểm tra cả hộp thư Spam.',
          helperMaxLines: 2,
          errorText: auth.fieldErrors['code'],
          errorMaxLines: 3,
          counterText: '',
        ),
      ),
      Wrap(
        alignment: WrapAlignment.spaceBetween,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          const Text('Chưa nhận được mã?'),
          TextButton(
            onPressed: auth.isLoading || wait > 0 ? null : _resend,
            child: Text(wait > 0 ? 'Gửi lại sau ${wait}s' : 'Gửi lại mã'),
          ),
        ],
      ),
      const SizedBox(height: 8),
      FilledButton(
        onPressed: auth.isLoading ? null : _verify,
        child: Text(auth.isLoading ? 'Đang kiểm tra…' : 'Xác nhận'),
      ),
    ];
  }

  Future<void> _resend() async {
    final auth = context.read<AuthController>();
    final sent = await auth.resendRegisterCode();
    if (sent && mounted) {
      _code.clear();
      showMessage(context, auth.takeMessage());
    }
  }

  Future<void> _verify() async {
    final auth = context.read<AuthController>();
    if (auth.isLoading) {
      return;
    }
    final ok = await auth.verifyRegisterCode(_code.text);
    if (!mounted) {
      return;
    }
    if (ok) {
      showMessage(context, auth.takeMessage());
    } else {
      _code.selection = TextSelection(baseOffset: 0, extentOffset: _code.text.length);
    }
  }

  // ---------------------------------------------------------------- Bước 3: tên, mật khẩu, đồng ý

  List<Widget> _passwordStep(AuthController auth) {
    final errors = auth.fieldErrors;
    final errorStyle = TextStyle(color: Theme.of(context).colorScheme.error);
    return [
      TextField(
        controller: _displayName,
        maxLength: AuthController.displayNameMax,
        autofillHints: const [AutofillHints.nickname],
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          labelText: 'Tên hiển thị',
          helperText: 'Tên này hiện trên review và bài viết của bạn.',
          errorText: errors['displayName'],
        ),
      ),
      const SizedBox(height: 8),
      PasswordField(
        controller: _password,
        label: 'Mật khẩu',
        isNewPassword: true,
        errorText: errors['password'],
        textInputAction: TextInputAction.next,
      ),
      const SizedBox(height: 4),
      PasswordRules(controller: _password, minLength: auth.passwordMinLength),
      const SizedBox(height: 12),
      PasswordField(
        controller: _confirm,
        label: 'Nhập lại mật khẩu',
        isNewPassword: true,
        errorText: errors['confirmPassword'],
        textInputAction: TextInputAction.done,
      ),
      const SizedBox(height: 8),
      CheckboxListTile(
        value: _adult,
        onChanged: (on) => setState(() => _adult = on ?? false),
        controlAffinity: ListTileControlAffinity.leading,
        contentPadding: EdgeInsets.zero,
        title: const Text('Tôi xác nhận mình đã đủ 18 tuổi.'),
        subtitle: errors['adultConfirmed'] == null ? null : Text(errors['adultConfirmed']!, style: errorStyle),
      ),
      CheckboxListTile(
        value: _acceptTerms,
        onChanged: (on) => setState(() => _acceptTerms = on ?? false),
        controlAffinity: ListTileControlAffinity.leading,
        contentPadding: EdgeInsets.zero,
        title: const Text('Tôi đồng ý với Điều khoản sử dụng, Chính sách bảo mật và Quy tắc cộng đồng.'),
        subtitle: errors['acceptTerms'] == null ? null : Text(errors['acceptTerms']!, style: errorStyle),
      ),
      Wrap(
        spacing: 4,
        children: [
          _legalLink('Điều khoản sử dụng', 'terms'),
          _legalLink('Chính sách bảo mật', 'privacy'),
          _legalLink('Quy tắc cộng đồng', 'community'),
        ],
      ),
      const SizedBox(height: 8),
      FilledButton(
        onPressed: auth.isLoading ? null : _complete,
        child: Text(auth.isLoading ? 'Đang tạo tài khoản…' : 'Tạo tài khoản'),
      ),
    ];
  }

  Widget _legalLink(String label, String type) => TextButton.icon(
    icon: const Icon(Icons.open_in_new, size: 16),
    label: Text(label),
    onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => LegalScreen(type: type))),
  );

  Future<void> _complete() async {
    final auth = context.read<AuthController>();
    final created = await auth.completeRegistration(
      displayName: _displayName.text,
      password: _password.text,
      confirmPassword: _confirm.text,
      adultConfirmed: _adult,
      acceptTerms: _acceptTerms,
    );
    if (!created || !mounted) {
      return;
    }
    TextInput.finishAutofillContext();
    showMessage(context, auth.takeMessage());
    Navigator.pop(context, auth.isSignedIn);
  }

  void _openLogin() {
    if (widget.fromLogin) {
      Navigator.pop(context, false);
    } else {
      Navigator.pushReplacement(context, MaterialPageRoute<bool>(builder: (_) => const LoginScreen()));
    }
  }
}

/// Ba bước đăng ký, bước đang làm được tô đậm, bước đã xong có dấu tích.
class _StepBar extends StatelessWidget {
  const _StepBar({required this.step});

  final int step;

  static const _labels = ['Email', 'Mã xác thực', 'Mật khẩu'];

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Row(
      children: [
        for (var i = 0; i < _labels.length; i++)
          Expanded(
            child: Column(
              children: [
                CircleAvatar(
                  radius: 14,
                  backgroundColor: i + 1 <= step ? scheme.primary : scheme.surfaceContainerHighest,
                  foregroundColor: i + 1 <= step ? scheme.onPrimary : scheme.onSurfaceVariant,
                  child: i + 1 < step ? const Icon(Icons.check, size: 16) : Text('${i + 1}'),
                ),
                const SizedBox(height: 4),
                Text(
                  _labels[i],
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontWeight: i + 1 == step ? FontWeight.bold : FontWeight.normal),
                ),
              ],
            ),
          ),
      ],
    );
  }
}
