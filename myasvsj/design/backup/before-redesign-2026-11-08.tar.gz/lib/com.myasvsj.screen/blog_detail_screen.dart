import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/blog_controller.dart';
import 'package:myasvsj/com.myasvsj.model/author.dart';
import 'package:myasvsj/com.myasvsj.model/blog.dart';
import 'package:myasvsj/com.myasvsj.model/blog_comment.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_author_line.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_badge.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_comment_bar.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_comment_tile.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_form_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_media_grid.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_place_list.dart';
import 'package:myasvsj/com.myasvsj.screen/chat_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/report_dialog.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// Màn hình chi tiết bài viết: ảnh, địa điểm liên quan, tác giả, cây bình luận; thích, lưu, báo cáo, bình luận,
/// trả lời, nhắn tin. Khách đọc được; bấm thao tác thì được đưa sang đăng nhập. Tác giả thấy thêm Sửa và Xóa.
class BlogDetailScreen extends StatefulWidget {
  const BlogDetailScreen({super.key, required this.blogId});

  final int blogId;

  @override
  State<BlogDetailScreen> createState() => _BlogDetailScreenState();
}

class _BlogDetailScreenState extends State<BlogDetailScreen> {
  static const _statusNotes = {
    'PROCESSING': 'Ảnh của bài đang được quét. Trong lúc này chỉ bạn thấy bài.',
    'HIDDEN': 'Bài đang tạm ẩn vì có nhiều báo cáo, chờ Moderator xem xét.',
    'REJECTED': 'Bài chưa được đăng vì vi phạm Quy tắc cộng đồng. Bạn có thể sửa rồi gửi lại.',
  };

  final _comment = TextEditingController();
  final _commentFocus = FocusNode();

  /// Bình luận đang được trả lời; null khi viết bình luận mới.
  BlogComment? _replyTo;

  /// Người đang đăng nhập lần vẽ trước: đổi (vừa đăng nhập, đăng xuất) thì tải lại cờ thích, lưu, tác giả.
  int? _userId;

  int get _id => widget.blogId;

  @override
  void initState() {
    super.initState();
    _userId = context.read<AuthController>().currentUser?.id;
    // Gọi sau khung hình đầu: notifyListeners() không được chạy giữa lúc đang dựng giao diện
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final blogs = context.read<BlogController>()..clearCommentError();
      blogs.loadBlog(_id);
    });
  }

  @override
  void dispose() {
    _comment.dispose();
    _commentFocus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final blogs = context.watch<BlogController>();
    final userId = context.select<AuthController, int?>((auth) => auth.currentUser?.id);
    if (userId != _userId) {
      _userId = userId;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          context.read<BlogController>().loadBlog(_id, quiet: true);
        }
      });
    }
    final blog = blogs.blogById(_id);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bài viết'),
        actions: [
          if (blog != null && blog.canEdit)
            IconButton(tooltip: 'Sửa bài', icon: const Icon(Icons.edit_outlined), onPressed: () => _edit(blog)),
          if (blog != null && blog.isMine)
            IconButton(tooltip: 'Xóa bài', icon: const Icon(Icons.delete_outline), onPressed: () => _delete(blog)),
        ],
      ),
      body: _body(blogs, blog),
    );
  }

  Widget _body(BlogController blogs, Blog? blog) {
    if (blog == null) {
      final error = blogs.blogError(_id);
      if (error == null) {
        return const LoadingView();
      }
      return ErrorView(message: error, onRetry: () => blogs.loadBlog(_id));
    }
    return Column(
      children: [
        Expanded(
          child: RefreshIndicator(
            onRefresh: () => blogs.loadBlog(_id, quiet: true),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
              children: [..._post(blog), ..._comments(blog)],
            ),
          ),
        ),
        _composer(blogs, blog),
      ],
    );
  }

  // ---------------------------------------------------------------- bài

  List<Widget> _post(Blog blog) {
    final theme = Theme.of(context);
    final note = _statusNotes[blog.status];
    final author = blog.author;
    return [
      if (note != null)
        Card(
          color: theme.colorScheme.tertiaryContainer,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Icon(
                  blog.isProcessing ? Icons.hourglass_top : Icons.block,
                  color: theme.colorScheme.onTertiaryContainer,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(note, style: TextStyle(color: theme.colorScheme.onTertiaryContainer)),
                ),
              ],
            ),
          ),
        ),
      if (blog.pinned)
        const Align(
          alignment: Alignment.centerLeft,
          child: BlogBadge(icon: Icons.push_pin_outlined, label: 'Đã ghim'),
        ),
      const SizedBox(height: 4),
      Text(blog.title, style: theme.textTheme.headlineSmall),
      const SizedBox(height: 8),
      BlogAuthorLine(author: author, showRank: true),
      Row(
        children: [
          Expanded(
            child: Text(
              [if (blog.createdAt != null) formatTimeAgo(blog.createdAt!), if (blog.edited) 'đã sửa'].join(' · '),
              style: theme.textTheme.bodySmall,
            ),
          ),
          if (author != null && !blog.isMine && author.id != _userId)
            TextButton.icon(
              onPressed: () => _openChat(author),
              icon: const Icon(Icons.chat_outlined, size: 18),
              label: const Text('Nhắn tin'),
            ),
        ],
      ),
      if (blog.topics.isNotEmpty)
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: [
            for (final topic in blog.topics)
              Chip(
                label: Text(topic.name),
                avatar: const Icon(Icons.sell_outlined, size: 16),
                visualDensity: VisualDensity.compact,
              ),
          ],
        ),
      if (blog.media.isNotEmpty) ...[const SizedBox(height: 12), BlogMediaGrid(media: blog.media)],
      const SizedBox(height: 12),
      SelectableText(blog.content, style: theme.textTheme.bodyLarge),
      if (blog.places.isNotEmpty) ...[const SizedBox(height: 16), BlogPlaceList(places: blog.places)],
      const SizedBox(height: 12),
      _actionBar(blog),
    ];
  }

  Widget _actionBar(Blog blog) {
    // Đã đăng nhập nhưng không thao tác được (bài chưa đăng): nút mờ. Khách vẫn bấm được để sang đăng nhập.
    final blocked = _userId != null && !blog.canInteract;
    return Wrap(
      spacing: 8,
      runSpacing: 4,
      crossAxisAlignment: WrapCrossAlignment.center,
      children: [
        if (blog.isMine)
          Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: Text('♥ ${blog.likeCount} lượt thích'))
        else if (blog.isLiked)
          FilledButton.icon(
            onPressed: blocked ? null : () => _like(blog),
            icon: const Icon(Icons.favorite),
            label: Text('Thích · ${blog.likeCount}'),
          )
        else
          OutlinedButton.icon(
            onPressed: blocked ? null : () => _like(blog),
            icon: const Icon(Icons.favorite_border),
            label: Text('Thích · ${blog.likeCount}'),
          ),
        OutlinedButton.icon(
          onPressed: blocked ? null : () => _save(blog),
          icon: Icon(blog.isSaved ? Icons.bookmark_added : Icons.bookmark_border),
          label: Text(blog.isSaved ? 'Đã lưu' : 'Lưu'),
        ),
        if (!blog.isMine && blog.isPublished)
          TextButton.icon(
            onPressed: blocked ? null : () => _reportBlog(blog),
            icon: const Icon(Icons.flag_outlined),
            label: const Text('Báo cáo'),
          ),
      ],
    );
  }

  // ---------------------------------------------------------------- bình luận

  List<Widget> _comments(Blog blog) {
    final theme = Theme.of(context);
    return [
      const Divider(height: 32),
      Text('Bình luận (${blog.commentCount})', style: theme.textTheme.titleMedium),
      if (!blog.isPublished)
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text('Bài chưa được đăng nên chưa nhận bình luận.', style: theme.textTheme.bodySmall),
        ),
      if (blog.comments.isEmpty && blog.isPublished)
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text('Chưa có bình luận nào.', style: theme.textTheme.bodySmall),
        ),
      for (final comment in blog.comments)
        BlogCommentTile(
          comment: comment,
          canReply: blog.isPublished,
          canEdit: blog.canInteract,
          isSignedIn: _userId != null,
          onAction: (c, action) => _onCommentAction(blog, c, action),
        ),
    ];
  }

  /// Ô bình luận dưới cùng: khách thấy nút Đăng nhập; tài khoản chỉ xem được thì thấy ghi chú.
  Widget _composer(BlogController blogs, Blog blog) {
    if (!blog.isPublished) {
      return const SizedBox.shrink();
    }
    if (_userId == null || !blog.canInteract) {
      final guest = _userId == null;
      return Material(
        elevation: 3,
        color: Theme.of(context).colorScheme.surfaceContainer,
        child: SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 12, 8),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    guest
                        ? 'Đăng nhập để bình luận và thích bài viết.'
                        : 'Tài khoản của bạn chỉ xem được, không bình luận được.',
                  ),
                ),
                if (guest) FilledButton(onPressed: () => requireSignIn(context), child: const Text('Đăng nhập')),
              ],
            ),
          ),
        ),
      );
    }
    return BlogCommentBar(
      controller: _comment,
      focusNode: _commentFocus,
      replyName: _replyTo == null ? null : (_replyTo!.author?.displayName ?? 'bình luận'),
      isSending: blogs.isSendingComment,
      error: blogs.commentError,
      maxLength: BlogController.commentMax,
      onChanged: (_) => blogs.clearCommentError(),
      onCancelReply: () => setState(() => _replyTo = null),
      onSend: () => _sendComment(blogs),
    );
  }

  Future<void> _sendComment(BlogController blogs) async {
    final sent = await blogs.addComment(_id, _comment.text, parentId: _replyTo?.id);
    if (!sent || !mounted) {
      return;
    }
    _comment.clear();
    _commentFocus.unfocus();
    setState(() => _replyTo = null);
    showMessage(context, blogs.takeMessage());
  }

  Future<void> _onCommentAction(Blog blog, BlogComment comment, BlogCommentAction action) async {
    final blogs = context.read<BlogController>();
    switch (action) {
      case BlogCommentAction.like:
        if (await _signedIn()) {
          await blogs.toggleCommentLike(_id, comment.id);
        }
      case BlogCommentAction.reply:
        if (await _signedIn() && mounted) {
          setState(() => _replyTo = comment);
          _commentFocus.requestFocus();
        }
      case BlogCommentAction.edit:
        await _editComment(comment);
      case BlogCommentAction.delete:
        if (await _confirm('Xóa bình luận?', 'Bạn có chắc muốn xóa bình luận này?')) {
          await blogs.deleteComment(_id, comment.id);
        }
      case BlogCommentAction.report:
        if (await _signedIn() && mounted) {
          final choice = await showReportDialog(context, reasons: blog.reportReasons, title: 'Báo cáo bình luận');
          if (choice != null) {
            await blogs.reportComment(_id, comment.id, reasonId: choice.reasonId, note: choice.note);
          }
        }
      case BlogCommentAction.message:
        if (comment.author != null) {
          await _openChat(comment.author!);
        }
    }
    if (mounted) {
      showMessage(context, blogs.takeMessage());
    }
  }

  Future<void> _editComment(BlogComment comment) async {
    final text = await showDialog<String>(
      context: context,
      builder: (_) => _EditCommentDialog(initial: comment.content),
    );
    if (text == null || text.trim() == comment.content || !mounted) {
      return;
    }
    await context.read<BlogController>().updateComment(_id, comment.id, text);
  }

  // ---------------------------------------------------------------- thao tác với bài

  /// Thao tác cần tài khoản. Khách vừa đăng nhập xong thì chưa làm ngay: bài được tải lại (cờ thích, lưu, tác giả
  /// mới đúng với người vừa đăng nhập), người dùng bấm lại.
  Future<bool> _signedIn() async {
    final wasGuest = _userId == null;
    if (!await requireSignIn(context) || !mounted) {
      return false;
    }
    return !wasGuest;
  }

  Future<void> _like(Blog blog) async {
    if (!await _signedIn() || !mounted) {
      return;
    }
    final blogs = context.read<BlogController>();
    await blogs.toggleLike(_id);
    if (mounted) {
      showMessage(context, blogs.takeMessage());
    }
  }

  Future<void> _save(Blog blog) async {
    if (!await _signedIn() || !mounted) {
      return;
    }
    final blogs = context.read<BlogController>();
    await blogs.toggleSave(_id);
    if (mounted) {
      showMessage(context, blogs.takeMessage());
    }
  }

  Future<void> _reportBlog(Blog blog) async {
    if (!await _signedIn() || !mounted) {
      return;
    }
    final choice = await showReportDialog(context, reasons: blog.reportReasons, title: 'Báo cáo bài viết');
    if (choice == null || !mounted) {
      return;
    }
    final blogs = context.read<BlogController>();
    await blogs.reportBlog(_id, reasonId: choice.reasonId, note: choice.note);
    if (mounted) {
      showMessage(context, blogs.takeMessage());
    }
  }

  /// Nhắn tin riêng cho tác giả hoặc người bình luận (không phải chính mình).
  Future<void> _openChat(Author author) async {
    if (!await requireSignIn(context) || !mounted) {
      return;
    }
    if (context.read<AuthController>().currentUser?.id == author.id) {
      return;
    }
    await Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (_) => ChatScreen(withUserId: author.id, title: author.displayName),
      ),
    );
  }

  Future<void> _edit(Blog blog) async {
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => BlogFormScreen(blogId: blog.id)),
    );
    if (saved == true && mounted) {
      showMessage(context, context.read<BlogController>().takeMessage());
    }
  }

  Future<void> _delete(Blog blog) async {
    final confirmed = await _confirm(
      'Xóa bài viết?',
      'Bạn có chắc muốn xóa bài viết này? Bình luận của bài cũng bị xóa, và điểm bài đã nhận sẽ bị thu lại.',
    );
    if (!confirmed || !mounted) {
      return;
    }
    final blogs = context.read<BlogController>();
    final deleted = await blogs.deleteBlog(_id);
    if (!mounted) {
      return;
    }
    showMessage(context, blogs.takeMessage());
    if (deleted) {
      Navigator.pop(context);
    }
  }

  Future<bool> _confirm(String title, String text) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(title),
        content: Text(text),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Xóa')),
        ],
      ),
    );
    return confirmed == true;
  }
}

/// Hộp thoại sửa bình luận của mình: chữ cũ sẵn trong ô, "Lưu" / "Hủy".
class _EditCommentDialog extends StatefulWidget {
  const _EditCommentDialog({required this.initial});

  final String initial;

  @override
  State<_EditCommentDialog> createState() => _EditCommentDialogState();
}

class _EditCommentDialogState extends State<_EditCommentDialog> {
  late final _text = TextEditingController(text: widget.initial);

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Sửa bình luận'),
      content: TextField(
        controller: _text,
        autofocus: true,
        minLines: 2,
        maxLines: 6,
        maxLength: BlogController.commentMax,
        decoration: const InputDecoration(border: OutlineInputBorder()),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Hủy')),
        FilledButton(onPressed: () => Navigator.pop(context, _text.text), child: const Text('Lưu')),
      ],
    );
  }
}
