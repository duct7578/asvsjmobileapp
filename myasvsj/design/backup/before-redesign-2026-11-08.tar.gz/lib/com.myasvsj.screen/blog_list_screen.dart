import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/blog_controller.dart';
import 'package:myasvsj/com.myasvsj.screen/app_bar_actions.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_card.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_featured_list.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_form_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_stats_card.dart';
import 'package:myasvsj/com.myasvsj.screen/empty_view.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// Tab Blog: tìm kiếm, lọc chủ đề, sắp xếp, bài nổi bật, thống kê và danh sách bài (tải thêm khi cuộn tới cuối).
/// Nút "Viết bài" mở form tạo bài (khách được đưa sang đăng nhập trước).
class BlogListScreen extends StatefulWidget {
  const BlogListScreen({super.key});

  /// Nhãn của các cách sắp xếp (giống web).
  static const sortLabels = {'NEWEST': 'Mới nhất', 'LIKES': 'Nhiều thích', 'COMMENTS': 'Nhiều bình luận'};

  @override
  State<BlogListScreen> createState() => _BlogListScreenState();
}

class _BlogListScreenState extends State<BlogListScreen> {
  final _search = TextEditingController();
  final _scroll = ScrollController();

  /// Người đang đăng nhập lần vẽ trước: đổi thì tải lại (tác giả thấy thêm bài đang quét ảnh của mình).
  int? _userId;

  @override
  void initState() {
    super.initState();
    _scroll.addListener(_onScroll);
    _userId = context.read<AuthController>().currentUser?.id;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final blogs = context.read<BlogController>();
      _search.text = blogs.query;
      blogs.openList();
    });
  }

  @override
  void dispose() {
    _search.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scroll.position.extentAfter < 400) {
      context.read<BlogController>().loadMore();
    }
  }

  @override
  Widget build(BuildContext context) {
    final blogs = context.watch<BlogController>();
    final userId = context.select<AuthController, int?>((auth) => auth.currentUser?.id);
    if (userId != _userId) {
      _userId = userId;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          context.read<BlogController>().loadBlogs();
        }
      });
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Blog'), actions: const [AppBarActions()]),
      floatingActionButton: FloatingActionButton.extended(
        tooltip: 'Viết bài',
        onPressed: _openForm,
        icon: const Icon(Icons.edit_outlined),
        label: const Text('Viết bài'),
      ),
      body: RefreshIndicator(onRefresh: blogs.refresh, child: _list(blogs)),
    );
  }

  Widget _list(BlogController blogs) {
    final header = <Widget>[
      _searchField(blogs),
      _filterBar(blogs),
      if (blogs.isFiltered) _filterSummary(blogs),
      ..._overview(blogs),
      if (!blogs.isFiltered && blogs.blogs.isNotEmpty)
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: Text('${blogs.totalItems} bài', style: Theme.of(context).textTheme.bodySmall),
        ),
    ];
    final body = _bodyState(blogs);
    final items = blogs.blogs;
    return ListView.builder(
      controller: _scroll,
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.only(bottom: 88),
      itemCount: header.length + (body != null ? 1 : items.length + 1),
      itemBuilder: (context, i) {
        if (i < header.length) {
          return header[i];
        }
        if (body != null) {
          return body;
        }
        final index = i - header.length;
        if (index < items.length) {
          return BlogCard(blog: items[index], onTopicTap: (topic) => blogs.filterByTopic(topic.id));
        }
        return _footer(blogs);
      },
    );
  }

  /// Trạng thái thay cho danh sách: đang tải lần đầu, lỗi, rỗng. null khi có bài để hiện.
  Widget? _bodyState(BlogController blogs) {
    if (blogs.error != null) {
      return ErrorView(message: blogs.error!, onRetry: blogs.loadBlogs);
    }
    if (blogs.blogs.isEmpty && (blogs.isLoading || !blogs.isListLoaded)) {
      return const SizedBox(height: 240, child: LoadingView());
    }
    if (blogs.blogs.isEmpty) {
      if (blogs.isFiltered) {
        return Column(
          children: [
            const EmptyView(text: 'Không có bài viết nào khớp với lựa chọn của bạn.', icon: Icons.search_off),
            OutlinedButton(onPressed: _clearFilters, child: const Text('Xóa bộ lọc')),
          ],
        );
      }
      return const EmptyView(text: 'Chưa có bài viết nào.', icon: Icons.forum_outlined);
    }
    return null;
  }

  Widget _searchField(BlogController blogs) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
      child: TextField(
        controller: _search,
        maxLength: 100,
        textInputAction: TextInputAction.search,
        onSubmitted: blogs.search,
        onChanged: (_) => setState(() {}),
        decoration: InputDecoration(
          hintText: 'Tìm theo tiêu đề, nội dung hoặc địa điểm',
          prefixIcon: const Icon(Icons.search),
          counterText: '',
          isDense: true,
          border: const OutlineInputBorder(),
          suffixIcon: _search.text.isEmpty
              ? null
              : IconButton(
                  tooltip: 'Xóa từ khóa',
                  icon: const Icon(Icons.close),
                  onPressed: () {
                    _search.clear();
                    blogs.search('');
                    setState(() {});
                  },
                ),
        ),
      ),
    );
  }

  /// Chọn cách sắp xếp và các chủ đề (cuộn ngang).
  Widget _filterBar(BlogController blogs) {
    final topics = blogs.overview?.topics ?? const [];
    return SizedBox(
      height: 48,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        children: [
          PopupMenuButton<String>(
            tooltip: 'Sắp xếp',
            initialValue: blogs.sort,
            onSelected: blogs.setSort,
            itemBuilder: (_) => [
              for (final entry in BlogListScreen.sortLabels.entries)
                PopupMenuItem(value: entry.key, child: Text(entry.value)),
            ],
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Row(
                children: [
                  const Icon(Icons.sort, size: 20),
                  const SizedBox(width: 4),
                  Text(BlogListScreen.sortLabels[blogs.sort] ?? ''),
                  const Icon(Icons.arrow_drop_down),
                ],
              ),
            ),
          ),
          const SizedBox(width: 4),
          for (final topic in topics)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 4),
              child: FilterChip(
                label: Text(topic.name),
                selected: blogs.filterTopicIds.contains(topic.id),
                onSelected: (_) => blogs.toggleTopic(topic.id),
                visualDensity: VisualDensity.compact,
              ),
            ),
        ],
      ),
    );
  }

  Widget _filterSummary(BlogController blogs) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: Text(
              blogs.isLoading ? 'Đang tìm…' : '${blogs.totalItems} bài phù hợp',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ),
          TextButton.icon(
            onPressed: _clearFilters,
            icon: const Icon(Icons.close, size: 18),
            label: const Text('Xóa bộ lọc'),
          ),
        ],
      ),
    );
  }

  /// Bài nổi bật và thống kê: chỉ hiện khi không lọc, như web.
  List<Widget> _overview(BlogController blogs) {
    final overview = blogs.overview;
    if (overview == null || blogs.isFiltered) {
      return const [];
    }
    return [
      if (overview.featured.isNotEmpty) BlogFeaturedList(period: overview.featuredPeriod, posts: overview.featured),
      BlogStatsCard(overview: overview, onTopicTap: blogs.filterByTopic),
    ];
  }

  Widget _footer(BlogController blogs) {
    if (blogs.isLoadingMore) {
      return const Padding(
        padding: EdgeInsets.all(16),
        child: Center(child: CircularProgressIndicator()),
      );
    }
    if (blogs.loadMoreError != null) {
      return Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(blogs.loadMoreError!, textAlign: TextAlign.center),
            TextButton(onPressed: blogs.loadMore, child: const Text('Thử lại')),
          ],
        ),
      );
    }
    if (blogs.hasMore) {
      return Center(
        child: TextButton(onPressed: blogs.loadMore, child: const Text('Tải thêm')),
      );
    }
    return const SizedBox(height: 16);
  }

  void _clearFilters() {
    _search.clear();
    context.read<BlogController>().clearFilters();
  }

  /// Viết bài cần tài khoản User: khách được đưa sang đăng nhập trước.
  Future<void> _openForm() async {
    if (!await requireSignIn(context) || !mounted) {
      return;
    }
    final saved = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => const BlogFormScreen()));
    if (saved == true && mounted) {
      showMessage(context, context.read<BlogController>().takeMessage());
    }
  }
}
