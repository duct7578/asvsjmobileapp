import 'package:flutter/material.dart';

/// Nhãn nhỏ trong dòng phụ của kết quả ("Đã giải quyết", "Đang kiểm duyệt", tên chủ đề…).
class SearchBadge extends StatelessWidget {
  const SearchBadge({super.key, required this.text, this.warn = false});

  final String text;
  final bool warn;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 1),
      decoration: BoxDecoration(
        color: warn ? scheme.errorContainer : scheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        text,
        style: Theme.of(context).textTheme.labelSmall?.copyWith(color: warn ? scheme.onErrorContainer : null),
      ),
    );
  }
}
