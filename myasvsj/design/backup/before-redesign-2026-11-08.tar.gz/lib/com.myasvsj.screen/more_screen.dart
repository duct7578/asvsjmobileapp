import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.screen/app_bar_actions.dart';
import 'package:myasvsj/com.myasvsj.screen/conversation_list_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/event_list_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/faq_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/guide_list_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/legal_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/login_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/my_guides_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/notification_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/phrase_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/profile_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/register_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/saved_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// Tab "Thêm": gom Nhật ngữ, Sự kiện, Cẩm nang, FAQ, các mục cá nhân và văn bản pháp lý.
class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    return Scaffold(
      appBar: AppBar(title: const Text('Thêm'), actions: const [AppBarActions()]),
      body: ListView(
        children: [
          _tile(context, Icons.translate, 'Nhật ngữ', 'Mẫu câu, từ vựng, thẻ ghi nhớ', const PhraseScreen()),
          _tile(context, Icons.festival_outlined, 'Lễ hội và sự kiện', null, const EventListScreen()),
          _tile(context, Icons.menu_book_outlined, 'Cẩm nang', 'Theo từng giai đoạn', const GuideListScreen()),
          _tile(context, Icons.help_outline, 'Câu hỏi thường gặp', null, const FaqScreen()),
          const Divider(),
          if (auth.isSignedIn) ...[
            _tile(context, Icons.account_circle_outlined, 'Tôi', auth.currentUser?.displayName, const ProfileScreen()),
            _tile(context, Icons.chat_bubble_outline, 'Tin nhắn', null, const ConversationListScreen(), signIn: true),
            _tile(context, Icons.notifications_none, 'Thông báo', null, const NotificationScreen(), signIn: true),
            _tile(context, Icons.bookmark_border, 'Đã lưu', null, const SavedScreen(), signIn: true),
            _tile(context, Icons.checklist, 'Cẩm nang của tôi', null, const MyGuidesScreen(), signIn: true),
          ] else ...[
            _tile(context, Icons.login, 'Đăng nhập', null, const LoginScreen()),
            _tile(context, Icons.person_add_alt, 'Đăng ký', 'Miễn phí, dành cho người từ 18 tuổi', const RegisterScreen()),
          ],
          const Divider(),
          _tile(context, Icons.gavel_outlined, 'Điều khoản sử dụng', null, const LegalScreen(type: 'terms')),
          _tile(context, Icons.privacy_tip_outlined, 'Chính sách bảo mật', null, const LegalScreen(type: 'privacy')),
          _tile(context, Icons.groups_outlined, 'Quy tắc cộng đồng', null, const LegalScreen(type: 'community')),
        ],
      ),
    );
  }

  Widget _tile(BuildContext context, IconData icon, String title, String? subtitle, Widget screen,
      {bool signIn = false}) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      subtitle: subtitle == null ? null : Text(subtitle),
      trailing: const Icon(Icons.chevron_right),
      onTap: () async {
        if (signIn && (!await requireSignIn(context) || !context.mounted)) {
          return;
        }
        Navigator.push(context, MaterialPageRoute<void>(builder: (_) => screen));
      },
    );
  }
}
