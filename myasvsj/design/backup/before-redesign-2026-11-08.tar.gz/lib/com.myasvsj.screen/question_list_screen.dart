import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/faq_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/question_controller.dart';
import 'package:myasvsj/com.myasvsj.model/question_overview.dart';
import 'package:myasvsj/com.myasvsj.model/topic.dart';
import 'package:myasvsj/com.myasvsj.screen/app_bar_actions.dart';
import 'package:myasvsj/com.myasvsj.screen/empty_view.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/faq_tile.dart';
import 'package:myasvsj/com.myasvsj.screen/faq_view.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/question_card.dart';
import 'package:myasvsj/com.myasvsj.screen/question_form_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// Tab Hỏi-Đáp (tab thứ 4 của app), hai tab con giống trang `/qa` của web:
/// - "Câu hỏi": câu hỏi của cộng đồng, tìm, lọc trạng thái và chủ đề, sắp xếp, thống kê, FAQ liên quan khi tìm,
///   tải thêm khi cuộn, kéo xuống làm mới;
/// - "Câu hỏi thường gặp": FaqView.
///
/// Nút "Đặt câu hỏi" cần tài khoản: khách được đưa sang Đăng nhập trước.
class QuestionListScreen extends StatefulWidget {
  const QuestionListScreen({super.key, this.initialTab = 0, this.initialQuery = ''});

  /// 0 = Câu hỏi, 1 = Câu hỏi thường gặp.
  final int initialTab;

  /// Mở sẵn kết quả tìm từ khóa này trong tab [initialTab] (ví dụ "Xem tất cả … câu hỏi" của Tìm kiếm, như
  /// `/qa?q=` và `/qa?tab=faq&q=` của web). Rỗng = giữ bộ lọc đang có.
  final String initialQuery;

  @override
  State<QuestionListScreen> createState() => _QuestionListScreenState();
}

class _QuestionListScreenState extends State<QuestionListScreen> with SingleTickerProviderStateMixin {
  static const _searchDelay = Duration(milliseconds: 400);
  static const _statusLabels = {
    'ALL': 'Tất cả',
    'UNANSWERED': 'Chưa ai trả lời',
    'UNSOLVED': 'Chưa giải quyết',
    'SOLVED': 'Đã giải quyết',
  };
  static const _sortLabels = {'NEWEST': 'Mới nhất', 'LIKES': 'Nhiều thích', 'ANSWERS': 'Nhiều trả lời'};

  late final TabController _tabs = TabController(length: 2, vsync: this, initialIndex: widget.initialTab.clamp(0, 1));
  final _search = TextEditingController();
  Timer? _debounce;

  /// Người đang đăng nhập lần dựng trước: đổi (đăng nhập / đăng xuất) thì tải lại, vì người hỏi thấy cả câu hỏi
  /// của mình đang được quét ảnh.
  int? _userId;
  bool _userSeen = false;

  /// Từ khóa của Controller lần cuối màn hình thấy: đổi từ nơi khác (một màn Hỏi-Đáp khác) thì chép vào ô tìm.
  String _seenQuery = '';

  @override
  void initState() {
    super.initState();
    final questions = context.read<QuestionController>();
    final faq = context.read<FaqController>();
    final query = widget.initialQuery.trim();
    final searchQuestions = query.isNotEmpty && _tabs.index == 0;
    _search.text = searchQuestions ? query : questions.query;
    _seenQuery = _search.text;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (searchQuestions) {
        questions.search(query);
        faq.loadHits(query);
      } else if (!questions.hasLoaded && !questions.isLoading) {
        questions.loadQuestions();
      }
      if (query.isNotEmpty && _tabs.index == 1) {
        faq.search(query);
      }
      if (questions.overview == null) {
        questions.loadOverview();
      }
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _tabs.dispose();
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final userId = context.watch<AuthController>().currentUser?.id;
    if (_userSeen && userId != _userId) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          context.read<QuestionController>().loadQuestions();
        }
      });
    }
    _userSeen = true;
    _userId = userId;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Hỏi-Đáp'),
        actions: const [AppBarActions()],
        bottom: TabBar(
          controller: _tabs,
          tabs: const [
            Tab(text: 'Câu hỏi'),
            Tab(text: 'Câu hỏi thường gặp'),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'qa-ask',
        tooltip: 'Đặt câu hỏi',
        onPressed: _ask,
        icon: const Icon(Icons.contact_support_outlined),
        label: const Text('Đặt câu hỏi'),
      ),
      body: TabBarView(controller: _tabs, children: [_questionsTab(), const FaqView()]),
    );
  }

  // ---------------------------------------------------------------- Tab "Câu hỏi"

  Widget _questionsTab() {
    final c = context.watch<QuestionController>();
    final faq = context.watch<FaqController>();
    if (c.query != _seenQuery) {
      _seenQuery = c.query;
      if (_search.text.trim() != c.query) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) {
            _search.text = c.query;
          }
        });
      }
    }
    return NotificationListener<ScrollNotification>(
      onNotification: (n) {
        if (n.metrics.axis == Axis.vertical && n.metrics.extentAfter < 300) {
          c.loadMore();
        }
        return false;
      },
      child: RefreshIndicator(
        onRefresh: () => Future.wait([c.loadQuestions(), c.loadOverview(), faq.loadHits(c.query)]),
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(child: _searchBox(c, faq)),
            SliverToBoxAdapter(child: _filters(c)),
            if (c.overview != null && !c.isFiltered) SliverToBoxAdapter(child: _statsCard(c, c.overview!)),
            if (_showHits(c, faq)) SliverToBoxAdapter(child: _faqHits(c, faq)),
            ..._results(c),
            const SliverPadding(padding: EdgeInsets.only(bottom: 96)),
          ],
        ),
      ),
    );
  }

  Widget _searchBox(QuestionController c, FaqController faq) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
      child: TextField(
        controller: _search,
        maxLength: 100,
        textInputAction: TextInputAction.search,
        decoration: InputDecoration(
          hintText: 'Tìm câu hỏi theo nội dung hoặc địa điểm',
          prefixIcon: const Icon(Icons.search),
          counterText: '',
          border: const OutlineInputBorder(),
          isDense: true,
          suffixIcon: _search.text.isEmpty
              ? null
              : IconButton(
                  tooltip: 'Xóa từ khóa',
                  icon: const Icon(Icons.clear),
                  onPressed: () {
                    _search.clear();
                    _runSearch('');
                  },
                ),
        ),
        onChanged: (text) {
          setState(() {});
          _debounce?.cancel();
          _debounce = Timer(_searchDelay, () => _runSearch(text));
        },
        onSubmitted: _runSearch,
      ),
    );
  }

  /// Tìm câu hỏi và các câu hỏi thường gặp giống từ khóa.
  void _runSearch(String text) {
    _debounce?.cancel();
    final c = context.read<QuestionController>();
    if (text.trim() == c.query && c.error == null) {
      return;
    }
    c.search(text);
    context.read<FaqController>().loadHits(text);
  }

  Widget _filters(QuestionController c) {
    final topicCount = c.topicIds.length;
    final names = {for (final t in c.overview?.topics ?? const <Topic>[]) t.id: t.name};
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: [
              for (final entry in _statusLabels.entries)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(entry.value),
                    selected: c.status == entry.key,
                    onSelected: (_) {
                      if (c.status != entry.key) {
                        c.setStatus(entry.key);
                      }
                    },
                  ),
                ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: [
              OutlinedButton.icon(
                onPressed: () => _pickTopics(c),
                icon: const Icon(Icons.sell_outlined, size: 18),
                label: Text(topicCount == 0 ? 'Chủ đề' : 'Chủ đề ($topicCount)'),
              ),
              const Spacer(),
              PopupMenuButton<String>(
                tooltip: 'Sắp xếp',
                initialValue: c.sort,
                onSelected: (value) {
                  if (value != c.sort) {
                    c.setSort(value);
                  }
                },
                itemBuilder: (_) => [
                  for (final entry in _sortLabels.entries) PopupMenuItem(value: entry.key, child: Text(entry.value)),
                ],
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.sort, size: 18),
                      const SizedBox(width: 4),
                      Text(_sortLabels[c.sort] ?? 'Mới nhất'),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        if (c.isFiltered)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Wrap(
              spacing: 8,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                for (final id in c.topicIds)
                  InputChip(
                    label: Text(names[id] ?? 'Chủ đề $id'),
                    onDeleted: () => c.toggleTopic(id),
                    deleteButtonTooltipMessage: 'Bỏ chủ đề ${names[id] ?? id}',
                  ),
                TextButton(onPressed: _clearFilters, child: const Text('Xóa bộ lọc')),
              ],
            ),
          ),
      ],
    );
  }

  void _clearFilters() {
    _search.clear();
    context.read<QuestionController>().clearFilters();
    context.read<FaqController>().loadHits('');
  }

  /// Bảng chọn chủ đề: bấm chủ đề nào danh sách lọc ngay theo chủ đề đó.
  Future<void> _pickTopics(QuestionController c) async {
    if (c.overview == null) {
      await c.loadOverview();
    }
    if (!mounted) {
      return;
    }
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (sheetContext) => Consumer<QuestionController>(
        builder: (_, controller, _) {
          final topics = controller.overview?.topics ?? const <Topic>[];
          return SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Chọn chủ đề', style: Theme.of(sheetContext).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  if (topics.isEmpty)
                    Text(controller.overviewError ?? 'Chưa có chủ đề.')
                  else
                    Wrap(
                      spacing: 8,
                      runSpacing: 4,
                      children: [
                        for (final t in topics)
                          FilterChip(
                            label: Text(t.name),
                            selected: controller.topicIds.contains(t.id),
                            onSelected: (_) => controller.toggleTopic(t.id),
                          ),
                      ],
                    ),
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerRight,
                    child: FilledButton(onPressed: () => Navigator.pop(sheetContext), child: const Text('Xong')),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  /// Thống kê của cộng đồng; bấm số "chưa ai trả lời" / "đã giải quyết" để lọc.
  Widget _statsCard(QuestionController c, QuestionOverview o) {
    final theme = Theme.of(context);
    Widget stat(int value, String label, String? status) => Expanded(
      child: InkWell(
        onTap: status == null ? null : () => c.setStatus(status),
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(
            children: [
              Text('$value', style: theme.textTheme.titleLarge),
              Text(label, textAlign: TextAlign.center, style: theme.textTheme.bodySmall),
            ],
          ),
        ),
      ),
    );
    return Card(
      margin: const EdgeInsets.fromLTRB(12, 8, 12, 4),
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        key: const PageStorageKey<String>('qa-stats'),
        shape: const Border(),
        collapsedShape: const Border(),
        title: Row(
          children: [
            stat(o.total, 'câu hỏi', null),
            stat(o.unanswered, 'chưa ai trả lời', 'UNANSWERED'),
            stat(o.solved, 'đã giải quyết', 'SOLVED'),
          ],
        ),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (o.unanswered > 0)
            Text('Bạn biết câu trả lời? Giúp người hỏi trong mục “Chưa ai trả lời”.', style: theme.textTheme.bodySmall),
          const SizedBox(height: 8),
          Text('Chủ đề hay được hỏi', style: theme.textTheme.titleSmall),
          const SizedBox(height: 4),
          if (o.popularTopics.isEmpty)
            const Text('Chưa có dữ liệu.')
          else
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                for (final p in o.popularTopics)
                  ActionChip(label: Text('${p.topic.name} · ${p.count}'), onPressed: () => c.showTopic(p.topic.id)),
              ],
            ),
          const SizedBox(height: 12),
          Text('Senpai giải đáp nhiều', style: theme.textTheme.titleSmall),
          Text('Trong ${o.topAnswerersDays} ngày qua', style: theme.textTheme.bodySmall),
          const SizedBox(height: 4),
          if (o.topAnswerers.isEmpty)
            const Text('Chưa có ai trả lời trong thời gian này.')
          else
            for (final a in o.topAnswerers)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Row(
                  children: [
                    const Icon(Icons.workspace_premium_outlined, size: 18),
                    const SizedBox(width: 6),
                    Expanded(child: Text(a.author.displayName, maxLines: 1, overflow: TextOverflow.ellipsis)),
                    Text(
                      '${a.answerCount} trả lời${a.bestCount > 0 ? ' · ${a.bestCount} hay nhất' : ''}',
                      style: theme.textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
        ],
      ),
    );
  }

  bool _showHits(QuestionController c, FaqController faq) =>
      faq.hits.isNotEmpty && c.query.isNotEmpty && faq.hitsQuery == c.query && c.error == null;

  /// "Câu hỏi thường gặp liên quan" phía trên kết quả tìm câu hỏi.
  Widget _faqHits(QuestionController c, FaqController faq) {
    final theme = Theme.of(context);
    return Card(
      margin: const EdgeInsets.fromLTRB(12, 8, 12, 4),
      color: theme.colorScheme.secondaryContainer.withValues(alpha: 0.4),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Icon(Icons.quiz_outlined, color: theme.colorScheme.primary),
                  const SizedBox(width: 8),
                  Expanded(child: Text('Câu hỏi thường gặp liên quan', style: theme.textTheme.titleSmall)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
              child: Text('Có thể câu trả lời bạn cần đã có ở đây.', style: theme.textTheme.bodySmall),
            ),
            for (final entry in faq.hits) FaqTile(entry: entry),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: TextButton.icon(
                onPressed: () {
                  faq.search(c.query);
                  _tabs.animateTo(1);
                },
                icon: const Icon(Icons.quiz_outlined),
                label: Text('Tìm “${c.query}” trong Câu hỏi thường gặp', maxLines: 2, overflow: TextOverflow.ellipsis),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Danh sách câu hỏi, hoặc trạng thái chờ / lỗi / rỗng.
  List<Widget> _results(QuestionController c) {
    if (c.isLoading && c.questions.isEmpty) {
      return const [
        SliverToBoxAdapter(
          child: Padding(padding: EdgeInsets.all(32), child: LoadingView()),
        ),
      ];
    }
    if (c.error != null) {
      return [
        SliverToBoxAdapter(
          child: ErrorView(message: c.error!, onRetry: c.loadQuestions),
        ),
      ];
    }
    if (c.questions.isEmpty) {
      final searching = c.query.isNotEmpty;
      return [
        SliverToBoxAdapter(
          child: Column(
            children: [
              EmptyView(
                text: !c.isFiltered
                    ? 'Chưa có câu hỏi nào.'
                    : searching
                    ? 'Không có câu hỏi nào khớp với lựa chọn của bạn. Chưa thấy lời giải? Hãy hỏi các senpai.'
                    : 'Không có câu hỏi nào khớp với lựa chọn của bạn.',
                icon: Icons.contact_support_outlined,
              ),
              Wrap(
                spacing: 8,
                children: [
                  if (!c.isFiltered || searching)
                    FilledButton.icon(
                      onPressed: _ask,
                      icon: const Icon(Icons.contact_support_outlined),
                      label: const Text('Đặt câu hỏi'),
                    ),
                  if (c.isFiltered) OutlinedButton(onPressed: _clearFilters, child: const Text('Xóa bộ lọc')),
                ],
              ),
            ],
          ),
        ),
      ];
    }
    return [
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
          child: Text(
            '${c.totalItems} câu hỏi${c.isFiltered ? ' phù hợp' : ''}',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
      ),
      SliverList.builder(
        itemCount: c.questions.length,
        itemBuilder: (_, i) => QuestionCard(question: c.questions[i], onTopicTap: c.showTopic),
      ),
      SliverToBoxAdapter(
        child: c.isLoadingMore
            ? const Padding(padding: EdgeInsets.all(16), child: LoadingView())
            : c.hasMore
            ? Center(
                child: TextButton(onPressed: c.loadMore, child: const Text('Tải thêm')),
              )
            : const SizedBox.shrink(),
      ),
    ];
  }

  /// "Đặt câu hỏi": khách đăng nhập trước. Form đặt xong tự mở câu hỏi vừa đăng.
  Future<void> _ask() async {
    if (!await requireSignIn(context) || !mounted) {
      return;
    }
    await Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const QuestionFormScreen()));
  }
}
