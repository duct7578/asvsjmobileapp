import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/event.dart';
import 'package:myasvsj/com.myasvsj.screen/event_cover.dart';
import 'package:myasvsj/com.myasvsj.screen/event_info_line.dart';
import 'package:myasvsj/com.myasvsj.screen/event_stars.dart';
import 'package:myasvsj/com.myasvsj.screen/event_text.dart';

/// Thẻ một sự kiện trong danh sách: ảnh bìa, trạng thái, tên, ngày · nơi tổ chức · chi phí, điểm review.
/// Sự kiện đã bắt đầu có thêm nút "Viết review" khi có [onWriteReview].
class EventCard extends StatelessWidget {
  const EventCard({super.key, required this.event, this.onTap, this.onWriteReview});

  final Event event;
  final VoidCallback? onTap;
  final VoidCallback? onWriteReview;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final avg = event.avgRating;
    return Card(
      clipBehavior: Clip.antiAlias,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: InkWell(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            EventCover(event: event, height: 120),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(event.title, style: theme.textTheme.titleMedium, maxLines: 2, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 6),
                  EventInfoLine(icon: Icons.event_outlined, text: eventDateRange(event)),
                  EventInfoLine(icon: Icons.location_on_outlined, text: event.locationName),
                  if (event.costNote.isNotEmpty) EventInfoLine(icon: Icons.payments_outlined, text: event.costNote),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      if (event.reviewCount > 0 && avg != null) ...[
                        EventStars(rating: avg),
                        const SizedBox(width: 6),
                        Flexible(
                          child: Text(
                            '${avg.toStringAsFixed(1)} · ${event.reviewCount} review',
                            style: theme.textTheme.bodySmall,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ] else
                        Text('Chưa có review', style: theme.textTheme.bodySmall),
                      const Spacer(),
                      if (event.canReview && onWriteReview != null)
                        TextButton.icon(
                          onPressed: onWriteReview,
                          icon: const Icon(Icons.rate_review_outlined, size: 18),
                          label: const Text('Viết review'),
                        )
                      else
                        const SizedBox(height: 40),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
