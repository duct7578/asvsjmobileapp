import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/recent_review.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';
import 'package:myasvsj/com.myasvsj.screen/home_format.dart';
import 'package:myasvsj/com.myasvsj.screen/home_tag_chips.dart';
import 'package:myasvsj/com.myasvsj.screen/map_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/media_image.dart';
import 'package:myasvsj/com.myasvsj.screen/place_detail_screen.dart';

/// Một review của màn "Review mới": địa điểm (loại, khu vực), số sao, "Gần bạn" / "Cùng tỉnh", "Đã đóng cửa",
/// "Hữu ích", đoạn trích, ảnh đầu tiên, tác giả. Bấm vào thì mở chi tiết địa điểm.
class RecentReviewCard extends StatelessWidget {
  const RecentReviewCard({super.key, required this.review});

  final RecentReview review;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final where = areaRoman(review.placeArea);
    final meta = theme.textTheme.bodySmall;
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => pushScreen<void>(context, PlaceDetailScreen(placeId: review.placeId)),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 18,
                    backgroundColor: scheme.secondaryContainer,
                    child: Icon(categoryIcon(review.categoryIcon), size: 20, color: scheme.onSecondaryContainer),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          review.placeName,
                          style: theme.textTheme.titleSmall,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          [review.categoryName, if (where.isNotEmpty) where].where((s) => s.isNotEmpty).join(' · '),
                          style: meta,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 6,
                runSpacing: 4,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  Text(
                    starText(review.rating),
                    style: TextStyle(color: scheme.tertiary),
                    semanticsLabel: '${review.rating} sao',
                  ),
                  if (review.near == 'AREA') _Badge(text: 'Gần bạn', icon: Icons.location_on_outlined),
                  if (review.near == 'PREFECTURE') const _Badge(text: 'Cùng tỉnh'),
                  if (review.placeClosed) const _Badge(text: 'Đã đóng cửa', warn: true),
                  if (review.isHelpful) const _Badge(text: 'Hữu ích', icon: Icons.verified_outlined),
                ],
              ),
              const SizedBox(height: 6),
              Text(review.excerpt, maxLines: 6, overflow: TextOverflow.ellipsis),
              if ((review.photoUrl ?? '').isNotEmpty) ...[
                const SizedBox(height: 8),
                Stack(
                  children: [
                    MediaImage(url: review.photoUrl!, height: 160, width: double.infinity),
                    if (review.mediaCount > 1)
                      Positioned(
                        right: 8,
                        bottom: 8,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: scheme.inverseSurface,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text('+${review.mediaCount - 1}', style: TextStyle(color: scheme.onInverseSurface)),
                        ),
                      ),
                  ],
                ),
              ] else if (review.mediaCount > 0)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text('${review.mediaCount} video', style: meta),
                ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 6,
                runSpacing: 2,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  Text(review.authorName, style: meta),
                  HomeTagChips(tags: review.authorTags),
                  Text(
                    [
                      if (review.createdAt != null) formatTimeAgo(review.createdAt!),
                      '♥ ${review.likeCount}',
                    ].join(' · '),
                    style: meta,
                  ),
                ],
              ),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: () => pushScreen<void>(context, MapScreen(focusPlaceId: review.placeId)),
                  icon: const Icon(Icons.map_outlined, size: 18),
                  label: const Text('Xem trên bản đồ'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  const _Badge({required this.text, this.icon, this.warn = false});

  final String text;
  final IconData? icon;
  final bool warn;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final background = warn ? scheme.errorContainer : scheme.secondaryContainer;
    final foreground = warn ? scheme.onErrorContainer : scheme.onSecondaryContainer;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(color: background, borderRadius: BorderRadius.circular(10)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[Icon(icon, size: 14, color: foreground), const SizedBox(width: 3)],
          Text(text, style: Theme.of(context).textTheme.labelSmall?.copyWith(color: foreground)),
        ],
      ),
    );
  }
}
