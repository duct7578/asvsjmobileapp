// Cách hiện chữ dùng chung cho Trang chủ, "Dành cho bạn", "Review mới" và "Tìm kiếm" (chép theo lib/ui.js của web).
import 'package:flutter/material.dart';

/// Tên ngắn của giai đoạn (STAGES của web).
const Map<String, String> stageNames = {
  'PRE': 'Sắp sang Nhật',
  'ARR': 'Mới đến',
  'LEAVE': 'Sắp về nước',
  'HOME': 'Đã về nước',
};

/// "ARR" → "Mới đến"; mã lạ giữ nguyên, null → rỗng.
String stageName(String? code) => stageNames[code] ?? (code ?? '');

/// "Arakawa-ku, Tokyo · 東京都荒川区" → "Arakawa-ku, Tokyo".
String areaRoman(String? name) => (name ?? '').split(' · ').first.trim();

/// "Arakawa-ku, Tokyo · 東京都荒川区" → "Arakawa-ku"; "Kita-ku, Osaka-shi, Osaka · …" → "Kita-ku, Osaka-shi".
String areaShort(String? name) {
  final roman = areaRoman(name);
  final comma = roman.lastIndexOf(',');
  return comma < 0 ? roman : roman.substring(0, comma).trim();
}

/// "Arakawa-ku, Tokyo · 東京都荒川区" → "Tokyo".
String prefectureShort(String? name) {
  final roman = areaRoman(name);
  return roman.substring(roman.lastIndexOf(',') + 1).trim();
}

/// 4 sao → "★★★★☆".
String starText(int rating) {
  final full = rating.clamp(0, 5);
  return '${'★' * full}${'☆' * (5 - full)}';
}

/// Sự kiện của trang chủ: "Đang diễn ra" hoặc "Còn n ngày".
String eventWhen(int daysUntil) => daysUntil <= 0 ? 'Đang diễn ra' : 'Còn $daysUntil ngày';

/// Màu tag server gửi ("#C2456E"); null khi không đọc được (dùng màu theme).
Color? tagColor(String hex) {
  final digits = hex.replaceFirst('#', '');
  if (digits.length != 6) {
    return null;
  }
  final value = int.tryParse(digits, radix: 16);
  return value == null ? null : Color(0xFF000000 | value);
}

/// Biểu tượng ứng với tên biểu tượng Material của web (loại địa điểm, loại mẫu câu); tên lạ → ghim địa điểm.
IconData categoryIcon(String? name) => switch (name) {
  'school' => Icons.school_outlined,
  'restaurant' => Icons.restaurant,
  'train' => Icons.train_outlined,
  'local_convenience_store' => Icons.local_convenience_store_outlined,
  'local_post_office' => Icons.local_post_office_outlined,
  'local_pharmacy' => Icons.local_pharmacy_outlined,
  'local_hospital' => Icons.local_hospital_outlined,
  'account_balance' => Icons.account_balance_outlined,
  'shopping_cart' || 'shopping_bag' => Icons.shopping_bag_outlined,
  'home' || 'apartment' => Icons.home_outlined,
  'park' => Icons.park_outlined,
  'temple_buddhist' || 'temple_hindu' => Icons.temple_buddhist_outlined,
  'church' => Icons.church_outlined,
  'local_cafe' => Icons.local_cafe_outlined,
  'work' => Icons.work_outline,
  'translate' => Icons.translate,
  'celebration' => Icons.celebration_outlined,
  _ => Icons.place_outlined,
};

/// Lời chào giống web: chỉ tên gọi (chữ cuối của tên), thêm một câu theo giai đoạn khi đã chọn khu vực và giai đoạn.
String homeGreeting({required String displayName, String? stage, String? areaName}) {
  final parts = displayName.trim().split(RegExp(r'\s+'));
  final name = parts.isEmpty ? '' : parts.last;
  if ((areaName ?? '').isEmpty || (stage ?? '').isEmpty) {
    return 'Chào $name!';
  }
  final area = areaShort(areaName);
  return 'Chào $name, ${switch (stage) {
    'PRE' => 'sắp sang Nhật rồi, chuẩn bị đến đâu rồi?',
    'ARR' => 'dạo này ở $area thế nào rồi?',
    'LEAVE' => 'sắp rời $area rồi, đừng quên các thủ tục nhé.',
    'HOME' => 'về nước rồi, giúp các bạn đi sau nhé!',
    _ => 'hôm nay thế nào rồi?',
  }}';
}

/// Dòng dưới "Dựa trên": chủ đề quan tâm lấy từ đâu và cách tự chọn (interestNote của web).
String interestNote({required int interests, required int chosen}) {
  const learnt = 'những bài bạn đã thích, lưu, bình luận hoặc viết trong 90 ngày qua';
  if (interests == 0) {
    return 'Bấm “Điều chỉnh” để chọn chủ đề bạn quan tâm. Senpai ơi cũng học từ những bài bạn thích, lưu hoặc '
        'bình luận để gợi ý sát hơn.';
  }
  if (chosen == 0) {
    return 'Chủ đề quan tâm được rút ra từ $learnt. Bấm “Điều chỉnh” để tự chọn chủ đề.';
  }
  return 'Bài thuộc chủ đề bạn chọn được ưu tiên trong gợi ý.'
      '${interests > chosen ? ' Các chủ đề còn lại được rút ra từ $learnt.' : ''}';
}

/// Mở [screen] chồng lên màn hình hiện tại.
Future<T?> pushScreen<T>(BuildContext context, Widget screen) =>
    Navigator.push<T>(context, MaterialPageRoute<T>(builder: (_) => screen));
