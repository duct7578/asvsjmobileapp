import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/blog_controller.dart';
import 'package:myasvsj/com.myasvsj.model/blog_compose_options.dart';
import 'package:myasvsj/com.myasvsj.model/blog_place.dart';
import 'package:myasvsj/com.myasvsj.model/media_item.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_place_picker.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/media_image.dart';
import 'package:myasvsj/com.myasvsj.screen/photo_picker.dart';

/// Form viết bài (Create, khi [blogId] là null) và sửa bài (Update): tiêu đề, chủ đề, địa điểm liên quan,
/// nội dung, tối đa 5 ảnh. Khi sửa, ảnh cũ giữ lại hoặc bỏ được và thêm được ảnh mới.
/// Lưu xong, màn hình đóng và trả về true để màn trước hiện câu thông báo của server.
class BlogFormScreen extends StatefulWidget {
  const BlogFormScreen({super.key, this.blogId});

  final int? blogId;

  @override
  State<BlogFormScreen> createState() => _BlogFormScreenState();
}

class _BlogFormScreenState extends State<BlogFormScreen> {
  final _title = TextEditingController();
  final _content = TextEditingController();
  final _scroll = ScrollController();
  List<int> _topicIds = [];
  List<BlogPlace> _places = [];

  /// Ảnh / video đã gắn (khi sửa) còn giữ lại.
  List<MediaItem> _keptMedia = [];

  /// Ảnh mới chọn trên máy.
  List<String> _imagePaths = [];

  /// Nội dung form lúc mở, để hỏi trước khi bỏ thay đổi chưa lưu.
  String _opened = '';

  bool get _editing => widget.blogId != null;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final blogs = context.read<BlogController>();
    await blogs.openForm(blogId: widget.blogId);
    if (!mounted) {
      return;
    }
    final old = blogs.editing;
    setState(() {
      if (old != null) {
        _title.text = old.title;
        _content.text = old.content;
        _topicIds = [...old.topicIds];
        _places = [...old.places];
        _keptMedia = [...old.media];
      }
      _opened = _snapshot();
    });
  }

  @override
  void dispose() {
    _title.dispose();
    _content.dispose();
    _scroll.dispose();
    super.dispose();
  }

  String _snapshot() => [
    _title.text,
    _content.text,
    _topicIds,
    [for (final p in _places) p.key],
    [for (final m in _keptMedia) m.id],
    _imagePaths,
  ].join('|');

  @override
  Widget build(BuildContext context) {
    final blogs = context.watch<BlogController>();
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) => _leave(didPop),
      child: Scaffold(
        appBar: AppBar(title: Text(_editing ? 'Sửa bài' : 'Viết bài')),
        body: _body(blogs),
      ),
    );
  }

  Widget _body(BlogController blogs) {
    final options = blogs.composeOptions;
    if (blogs.isLoadingForm) {
      return const LoadingView();
    }
    if (options == null) {
      // Không mở được form: chưa đăng nhập, tài khoản staff (MSG18), không phải tác giả hoặc mất mạng
      return ErrorView(message: blogs.formError ?? 'Không tải được dữ liệu. Vui lòng thử lại.', onRetry: _load);
    }
    final theme = Theme.of(context);
    final errors = blogs.fieldErrors;
    final errorStyle = TextStyle(color: theme.colorScheme.error);
    final noteStyle = theme.textTheme.bodySmall;
    final topicsFull = _topicIds.length >= options.topicsMax;
    final showScamHint = _topicIds.any(options.scamWarningTopicIds.contains);
    return ListView(
      controller: _scroll,
      padding: const EdgeInsets.all(16),
      children: [
        ..._notes(blogs, options),
        if (blogs.formError != null)
          Card(
            color: theme.colorScheme.errorContainer,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(blogs.formError!, style: TextStyle(color: theme.colorScheme.onErrorContainer)),
            ),
          ),
        const SizedBox(height: 8),
        TextField(
          controller: _title,
          maxLength: options.titleMax,
          textCapitalization: TextCapitalization.sentences,
          decoration: InputDecoration(
            labelText: 'Tiêu đề *',
            border: const OutlineInputBorder(),
            errorText: errors['title'],
          ),
        ),
        const SizedBox(height: 8),
        Text('Chủ đề * (${_topicIds.length}/${options.topicsMax})', style: theme.textTheme.titleSmall),
        const SizedBox(height: 4),
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: [
            for (final topic in options.topics)
              FilterChip(
                label: Text(topic.name),
                selected: _topicIds.contains(topic.id),
                onSelected: topicsFull && !_topicIds.contains(topic.id)
                    ? null
                    : (on) => setState(() {
                        _topicIds = on ? [..._topicIds, topic.id] : _topicIds.where((id) => id != topic.id).toList();
                      }),
              ),
          ],
        ),
        const SizedBox(height: 4),
        if (errors['topicIds'] != null)
          Text(errors['topicIds']!, style: errorStyle)
        else
          Text('Chọn từ 1 đến ${options.topicsMax} chủ đề. Không có chủ đề phù hợp thì chọn “Khác”.', style: noteStyle),
        const SizedBox(height: 16),
        BlogPlacePicker(
          selected: _places,
          max: options.placesMax,
          results: blogs.placeResults,
          isSearching: blogs.isSearchingPlaces,
          message: blogs.placeError,
          errorText: errors['placeIds'],
          onSearch: blogs.searchPlaces,
          onAdd: (place) {
            blogs.clearPlaceResults();
            setState(() => _places = [..._places, place]);
          },
          onRemove: (place) => setState(() => _places = _places.where((p) => p.key != place.key).toList()),
        ),
        if (showScamHint)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(
              '! Bài “Cảnh báo lừa đảo” gắn địa điểm sẽ hiện dấu “!” trên ghim của địa điểm đó trên bản đồ.',
              style: noteStyle,
            ),
          ),
        const SizedBox(height: 16),
        TextField(
          controller: _content,
          minLines: 6,
          maxLines: 16,
          maxLength: options.contentMax,
          textCapitalization: TextCapitalization.sentences,
          decoration: InputDecoration(
            labelText: 'Nội dung *',
            alignLabelWithHint: true,
            border: const OutlineInputBorder(),
            errorText: errors['content'],
            errorMaxLines: 3,
          ),
        ),
        Text(
          options.canPostLinks
              ? 'Bạn có tag định danh nên được chèn link và đăng ảnh có mã QR. '
                    'Không dùng link rút gọn (bit.ly, tinyurl…).'
              : 'Chỉ tài khoản đã có tag định danh mới được chèn link, ghi số điện thoại hoặc tài khoản Zalo, '
                    'LINE, Telegram, hay đăng ảnh có mã QR.',
          style: noteStyle,
        ),
        const SizedBox(height: 16),
        ..._photos(options, errors['images'] ?? errors['video']),
        const SizedBox(height: 24),
        FilledButton.icon(
          onPressed: blogs.isSaving ? null : _save,
          icon: blogs.isSaving
              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.send),
          label: Text(_submitLabel(blogs.isSaving)),
        ),
      ],
    );
  }

  /// Ghi chú trên cùng: bài đang quét / bị từ chối (khi sửa), lượt đăng hôm nay của tài khoản mới (khi viết mới).
  List<Widget> _notes(BlogController blogs, BlogComposeOptions options) {
    final status = blogs.editing?.status;
    final text = switch (status) {
      'PROCESSING' => 'Ảnh đang được quét; trong lúc này chỉ bạn thấy bài.',
      'REJECTED' =>
        'Bài chưa được đăng vì ảnh hoặc video vi phạm Quy tắc cộng đồng (đã được gỡ). '
            'Sửa xong bấm “Lưu thay đổi” để đăng lại.',
      _ when !_editing && options.newAccount =>
        'Tài khoản mới, hôm nay: ${options.postsUsed}/${options.postsLimit} bài viết và review.'
            '${options.quotaFull ? ' Bạn đã dùng hết lượt đăng hôm nay, hãy quay lại vào ngày mai.' : ''}',
      _ => null,
    };
    if (text == null) {
      return const [];
    }
    final scheme = Theme.of(context).colorScheme;
    return [
      Card(
        color: scheme.tertiaryContainer,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Text(text, style: TextStyle(color: scheme.onTertiaryContainer)),
        ),
      ),
    ];
  }

  List<Widget> _photos(BlogComposeOptions options, String? error) {
    final theme = Theme.of(context);
    final keptImages = _keptMedia.where((m) => m.isImage).length;
    final room = options.imagesMax - keptImages;
    return [
      Text('Ảnh (không bắt buộc)', style: theme.textTheme.titleSmall),
      const SizedBox(height: 8),
      if (_keptMedia.isNotEmpty) ...[
        Text('Ảnh đang có', style: theme.textTheme.bodySmall),
        const SizedBox(height: 4),
        Wrap(spacing: 8, runSpacing: 8, children: [for (final m in _keptMedia) _keptTile(m)]),
        const SizedBox(height: 12),
      ],
      if (room > 0)
        PhotoPicker(
          paths: _imagePaths,
          max: room,
          label: _editing ? 'Ảnh mới' : 'Ảnh',
          onChanged: (paths) => setState(() => _imagePaths = paths),
        )
      else
        Text('Đã đủ ${options.imagesMax} ảnh. Bỏ bớt ảnh đang có để thêm ảnh mới.', style: theme.textTheme.bodySmall),
      const SizedBox(height: 4),
      Text(
        'Tối đa ${options.imagesMax} ảnh, mỗi ảnh không quá ${options.imageMaxMb} MB. App chưa đăng được video.',
        style: theme.textTheme.bodySmall,
      ),
      if (error != null) Text(error, style: TextStyle(color: theme.colorScheme.error)),
    ];
  }

  /// Ảnh (hoặc video đăng từ web) đã gắn vào bài, có nút bỏ.
  Widget _keptTile(MediaItem media) {
    final scheme = Theme.of(context).colorScheme;
    return Stack(
      children: [
        if (media.isImage)
          MediaImage(url: media.url, width: 80, height: 80)
        else
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(color: scheme.surfaceContainerHighest, borderRadius: BorderRadius.circular(8)),
            child: const Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [Icon(Icons.videocam_outlined), Text('Video')],
            ),
          ),
        Positioned(
          right: 0,
          top: 0,
          child: Tooltip(
            message: media.isImage ? 'Bỏ ảnh này' : 'Bỏ video',
            child: InkWell(
              onTap: () => setState(() => _keptMedia = _keptMedia.where((m) => m.id != media.id).toList()),
              child: const CircleAvatar(radius: 12, child: Icon(Icons.close, size: 16)),
            ),
          ),
        ),
      ],
    );
  }

  String _submitLabel(bool saving) {
    if (saving) {
      return _imagePaths.isNotEmpty ? 'Đang tải lên và kiểm tra…' : 'Đang kiểm tra nội dung…';
    }
    return _editing ? 'Lưu thay đổi' : 'Đăng bài';
  }

  Future<void> _save() async {
    FocusScope.of(context).unfocus();
    final blogs = context.read<BlogController>();
    final saved = await blogs.saveBlog(
      title: _title.text,
      content: _content.text,
      topicIds: _topicIds,
      places: _places,
      keptMedia: _keptMedia,
      imagePaths: _imagePaths,
    );
    if (!mounted) {
      return;
    }
    if (saved) {
      Navigator.pop(context, true);
    } else if (_scroll.hasClients) {
      // Câu lỗi chung nằm trên cùng form
      _scroll.animateTo(0, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
    }
  }

  /// Bấm quay lại: còn thay đổi chưa lưu thì hỏi trước (MSG15).
  Future<void> _leave(bool didPop) async {
    if (didPop) {
      return;
    }
    final changed = context.read<BlogController>().composeOptions != null && _snapshot() != _opened;
    if (changed) {
      final discard = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Bỏ thay đổi?'),
          content: const Text('Bạn có thay đổi chưa lưu. Bạn có muốn bỏ các thay đổi này không?'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Ở lại')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Bỏ thay đổi')),
          ],
        ),
      );
      if (discard != true) {
        return;
      }
    }
    if (mounted) {
      Navigator.pop(context);
    }
  }
}
