import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:myasvsj/com.myasvsj.screen/app_message.dart';

/// Nút "Chỉ đường": mở chỉ đường Google Maps tới địa điểm (app Google Maps nếu có, không thì trình duyệt).
/// [url] lấy từ thực thể (`directionsUrl` của MapPlace, PlaceOption, PlaceDetail).
class PlaceDirectionsButton extends StatelessWidget {
  const PlaceDirectionsButton({super.key, required this.url, this.filled = false});

  final String url;

  /// Nút nổi bật (FilledButton.tonal) thay vì nút viền.
  final bool filled;

  @override
  Widget build(BuildContext context) {
    const icon = Icon(Icons.directions);
    const label = Text('Chỉ đường');
    return filled
        ? FilledButton.tonalIcon(onPressed: () => _open(context), icon: icon, label: label)
        : OutlinedButton.icon(onPressed: () => _open(context), icon: icon, label: label);
  }

  Future<void> _open(BuildContext context) async {
    var opened = false;
    try {
      opened = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {
      opened = false;
    }
    if (!opened && context.mounted) {
      showMessage(context, 'Không mở được Google Maps trên máy này.');
    }
  }
}
