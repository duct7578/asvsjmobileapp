import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/event_controller.dart';
import 'package:myasvsj/com.myasvsj.model/event_detail.dart';
import 'package:myasvsj/com.myasvsj.model/event_review.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/event_cover.dart';
import 'package:myasvsj/com.myasvsj.screen/event_info_line.dart';
import 'package:myasvsj/com.myasvsj.screen/event_photo_viewer.dart';
import 'package:myasvsj/com.myasvsj.screen/event_review_form_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/event_review_tile.dart';
import 'package:myasvsj/com.myasvsj.screen/event_stars.dart';
import 'package:myasvsj/com.myasvsj.screen/event_text.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/media_image.dart';
import 'package:myasvsj/com.myasvsj.screen/report_dialog.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// Chi tiết một sự kiện (`GET /api/events/{id}`): ảnh bìa, thời gian, nơi tổ chức (có "Chỉ đường" bằng Google Maps),
/// chi phí, mẹo từ Moderator, album ảnh từ review và các review với Thích / Báo cáo / Sửa / Xóa.
class EventDetailScreen extends StatefulWidget {
  const EventDetailScreen({super.key, required this.eventId});

  final int eventId;

  @override
  State<EventDetailScreen> createState() => _EventDetailScreenState();
}

class _EventDetailScreenState extends State<EventDetailScreen> {
  /// Người đang đăng nhập lúc tải; đổi (vừa đăng nhập / đăng xuất) thì tải lại vì quyền và dấu "Thích" đổi theo.
  int? _userId;

  @override
  void initState() {
    super.initState();
    _userId = context.read<AuthController>().currentUser?.id;
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final events = context.read<EventController>();
    await events.loadEvent(widget.eventId);
    if (mounted) {
      showMessage(context, events.takeMessage());
    }
  }

  @override
  Widget build(BuildContext context) {
    final events = context.watch<EventController>();
    final userId = context.watch<AuthController>().currentUser?.id;
    if (userId != _userId) {
      _userId = userId;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          _load();
        }
      });
    }
    final detail = events.detailOf(widget.eventId);
    return Scaffold(
      appBar: AppBar(title: Text(detail?.event.title ?? 'Sự kiện', maxLines: 1, overflow: TextOverflow.ellipsis)),
      body: _body(events, detail),
    );
  }

  Widget _body(EventController events, EventDetail? detail) {
    if (detail == null) {
      final error = events.detailErrorOf(widget.eventId);
      if (error != null) {
        return ErrorView(message: error, onRetry: _load);
      }
      return const LoadingView();
    }
    final theme = Theme.of(context);
    final event = detail.event;
    final avg = event.avgRating;
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.only(bottom: 32),
        children: [
          EventCover(event: event, height: 180),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(event.title, style: theme.textTheme.headlineSmall),
                const SizedBox(height: 8),
                EventInfoLine(icon: Icons.event_outlined, text: eventDateRange(event)),
                EventInfoLine(icon: Icons.location_on_outlined, text: event.locationName, maxLines: 3),
                EventInfoLine(icon: Icons.payments_outlined, text: event.costNote.isEmpty ? 'Chưa rõ' : event.costNote),
                const SizedBox(height: 8),
                _locationRow(detail),
                if (detail.albumCount > 0) _album(detail),
                if (detail.tip != null) _tip(detail.tip!),
                const SizedBox(height: 12),
                Row(
                  children: [
                    if (event.reviewCount > 0 && avg != null) ...[
                      EventStars(rating: avg, size: 20),
                      const SizedBox(width: 8),
                      Text(avg.toStringAsFixed(1), style: theme.textTheme.titleMedium),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          '${event.reviewCount} review, gồm cả các năm trước',
                          style: theme.textTheme.bodySmall,
                        ),
                      ),
                    ] else
                      Text('Chưa có review.', style: theme.textTheme.bodySmall),
                  ],
                ),
                const SizedBox(height: 8),
                _writeButton(detail),
                const Divider(height: 32),
                Text('Review (${detail.publishedCount})', style: theme.textTheme.titleLarge),
                if (detail.reviews.isEmpty)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    child: Text('Chưa ai viết review về sự kiện này.', style: theme.textTheme.bodyMedium),
                  ),
                for (final review in detail.reviews) ...[
                  EventReviewTile(
                    review: review,
                    // Thành viên thích / báo cáo review đã đăng của người khác; khách thấy nút, bấm thì đăng nhập
                    canAct: review.isPublished && !review.mine && (detail.member || !detail.signedIn),
                    canEdit: review.status != EventReview.hidden && review.year == event.reviewYear,
                    liking: events.isLiking(review.id),
                    onLike: () => _like(review),
                    onReport: () => _report(detail, review),
                    onEdit: _openForm,
                    onDelete: () => _delete(review),
                  ),
                  const Divider(height: 1),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// "Nơi tổ chức": có tọa độ thì có nút "Chỉ đường" mở Google Maps.
  Widget _locationRow(EventDetail detail) {
    final uri = detail.event.directionsUri;
    if (uri == null) {
      return const EventInfoLine(icon: Icons.location_off_outlined, text: 'Sự kiện chưa gắn vị trí trên bản đồ.');
    }
    return Align(
      alignment: Alignment.centerLeft,
      child: OutlinedButton.icon(
        onPressed: () => _openUri(uri),
        icon: const Icon(Icons.directions),
        label: const Text('Chỉ đường'),
      ),
    );
  }

  Widget _album(EventDetail detail) {
    final theme = Theme.of(context);
    final photos = [for (final p in detail.album) (url: p.url, caption: '${p.authorName} · năm ${p.year}')];
    return Padding(
      padding: const EdgeInsets.only(top: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Album từ review (${detail.albumCount} ảnh)', style: theme.textTheme.titleMedium),
          const SizedBox(height: 8),
          SizedBox(
            height: 96,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: detail.album.length,
              separatorBuilder: (_, _) => const SizedBox(width: 8),
              itemBuilder: (_, i) => InkWell(
                onTap: () => showEventPhotos(context, photos: photos, initialIndex: i),
                child: MediaImage(url: detail.album[i].url, width: 96, height: 96),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _tip(String tip) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: scheme.secondaryContainer, borderRadius: BorderRadius.circular(12)),
      child: Text.rich(
        TextSpan(
          children: [
            const TextSpan(
              text: 'Mẹo từ Moderator: ',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            TextSpan(text: tip),
          ],
        ),
        style: TextStyle(color: scheme.onSecondaryContainer),
      ),
    );
  }

  /// "Viết review năm 2026" / "Sửa review năm 2026", hoặc lý do chưa viết được.
  Widget _writeButton(EventDetail detail) {
    final event = detail.event;
    if (!event.canReview) {
      return const EventInfoLine(icon: Icons.schedule, text: 'Viết review được khi sự kiện bắt đầu.', maxLines: 2);
    }
    if (detail.signedIn && !detail.member) {
      return const SizedBox.shrink(); // tài khoản staff không viết review
    }
    final editing = detail.myReviewId != null;
    return FilledButton.icon(
      onPressed: _openForm,
      icon: Icon(editing ? Icons.edit_outlined : Icons.rate_review_outlined),
      label: Text(editing ? 'Sửa review năm ${event.reviewYear}' : 'Viết review năm ${event.reviewYear}'),
    );
  }

  // ---------------------------------------------------------------- Thao tác

  Future<void> _openForm() async {
    if (!await requireSignIn(context) || !mounted) {
      return;
    }
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => EventReviewFormScreen(eventId: widget.eventId)),
    );
    if (saved == true && mounted) {
      showMessage(context, context.read<EventController>().takeMessage());
    }
  }

  /// Khách được đưa sang đăng nhập; đăng nhập xong trang tự tải lại dấu "Thích" thật của tài khoản, người dùng
  /// bấm lại nếu vẫn muốn thích (không đảo dấu thích theo dữ liệu cũ của khách).
  Future<void> _like(EventReview review) async {
    if (!context.read<AuthController>().isSignedIn) {
      await requireSignIn(context);
      return;
    }
    final events = context.read<EventController>();
    await events.toggleLike(widget.eventId, review.id);
    if (mounted) {
      showMessage(context, events.takeMessage());
    }
  }

  Future<void> _report(EventDetail detail, EventReview review) async {
    if (!await requireSignIn(context) || !mounted) {
      return;
    }
    final choice = await showReportDialog(context, reasons: detail.reportReasons, title: 'Báo cáo review');
    if (choice == null || !mounted) {
      return;
    }
    final events = context.read<EventController>();
    await events.reportReview(widget.eventId, review.id, reasonId: choice.reasonId, note: choice.note);
    if (mounted) {
      showMessage(context, events.takeMessage());
    }
  }

  Future<void> _delete(EventReview review) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Xóa review?'),
        content: const Text('Ảnh, video và điểm của review cũng bị xóa. Không thể hoàn tác.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Xóa')),
        ],
      ),
    );
    if (confirmed != true || !mounted) {
      return;
    }
    final events = context.read<EventController>();
    await events.deleteReview(widget.eventId, review.id);
    if (mounted) {
      showMessage(context, events.takeMessage());
    }
  }

  Future<void> _openUri(Uri uri) async {
    var opened = false;
    try {
      opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      // Máy không có trình duyệt / Google Maps: báo bên dưới
    }
    if (!opened && mounted) {
      showMessage(context, 'Không mở được Google Maps.');
    }
  }
}
