import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/home_guide_card.dart';
import 'package:myasvsj/com.myasvsj.model/home_member.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_list_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/feed_basis.dart';
import 'package:myasvsj/com.myasvsj.screen/feed_post_card.dart';
import 'package:myasvsj/com.myasvsj.screen/feed_settings_sheet.dart';
import 'package:myasvsj/com.myasvsj.screen/for_you_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/guide_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/guide_list_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/home_format.dart';

/// "Dành cho bạn" đầu trang chủ thành viên: "Dựa trên" + "Điều chỉnh", lời nhắc chọn khu vực và giai đoạn,
/// 5 bài Senpai ơi chọn (bài đầu có đoạn trích), "Xem tất cả" và "Cẩm nang cho giai đoạn …".
class HomeForYouSection extends StatelessWidget {
  const HomeForYouSection({
    super.key,
    required this.home,
    this.notice,
    this.showAreaPrompt = false,
    required this.onHidePrompt,
    required this.onSettingsSaved,
  });

  final HomeMember home;

  /// Câu báo đã lưu (sau "Điều chỉnh"); null khi không có.
  final String? notice;

  /// Hiện lời nhắc chọn khu vực và giai đoạn.
  final bool showAreaPrompt;
  final VoidCallback onHidePrompt;

  /// Màn "Khu vực và giai đoạn" hoặc "Chủ đề quan tâm" đã lưu: trang chủ tải lại.
  final VoidCallback onSettingsSaved;

  Future<void> _adjust(BuildContext context) async {
    if (await showFeedSettings(context)) {
      onSettingsSaved();
    }
  }

  Future<void> _open(BuildContext context, {required bool areaAndStage}) async {
    if (await openFeedSetting(context, areaAndStage: areaAndStage)) {
      onSettingsSaved();
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final posts = home.forYou;
    return Card(
      color: theme.colorScheme.surfaceContainerLow,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.auto_awesome, color: theme.colorScheme.primary),
                const SizedBox(width: 8),
                Expanded(child: Text('Dành cho bạn', style: theme.textTheme.titleLarge)),
                if (posts.isNotEmpty) ...[
                  IconButton(
                    tooltip: 'Tìm trong bài dành cho bạn',
                    icon: const Icon(Icons.search),
                    onPressed: () => pushScreen<void>(context, const ForYouScreen(autofocusSearch: true)),
                  ),
                  TextButton(
                    onPressed: () => pushScreen<void>(context, const ForYouScreen()),
                    child: const Text('Xem tất cả'),
                  ),
                ],
              ],
            ),
            Text(
              'Bài viết và cẩm nang Senpai ơi chọn riêng cho bạn, theo khu vực, giai đoạn và những chủ đề bạn quan tâm.',
              style: theme.textTheme.bodySmall,
            ),
            const SizedBox(height: 8),
            FeedBasis(
              areaName: home.areaName,
              stage: home.stage,
              interests: home.interests,
              chosenInterests: home.chosenInterests,
              onAdjust: () => _adjust(context),
            ),
            if (notice != null) ...[
              const SizedBox(height: 8),
              Row(
                children: [
                  Icon(Icons.check_circle_outline, color: theme.colorScheme.primary),
                  const SizedBox(width: 6),
                  Expanded(child: Text(notice!)),
                ],
              ),
            ],
            if (showAreaPrompt) ...[const SizedBox(height: 8), _prompt(context, theme)],
            const SizedBox(height: 8),
            if (posts.isEmpty)
              Wrap(
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  const Text('Chưa có bài viết phù hợp. Hãy xem thêm ở Blog.'),
                  TextButton(
                    onPressed: () => pushScreen<void>(context, const BlogListScreen()),
                    child: const Text('Mở Blog'),
                  ),
                ],
              )
            else ...[
              for (var i = 0; i < posts.length; i++) FeedPostCard(post: posts[i], showExcerpt: i == 0),
              const SizedBox(height: 4),
              OutlinedButton.icon(
                onPressed: () => pushScreen<void>(context, const ForYouScreen()),
                icon: const Icon(Icons.arrow_forward),
                label: const Text('Xem tất cả bài viết dành cho bạn'),
              ),
            ],
            if (home.stageGuides.isNotEmpty && (home.stage ?? '').isNotEmpty) ..._stageGuides(context, theme),
          ],
        ),
      ),
    );
  }

  /// Lời nhắc nhẹ, mở cho tới khi đã chọn đủ khu vực và giai đoạn, hoặc bấm "Để sau".
  Widget _prompt(BuildContext context, ThemeData theme) {
    final where = switch (home.stage) {
      'PRE' => 'bạn sắp đến',
      'HOME' => 'bạn từng sống',
      _ => 'bạn đang sinh sống',
    };
    return Card(
      key: const ValueKey('area-prompt'),
      color: theme.colorScheme.secondaryContainer,
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Mong bạn cho Senpai ơi biết khu vực $where', style: theme.textTheme.titleSmall),
            const SizedBox(height: 4),
            const Text(
              'Để Senpai ơi gợi ý đúng những gì gần bạn nhất: việc cần làm, review và sự kiện quanh đó. Chỉ lưu khu vực '
              '(quận, thành phố), không lưu địa chỉ hay vị trí; chỉ mình bạn thấy.',
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                FilledButton(
                  onPressed: () => _open(context, areaAndStage: true),
                  child: const Text('Chọn khu vực và giai đoạn'),
                ),
                OutlinedButton(
                  onPressed: () => _open(context, areaAndStage: false),
                  child: const Text('Chủ đề quan tâm'),
                ),
                TextButton(onPressed: onHidePrompt, child: const Text('Để sau')),
              ],
            ),
          ],
        ),
      ),
    );
  }

  /// "Cẩm nang cho giai đoạn …": tối đa 3 cẩm nang chưa xong của giai đoạn, đang làm dở trước.
  List<Widget> _stageGuides(BuildContext context, ThemeData theme) {
    final stage = home.stage!;
    return [
      const SizedBox(height: 12),
      Row(
        children: [
          Icon(Icons.menu_book_outlined, color: theme.colorScheme.primary),
          const SizedBox(width: 8),
          Expanded(child: Text('Cẩm nang cho giai đoạn ${stageName(stage)}', style: theme.textTheme.titleMedium)),
          TextButton(
            onPressed: () => pushScreen<void>(context, GuideListScreen(stage: stage)),
            child: const Text('Xem tất cả'),
          ),
        ],
      ),
      for (final guide in home.stageGuides) _GuideCard(guide: guide),
    ];
  }
}

class _GuideCard extends StatelessWidget {
  const _GuideCard({required this.guide});

  final HomeGuideCard guide;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => pushScreen<void>(context, GuideDetailScreen(guideId: guide.id)),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(
                    guide.inProgress ? Icons.pending_actions_outlined : Icons.flag_outlined,
                    size: 14,
                    color: scheme.secondary,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    guide.inProgress ? 'Đang làm dở' : 'Hợp giai đoạn của bạn',
                    style: theme.textTheme.labelSmall?.copyWith(color: scheme.secondary),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(guide.title, style: theme.textTheme.titleSmall, maxLines: 2, overflow: TextOverflow.ellipsis),
              if ((guide.excerpt ?? '').isNotEmpty)
                Text(guide.excerpt!, style: theme.textTheme.bodySmall, maxLines: 2, overflow: TextOverflow.ellipsis),
              const SizedBox(height: 6),
              Row(
                children: [
                  if ((guide.topicName ?? '').isNotEmpty) ...[
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: scheme.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(guide.topicName!, style: theme.textTheme.labelSmall),
                    ),
                    const SizedBox(width: 8),
                  ],
                  if (guide.checklist) ...[
                    Expanded(child: LinearProgressIndicator(value: guide.percent.clamp(0, 100) / 100)),
                    const SizedBox(width: 8),
                    Text('${guide.tasksDone}/${guide.tasksTotal} việc', style: theme.textTheme.bodySmall),
                  ] else
                    Text('Chưa đọc', style: theme.textTheme.bodySmall),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
