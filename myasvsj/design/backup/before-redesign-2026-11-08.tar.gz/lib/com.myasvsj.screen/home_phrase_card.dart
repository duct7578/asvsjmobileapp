import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/home_phrase.dart';
import 'package:myasvsj/com.myasvsj.screen/home_format.dart';
import 'package:myasvsj/com.myasvsj.screen/home_speak_button.dart';
import 'package:myasvsj/com.myasvsj.screen/phrase_screen.dart';

/// "Câu tiếng Nhật hôm nay": câu tiếng Nhật, romaji, nghĩa tiếng Việt, nút "Nghe" và "Học thêm chủ đề này"
/// (mở Nhật ngữ).
class HomePhraseCard extends StatelessWidget {
  const HomePhraseCard({super.key, required this.phrase});

  final HomePhrase phrase;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 8,
              runSpacing: 4,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.translate, size: 18, color: theme.colorScheme.primary),
                    const SizedBox(width: 6),
                    Text('Câu tiếng Nhật hôm nay', style: theme.textTheme.titleSmall),
                  ],
                ),
                if (phrase.categoryName.isNotEmpty)
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(categoryIcon(phrase.categoryIcon), size: 14),
                      const SizedBox(width: 4),
                      Text(phrase.categoryName, style: theme.textTheme.bodySmall),
                    ],
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Text(phrase.japanese, style: theme.textTheme.headlineSmall),
            if (phrase.romaji.isNotEmpty) Text(phrase.romaji, style: theme.textTheme.bodySmall),
            const SizedBox(height: 4),
            Text(phrase.meaningVi),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: [
                HomeSpeakButton(text: phrase.japanese),
                TextButton.icon(
                  onPressed: () => pushScreen<void>(
                    context,
                    PhraseScreen(topicId: phrase.topicId, categoryId: phrase.topicId == null ? phrase.categoryId : null),
                  ),
                  icon: const Icon(Icons.school_outlined),
                  label: const Text('Học thêm chủ đề này'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
