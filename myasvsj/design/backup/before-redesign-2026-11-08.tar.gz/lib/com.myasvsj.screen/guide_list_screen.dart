import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/guide_controller.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/empty_view.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/guide_card.dart';
import 'package:myasvsj/com.myasvsj.screen/guide_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';

/// Danh sách "Cẩm nang" (`GET /api/guides/browse`): lọc theo giai đoạn (Trước khi đi, Khi mới đến, Trước khi về
/// nước, Sau khi về nước – mã và tên lấy từ server) và chủ đề, tìm, sắp xếp, cuộn tới cuối để tải thêm.
class GuideListScreen extends StatefulWidget {
  const GuideListScreen({super.key, this.stage});

  /// Mở sẵn giai đoạn này (mã giai đoạn của web, ví dụ "ARR"); null = mọi giai đoạn.
  final String? stage;

  @override
  State<GuideListScreen> createState() => _GuideListScreenState();
}

class _GuideListScreenState extends State<GuideListScreen> {
  static const Map<String, String> _sortLabels = {'NEWEST': 'Mới nhất', 'OLDEST': 'Cũ nhất', 'TITLE': 'Tiêu đề A–Z'};

  final _search = TextEditingController();
  final _scroll = ScrollController();

  @override
  void initState() {
    super.initState();
    _scroll.addListener(_onScroll);
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<GuideController>().openList(stage: widget.stage));
  }

  @override
  void dispose() {
    _scroll.dispose();
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final guides = context.watch<GuideController>();
    return Scaffold(
      appBar: AppBar(title: const Text('Cẩm nang')),
      body: RefreshIndicator(
        onRefresh: guides.loadGuides,
        child: ListView(
          controller: _scroll,
          padding: const EdgeInsets.only(bottom: 24),
          children: [..._filters(guides), ..._results(guides)],
        ),
      ),
    );
  }

  List<Widget> _filters(GuideController guides) {
    final theme = Theme.of(context);
    return [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
        child: Text(
          'Hướng dẫn thiết thực cho việc học tập và cuộc sống tại Nhật Bản.',
          style: theme.textTheme.bodyMedium,
        ),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
        child: TextField(
          controller: _search,
          maxLength: 200,
          textInputAction: TextInputAction.search,
          decoration: InputDecoration(
            hintText: 'Tìm theo tiêu đề, chủ đề hoặc từ khóa…',
            prefixIcon: const Icon(Icons.search),
            counterText: '',
            isDense: true,
            border: const OutlineInputBorder(),
            suffixIcon: IconButton(
              tooltip: 'Tìm kiếm',
              icon: const Icon(Icons.arrow_forward),
              onPressed: () => guides.search(_search.text),
            ),
          ),
          onSubmitted: guides.search,
        ),
      ),
      _chipRow(
        label: 'Giai đoạn',
        allLabel: 'Tất cả giai đoạn',
        selected: guides.stage,
        options: [for (final s in guides.stages) (s.code, s.title)],
        onSelect: guides.selectStage,
      ),
      _chipRow(
        label: 'Chủ đề',
        allLabel: 'Tất cả',
        selected: guides.topic,
        options: [for (final t in guides.topics) (t.code, t.title)],
        onSelect: guides.selectTopic,
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
        child: Row(
          children: [
            Expanded(
              child: Text(
                guides.isLoading ? 'Đang tải cẩm nang…' : '${guides.totalItems} cẩm nang phù hợp',
                style: theme.textTheme.bodySmall,
              ),
            ),
            DropdownButton<String>(
              value: guides.sort,
              underline: const SizedBox.shrink(),
              items: [
                for (final entry in _sortLabels.entries) DropdownMenuItem(value: entry.key, child: Text(entry.value)),
              ],
              onChanged: (value) {
                if (value != null) {
                  guides.selectSort(value);
                }
              },
            ),
          ],
        ),
      ),
    ];
  }

  /// Một hàng chip cuộn ngang: "Tất cả" và các lựa chọn của server (ít lựa chọn nên dựng hết một lần).
  Widget _chipRow({
    required String label,
    required String allLabel,
    required String? selected,
    required List<(String, String)> options,
    required ValueChanged<String?> onSelect,
  }) {
    // Mã trên link (từ "Cẩm nang của tôi") không còn trong danh sách của server
    final unknown = selected != null && options.isNotEmpty && !options.any((o) => o.$1 == selected);
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Row(
        children: [
          Text('$label: ', style: Theme.of(context).textTheme.labelLarge),
          _chip(allLabel, selected == null, () => onSelect(null)),
          for (final (code, title) in options) _chip(title, selected == code, () => onSelect(code)),
          if (unknown) _chip('$label không tồn tại', true, () => onSelect(null)),
        ],
      ),
    );
  }

  Widget _chip(String text, bool selected, VoidCallback onTap) => Padding(
    padding: const EdgeInsets.only(right: 8),
    child: ChoiceChip(label: Text(text), selected: selected, onSelected: (_) => onTap()),
  );

  List<Widget> _results(GuideController guides) {
    if (guides.isLoading && guides.guides.isEmpty) {
      return const [SizedBox(height: 240, child: LoadingView())];
    }
    if (guides.error != null) {
      return [ErrorView(message: guides.error!, onRetry: guides.loadGuides)];
    }
    if (guides.guides.isEmpty) {
      return const [
        EmptyView(text: 'Không có cẩm nang phù hợp. Hãy thử từ khóa hoặc chủ đề khác.', icon: Icons.menu_book_outlined),
      ];
    }
    return [
      for (final guide in guides.guides) GuideCard(guide: guide, onTap: () => _open(guide.id)),
      if (guides.isLoadingMore)
        const Padding(
          padding: EdgeInsets.all(16),
          child: Center(child: CircularProgressIndicator()),
        )
      else if (guides.hasMore)
        Center(
          child: TextButton(onPressed: _loadMore, child: const Text('Tải thêm')),
        ),
    ];
  }

  void _onScroll() {
    if (_scroll.position.pixels > _scroll.position.maxScrollExtent - 300) {
      final guides = context.read<GuideController>();
      if (guides.hasMore && !guides.isLoadingMore && !guides.isLoading) {
        _loadMore();
      }
    }
  }

  Future<void> _loadMore() async {
    final guides = context.read<GuideController>();
    await guides.loadMore();
    if (mounted) {
      showMessage(context, guides.takeMessage());
    }
  }

  Future<void> _open(int guideId) =>
      Navigator.push(context, MaterialPageRoute<void>(builder: (_) => GuideDetailScreen(guideId: guideId)));
}
