import 'package:flutter/material.dart';

/// Vòng quay ở giữa màn hình khi đang tải lần đầu.
class LoadingView extends StatelessWidget {
  const LoadingView({super.key});

  @override
  Widget build(BuildContext context) => const Center(child: CircularProgressIndicator());
}
