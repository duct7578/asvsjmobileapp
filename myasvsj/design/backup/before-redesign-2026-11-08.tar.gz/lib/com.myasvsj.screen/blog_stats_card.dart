import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/blog_overview.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_author_line.dart';

/// Thống kê cộng đồng của Blog (cột bên phải trên web): "Chủ đề phổ biến" và "Senpai viết nhiều".
/// Thu gọn mặc định; bấm một chủ đề để lọc theo chủ đề đó.
class BlogStatsCard extends StatelessWidget {
  const BlogStatsCard({super.key, required this.overview, required this.onTopicTap});

  final BlogOverview overview;
  final ValueChanged<int> onTopicTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final note = theme.textTheme.bodySmall;
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        leading: const Icon(Icons.insights_outlined),
        title: const Text('Thống kê cộng đồng'),
        subtitle: const Text('Chủ đề phổ biến, Senpai viết nhiều'),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Chủ đề phổ biến', style: theme.textTheme.titleSmall),
          if (overview.popularTopics.isEmpty)
            Text('Chưa có dữ liệu.', style: note)
          else
            for (final topic in overview.popularTopics)
              ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.sell_outlined),
                title: Text(topic.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                trailing: Text('${topic.postCount} bài', style: note),
                onTap: () => onTopicTap(topic.id),
              ),
          const SizedBox(height: 8),
          Text('Senpai viết nhiều', style: theme.textTheme.titleSmall),
          Text('Trong ${overview.topWritersDays} ngày qua', style: note),
          if (overview.topWriters.isEmpty)
            Text('Chưa có dữ liệu.', style: note)
          else
            for (final writer in overview.topWriters)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Row(
                  children: [
                    Expanded(child: BlogAuthorLine(author: writer.author, dense: true)),
                    Text('${writer.postCount} bài', style: note),
                  ],
                ),
              ),
        ],
      ),
    );
  }
}
