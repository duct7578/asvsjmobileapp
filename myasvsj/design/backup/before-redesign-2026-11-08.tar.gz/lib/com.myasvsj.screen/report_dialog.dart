import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/report_reason.dart';

/// Hộp thoại "Báo cáo": chọn một lý do (danh sách lấy từ server) và ghi chú thêm (không bắt buộc).
///
/// ```dart
/// final choice = await showReportDialog(context, reasons: blog.reportReasons);
/// if (choice != null) await controller.reportBlog(blog.id, choice.reasonId, choice.note);
/// ```
Future<({int reasonId, String note})?> showReportDialog(
  BuildContext context, {
  required List<ReportReason> reasons,
  String title = 'Báo cáo nội dung',
}) {
  return showDialog<({int reasonId, String note})>(
    context: context,
    builder: (_) => ReportDialog(reasons: reasons, title: title),
  );
}

class ReportDialog extends StatefulWidget {
  const ReportDialog({super.key, required this.reasons, this.title = 'Báo cáo nội dung'});

  final List<ReportReason> reasons;
  final String title;

  @override
  State<ReportDialog> createState() => _ReportDialogState();
}

class _ReportDialogState extends State<ReportDialog> {
  final _note = TextEditingController();
  int? _reasonId;

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.title),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Lý do'),
            RadioGroup<int>(
              groupValue: _reasonId,
              onChanged: (value) => setState(() => _reasonId = value),
              child: Column(
                children: [
                  for (final reason in widget.reasons)
                    RadioListTile<int>(
                      value: reason.id,
                      title: Text(reason.label),
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                    ),
                ],
              ),
            ),
            TextField(
              controller: _note,
              maxLength: 500,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Ghi chú thêm (không bắt buộc)'),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Hủy')),
        FilledButton(
          onPressed: _reasonId == null
              ? null
              : () => Navigator.pop(context, (reasonId: _reasonId!, note: _note.text.trim())),
          child: const Text('Gửi báo cáo'),
        ),
      ],
    );
  }
}
