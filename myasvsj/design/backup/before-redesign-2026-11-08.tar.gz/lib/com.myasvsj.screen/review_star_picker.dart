import 'package:flutter/material.dart';

/// Chọn số sao 1–5 cho review; [value] 0 là chưa chọn. [errorText] hiện dưới hàng sao.
class ReviewStarPicker extends StatelessWidget {
  const ReviewStarPicker({super.key, required this.value, required this.onChanged, this.errorText});

  final int value;
  final ValueChanged<int> onChanged;
  final String? errorText;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            for (var n = 1; n <= 5; n++)
              IconButton(
                tooltip: '$n sao',
                visualDensity: VisualDensity.compact,
                onPressed: () => onChanged(n),
                icon: Icon(n <= value ? Icons.star : Icons.star_border, color: scheme.tertiary, size: 32),
              ),
            const SizedBox(width: 8),
            Flexible(child: Text(value > 0 ? '$value/5' : 'Chọn số sao')),
          ],
        ),
        if (errorText != null)
          Padding(
            padding: const EdgeInsets.only(left: 12),
            child: Text(errorText!, style: TextStyle(color: scheme.error, fontSize: 12)),
          ),
      ],
    );
  }
}
