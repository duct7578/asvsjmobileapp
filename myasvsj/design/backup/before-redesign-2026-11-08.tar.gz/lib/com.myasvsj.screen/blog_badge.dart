import 'package:flutter/material.dart';

/// Nhãn nhỏ có biểu tượng trên thẻ bài và màn chi tiết, ví dụ "Đã ghim", "Đang quét ảnh", "#1".
/// [warning] dùng màu nhấn của theme cho nhãn cần chú ý (bài đang quét, bị ẩn).
class BlogBadge extends StatelessWidget {
  const BlogBadge({super.key, required this.icon, required this.label, this.warning = false});

  final IconData icon;
  final String label;
  final bool warning;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final background = warning ? scheme.tertiaryContainer : scheme.secondaryContainer;
    final foreground = warning ? scheme.onTertiaryContainer : scheme.onSecondaryContainer;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(color: background, borderRadius: BorderRadius.circular(12)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: foreground),
          const SizedBox(width: 4),
          Flexible(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.labelSmall?.copyWith(color: foreground),
            ),
          ),
        ],
      ),
    );
  }
}
