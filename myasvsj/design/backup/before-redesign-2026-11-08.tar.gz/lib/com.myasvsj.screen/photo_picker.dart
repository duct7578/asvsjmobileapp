import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:image_picker/image_picker.dart';

/// Ô chọn ảnh cho form (bài viết, câu hỏi, review, ảnh minh chứng tag): chụp bằng camera hoặc chọn
/// trong thư viện, tối đa [max] ảnh, hiện ảnh nhỏ có nút xóa.
///
/// Mỗi ảnh được thu nhỏ còn cạnh dài ≤ 1600 px và đổi sang JPEG trước khi đưa ra ngoài, vì server chỉ đọc
/// JPEG và PNG (ảnh iPhone mặc định là HEIC). [onChanged] nhận danh sách đường dẫn file trên máy; Controller
/// chuyển nguyên danh sách này cho DAO, DAO gửi bằng `ApiClient.sendMultipart`.
class PhotoPicker extends StatefulWidget {
  const PhotoPicker({super.key, required this.paths, required this.onChanged, this.max = 5, this.label = 'Ảnh'});

  /// Ảnh đang chọn (đường dẫn trên máy).
  final List<String> paths;
  final ValueChanged<List<String>> onChanged;
  final int max;
  final String label;

  @override
  State<PhotoPicker> createState() => _PhotoPickerState();
}

class _PhotoPickerState extends State<PhotoPicker> {
  static const double _side = 1600;
  final _picker = ImagePicker();
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    final full = widget.paths.length >= widget.max;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('${widget.label} (${widget.paths.length}/${widget.max})'),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final path in widget.paths) _thumbnail(path),
            if (!full) ...[
              _addButton(Icons.photo_camera_outlined, 'Chụp ảnh', ImageSource.camera),
              _addButton(Icons.photo_library_outlined, 'Chọn ảnh', ImageSource.gallery),
            ],
          ],
        ),
      ],
    );
  }

  Widget _thumbnail(String path) {
    return Stack(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.file(File(path), width: 80, height: 80, fit: BoxFit.cover,
              errorBuilder: (_, _, _) => const SizedBox(width: 80, height: 80, child: Icon(Icons.broken_image))),
        ),
        Positioned(
          right: 0,
          top: 0,
          child: InkWell(
            onTap: () => widget.onChanged([...widget.paths]..remove(path)),
            child: const CircleAvatar(radius: 12, child: Icon(Icons.close, size: 16)),
          ),
        ),
      ],
    );
  }

  Widget _addButton(IconData icon, String tooltip, ImageSource source) {
    return SizedBox(
      width: 80,
      height: 80,
      child: OutlinedButton(
        onPressed: _busy ? null : () => _pick(source),
        style: OutlinedButton.styleFrom(padding: EdgeInsets.zero),
        child: Tooltip(message: tooltip, child: Icon(icon)),
      ),
    );
  }

  Future<void> _pick(ImageSource source) async {
    setState(() => _busy = true);
    try {
      final room = widget.max - widget.paths.length;
      final List<XFile> picked;
      if (source == ImageSource.camera) {
        final one = await _picker.pickImage(source: source, maxWidth: _side, maxHeight: _side, imageQuality: 85);
        picked = one == null ? const [] : [one];
      } else {
        picked = await _picker.pickMultiImage(maxWidth: _side, maxHeight: _side, imageQuality: 85, limit: room);
      }
      final added = <String>[];
      for (final file in picked.take(room)) {
        added.add(await _toJpeg(file.path));
      }
      if (added.isNotEmpty) {
        widget.onChanged([...widget.paths, ...added]);
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Không mở được camera hoặc thư viện ảnh.')));
      }
    } finally {
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  /// Đổi sang JPEG (ảnh HEIC của iPhone, ảnh WebP…). Lỗi thì giữ file gốc.
  Future<String> _toJpeg(String path) async {
    if (path.toLowerCase().endsWith('.jpg') || path.toLowerCase().endsWith('.jpeg')) {
      return path;
    }
    try {
      final target = '${Directory.systemTemp.path}/senpai_${DateTime.now().microsecondsSinceEpoch}.jpg';
      final result = await FlutterImageCompress.compressAndGetFile(path, target,
          quality: 85, minWidth: _side.toInt(), minHeight: _side.toInt(), format: CompressFormat.jpeg);
      return result?.path ?? path;
    } catch (_) {
      return path;
    }
  }
}
