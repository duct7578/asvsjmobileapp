import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/notification_controller.dart';
import 'package:myasvsj/com.myasvsj.model/app_notification.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/empty_view.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/link_router.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/notification_tile.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// Màn hình "Thông báo" (trang `/notifications` của web): thông báo mới nhất trước, 20 một trang, "Xem thêm".
/// Bấm một thông báo: đánh dấu đã đọc rồi mở trang của nó (bài viết, câu hỏi, địa điểm, sự kiện; tag → "Tôi").
class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key, this.linkOpener = openLink});

  /// Mở màn hình của một đường dẫn web; mặc định [openLink] (test thay để không phải dựng màn hình khác).
  final Future<bool> Function(BuildContext context, String? link) linkOpener;

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  int? _loadedFor;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    final notifications = context.watch<NotificationController>();
    final userId = auth.currentUser?.id;
    if (userId != null && userId != _loadedFor) {
      _loadedFor = userId;
      // Gọi sau khung hình: notifyListeners() không được chạy giữa lúc đang dựng giao diện
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          context.read<NotificationController>().loadNotifications();
        }
      });
    }
    final hasUnread = notifications.unreadCount > 0 || notifications.items.any((n) => !n.read);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Thông báo'),
        actions: [
          if (auth.isSignedIn)
            IconButton(
              tooltip: 'Đánh dấu tất cả đã đọc',
              icon: const Icon(Icons.done_all),
              onPressed: hasUnread ? _markAllRead : null,
            ),
        ],
      ),
      body: auth.isSignedIn ? _body(notifications) : _guest(),
    );
  }

  Widget _guest() => Center(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const EmptyView(text: 'Đăng nhập để xem thông báo của bạn.', icon: Icons.notifications_none),
        FilledButton(onPressed: () => requireSignIn(context), child: const Text('Đăng nhập')),
      ],
    ),
  );

  Widget _body(NotificationController n) {
    if (n.isLoading && n.items.isEmpty) {
      return const LoadingView();
    }
    if (n.error != null && n.items.isEmpty) {
      return ErrorView(message: n.error!, onRetry: n.loadNotifications);
    }
    final summary = n.items.isEmpty
        ? 'Chưa có thông báo.'
        : (n.unreadCount > 0 ? '${n.unreadCount} thông báo chưa đọc.' : 'Bạn đã xem hết thông báo.');
    // Dòng tóm tắt, các thông báo, rồi nút "Xem thêm" hoặc ô "Chưa có thông báo"
    final count = 1 + (n.items.isEmpty ? 1 : n.items.length) + (n.hasMore ? 1 : 0);
    return RefreshIndicator(
      onRefresh: n.loadNotifications,
      child: ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(),
        itemCount: count,
        itemBuilder: (context, i) {
          if (i == 0) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
              child: Text(summary, style: Theme.of(context).textTheme.bodySmall),
            );
          }
          if (n.items.isEmpty) {
            return const EmptyView(text: 'Chưa có thông báo.', icon: Icons.notifications_none);
          }
          final index = i - 1;
          if (index < n.items.length) {
            final item = n.items[index];
            return NotificationTile(notification: item, onTap: () => _open(item));
          }
          return Padding(
            padding: const EdgeInsets.all(16),
            child: Center(
              child: OutlinedButton(
                onPressed: n.isLoadingMore ? null : () => _loadMore(n),
                child: Text(n.isLoadingMore ? 'Đang tải…' : 'Xem thêm'),
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _loadMore(NotificationController n) async {
    await n.loadMore();
    if (mounted) {
      showMessage(context, n.takeMessage());
    }
  }

  /// Đánh dấu đã đọc (ngay trên màn hình, server lưu sau) rồi mở trang của thông báo.
  Future<void> _open(AppNotification item) async {
    final notifications = context.read<NotificationController>();
    final marking = notifications.markRead(item);
    final target = item.target;
    if (target != null) {
      unawaited(widget.linkOpener(context, target));
    }
    await marking;
    if (mounted) {
      showMessage(context, notifications.takeMessage());
    }
  }

  Future<void> _markAllRead() async {
    final notifications = context.read<NotificationController>();
    await notifications.markAllRead();
    if (mounted) {
      showMessage(context, notifications.takeMessage());
    }
  }
}
