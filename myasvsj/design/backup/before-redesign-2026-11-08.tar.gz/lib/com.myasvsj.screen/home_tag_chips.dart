import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/home_tag.dart';
import 'package:myasvsj/com.myasvsj.screen/home_format.dart';

/// Các tag định danh nhỏ cạnh tên người viết ("Mentor", "Kouhai"…), tô bằng màu server gửi.
class HomeTagChips extends StatelessWidget {
  const HomeTagChips({super.key, required this.tags});

  final List<HomeTag> tags;

  @override
  Widget build(BuildContext context) {
    if (tags.isEmpty) {
      return const SizedBox.shrink();
    }
    final theme = Theme.of(context);
    return Wrap(
      spacing: 4,
      runSpacing: 2,
      children: [
        for (final tag in tags)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
            decoration: BoxDecoration(
              border: Border.all(color: tagColor(tag.color) ?? theme.colorScheme.outline),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              tag.name,
              style: theme.textTheme.labelSmall?.copyWith(color: tagColor(tag.color) ?? theme.colorScheme.primary),
            ),
          ),
      ],
    );
  }
}
