import 'package:flutter/material.dart';

import 'package:myasvsj/com.myasvsj.model/search_event.dart';
import 'package:myasvsj/com.myasvsj.model/search_faq.dart';
import 'package:myasvsj/com.myasvsj.model/search_guide.dart';
import 'package:myasvsj/com.myasvsj.model/search_phrase.dart';
import 'package:myasvsj/com.myasvsj.model/search_place.dart';
import 'package:myasvsj/com.myasvsj.model/search_post.dart';
import 'package:myasvsj/com.myasvsj.model/search_question.dart';
import 'package:myasvsj/com.myasvsj.model/search_result.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/blog_list_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';
import 'package:myasvsj/com.myasvsj.screen/event_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/event_list_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/faq_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/for_you_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/guide_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/guide_list_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/home_format.dart';
import 'package:myasvsj/com.myasvsj.screen/home_speak_button.dart';
import 'package:myasvsj/com.myasvsj.screen/home_tag_chips.dart';
import 'package:myasvsj/com.myasvsj.screen/map_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/phrase_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/place_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/question_detail_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/question_list_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/search_badge.dart';
import 'package:myasvsj/com.myasvsj.screen/search_highlight.dart';
import 'package:myasvsj/com.myasvsj.screen/search_hit_tile.dart';

/// Kết quả "Tìm kiếm" theo từng phần (thứ tự như web): Địa điểm, Bài viết, Hỏi-Đáp, Cẩm nang, Sự kiện, Mẫu câu và
/// từ vựng, Câu hỏi thường gặp. Mỗi phần 5 mục đầu, chỗ khớp được tô; hàng nút trên cùng nhảy tới từng phần.
class SearchResultList extends StatefulWidget {
  const SearchResultList({super.key, required this.result, this.isMember = false});

  final SearchResult result;

  /// Thành viên có thêm "Chỉ tìm trong bài dành cho bạn".
  final bool isMember;

  @override
  State<SearchResultList> createState() => _SearchResultListState();
}

/// Một phần của kết quả: khóa, tên, biểu tượng, số mục.
typedef _Group = ({String key, String title, IconData icon, int total});

class _SearchResultListState extends State<SearchResultList> {
  final Map<String, GlobalKey> _keys = {};

  GlobalKey _keyOf(String group) => _keys.putIfAbsent(group, GlobalKey.new);

  void _jump(String group) {
    final target = _keys[group]?.currentContext;
    if (target != null) {
      Scrollable.ensureVisible(target, duration: const Duration(milliseconds: 300));
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = widget.result;
    final q = r.q;
    final theme = Theme.of(context);
    final List<_Group> groups = [
      (key: 'places', title: 'Địa điểm', icon: Icons.location_on_outlined, total: r.places.total),
      (key: 'posts', title: 'Bài viết', icon: Icons.forum_outlined, total: r.posts.total),
      (key: 'questions', title: 'Hỏi-Đáp', icon: Icons.contact_support_outlined, total: r.questions.total),
      (key: 'guides', title: 'Cẩm nang', icon: Icons.menu_book_outlined, total: r.guides.total),
      (key: 'events', title: 'Sự kiện', icon: Icons.celebration_outlined, total: r.events.total),
      (key: 'phrases', title: 'Mẫu câu và từ vựng', icon: Icons.translate, total: r.phrases.total),
      (key: 'faqs', title: 'Câu hỏi thường gặp', icon: Icons.quiz_outlined, total: r.faqs.total),
    ].where((g) => g.total > 0).toList();

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Tìm thấy ${r.total} kết quả cho “$q”.'),
          if (groups.length > 1) ...[
            const SizedBox(height: 8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  for (final g in groups)
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ActionChip(
                        avatar: Icon(g.icon, size: 18),
                        label: Text('${g.title} ${g.total}'),
                        onPressed: () => _jump(g.key),
                      ),
                    ),
                ],
              ),
            ),
          ],
          for (final g in groups) _section(context, g, q),
          if (r.places.isEmpty) ...[
            const SizedBox(height: 16),
            Text(
              'Không thấy địa điểm cần tìm? Bản đồ có cả địa điểm của OpenStreetMap.',
              style: theme.textTheme.bodySmall,
            ),
            TextButton.icon(
              onPressed: () => pushScreen<void>(context, const MapScreen()),
              icon: const Icon(Icons.map_outlined),
              label: const Text('Mở Bản đồ'),
            ),
          ],
        ],
      ),
    );
  }

  Widget _section(BuildContext context, _Group g, String q) {
    final r = widget.result;
    final theme = Theme.of(context);
    final (List<Widget> items, List<Widget> links) = switch (g.key) {
      'places' => (
        [for (final p in r.places.items) _place(context, p, q)],
        [_link(context, 'Mở Bản đồ (có cả địa điểm OpenStreetMap)', const MapScreen())],
      ),
      'posts' => (
        [for (final p in r.posts.items) _post(context, p, q)],
        [
          if (r.posts.hasMore)
            _link(context, 'Xem tất cả ${r.posts.total} bài viết trong Blog', const BlogListScreen()),
          if (widget.isMember)
            _link(context, 'Chỉ tìm trong bài dành cho bạn', ForYouScreen(initialQuery: q), icon: Icons.auto_awesome),
        ],
      ),
      'questions' => (
        [for (final x in r.questions.items) _question(context, x, q)],
        [
          if (r.questions.hasMore)
            _link(context, 'Xem tất cả ${r.questions.total} câu hỏi trong Hỏi-Đáp', QuestionListScreen(initialQuery: q)),
        ],
      ),
      'guides' => (
        [for (final x in r.guides.items) _guide(context, x, q)],
        [if (r.guides.hasMore) _link(context, 'Xem tất cả ${r.guides.total} bài cẩm nang', const GuideListScreen())],
      ),
      'events' => (
        [for (final x in r.events.items) _event(context, x, q)],
        [if (r.events.hasMore) _link(context, 'Xem tất cả ${r.events.total} sự kiện', const EventListScreen())],
      ),
      'phrases' => (
        [for (final x in r.phrases.items) _phrase(context, x, q)],
        [
          if (r.phrases.hasMore)
            _link(context, 'Xem tất cả ${r.phrases.total} mẫu câu và từ vựng trong Nhật ngữ', PhraseScreen(initialQuery: q)),
        ],
      ),
      _ => (
        [for (final x in r.faqs.items) _faq(context, x, q)],
        [
          if (r.faqs.hasMore)
            _link(context, 'Xem tất cả ${r.faqs.total} câu hỏi thường gặp', QuestionListScreen(initialTab: 1, initialQuery: q)),
        ],
      ),
    };
    return Padding(
      key: _keyOf(g.key),
      padding: const EdgeInsets.only(top: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(g.icon, color: theme.colorScheme.primary),
              const SizedBox(width: 8),
              Expanded(child: Text(g.title, style: theme.textTheme.titleMedium)),
              Text('${g.total}', style: theme.textTheme.labelLarge),
            ],
          ),
          const Divider(),
          ...items,
          ...links,
        ],
      ),
    );
  }

  Widget _link(BuildContext context, String label, Widget screen, {IconData icon = Icons.arrow_forward}) => Align(
    alignment: Alignment.centerLeft,
    child: TextButton.icon(
      onPressed: () => pushScreen<void>(context, screen),
      icon: Icon(icon, size: 18),
      label: Text(label),
    ),
  );

  Widget _meta(BuildContext context, List<Widget> children) =>
      Wrap(spacing: 6, runSpacing: 2, crossAxisAlignment: WrapCrossAlignment.center, children: children);

  Widget _small(BuildContext context, String text) => Text(text, style: Theme.of(context).textTheme.bodySmall);

  Widget _excerpt(BuildContext context, String text, String q) => text.isEmpty
      ? const SizedBox.shrink()
      : SearchHighlight(text: text, query: q, style: Theme.of(context).textTheme.bodyMedium, maxLines: 3);

  Widget _place(BuildContext context, SearchPlace p, String q) {
    final other = p.otherName;
    final where = areaRoman(p.areaName);
    return SearchHitTile(
      icon: categoryIcon(p.categoryIcon),
      title: Wrap(
        spacing: 6,
        children: [
          SearchHighlight(text: p.name, query: q),
          if (other != null) SearchHighlight(text: other, query: q, style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
      onTap: () => pushScreen<void>(context, PlaceDetailScreen(placeId: p.id)),
      children: [
        if ((p.address ?? '').isNotEmpty) _excerpt(context, p.address!, q),
        _meta(context, [
          if (p.categoryName.isNotEmpty) SearchBadge(text: p.categoryName),
          if (where.isNotEmpty) _small(context, where),
          _small(context, p.reviewCount > 0 ? '★ ${p.rating ?? ''} · ${p.reviewCount} review' : 'Chưa có review'),
          if (p.closed) const SearchBadge(text: 'Đã đóng cửa', warn: true),
        ]),
      ],
    );
  }

  Widget _post(BuildContext context, SearchPost b, String q) => SearchHitTile(
    icon: Icons.article_outlined,
    title: SearchHighlight(text: b.title, query: q, maxLines: 2),
    onTap: () => pushScreen<void>(context, BlogDetailScreen(blogId: b.id)),
    children: [
      _excerpt(context, b.excerpt, q),
      _meta(context, [
        if (b.isProcessing) const SearchBadge(text: 'Đang kiểm duyệt', warn: true),
        if (b.topicNames.isNotEmpty) SearchBadge(text: b.topicNames.first),
        _small(context, b.authorName),
        HomeTagChips(tags: b.authorTags),
        _small(
          context,
          [
            if (b.createdAt != null) formatTimeAgo(b.createdAt!),
            '♥ ${b.likeCount}',
            '${b.commentCount} bình luận',
          ].join(' · '),
        ),
      ]),
    ],
  );

  Widget _question(BuildContext context, SearchQuestion x, String q) => SearchHitTile(
    icon: Icons.help_outline,
    title: SearchHighlight(text: x.title, query: q, maxLines: 2),
    onTap: () => pushScreen<void>(context, QuestionDetailScreen(questionId: x.id)),
    children: [
      _excerpt(context, x.excerpt, q),
      _meta(context, [
        if (x.isProcessing) const SearchBadge(text: 'Đang kiểm duyệt', warn: true),
        if (x.solved)
          const SearchBadge(text: 'Đã giải quyết')
        else if (x.unanswered)
          const SearchBadge(text: 'Chưa ai trả lời', warn: true),
        if (x.topicNames.isNotEmpty) SearchBadge(text: x.topicNames.first),
        _small(
          context,
          [x.authorName, if (x.createdAt != null) formatTimeAgo(x.createdAt!), '${x.answerCount} trả lời'].join(' · '),
        ),
      ]),
    ],
  );

  Widget _guide(BuildContext context, SearchGuide g, String q) {
    // Cẩm nang không có chủ đề riêng thì server trả giai đoạn làm chủ đề: chỉ ghi một lần
    final where = {g.stageName, g.topicName}.whereType<String>().where((s) => s.isNotEmpty).join(' · ');
    return SearchHitTile(
      icon: Icons.menu_book_outlined,
      title: SearchHighlight(text: g.title, query: q, maxLines: 2),
      onTap: () => pushScreen<void>(context, GuideDetailScreen(guideId: g.id)),
      children: [_excerpt(context, g.summary, q), if (where.isNotEmpty) _small(context, where)],
    );
  }

  Widget _event(BuildContext context, SearchEvent e, String q) {
    final state = switch (e.state) {
      'NOW' => 'Đang diễn ra',
      'PAST' => 'Đã qua',
      _ => 'Còn ${e.daysUntil} ngày',
    };
    final range = e.startDate == e.endDate
        ? formatDate(e.startDate)
        : '${formatDate(e.startDate)} – ${formatDate(e.endDate)}';
    return SearchHitTile(
      icon: Icons.celebration_outlined,
      title: SearchHighlight(text: e.title, query: q, maxLines: 2),
      onTap: () => pushScreen<void>(context, EventDetailScreen(eventId: e.id)),
      children: [
        _meta(context, [SearchBadge(text: state, warn: e.state == 'PAST'), _small(context, range)]),
        SearchHighlight(
          text: (e.locationName ?? '').isEmpty ? 'Chưa gắn vị trí' : e.locationName!,
          query: q,
          style: Theme.of(context).textTheme.bodySmall,
          maxLines: 2,
        ),
      ],
    );
  }

  Widget _phrase(BuildContext context, SearchPhrase p, String q) => SearchHitTile(
    icon: Icons.translate,
    title: SearchHighlight(text: p.japanese, query: q),
    onTap: () => pushScreen<void>(context, PhraseScreen(initialQuery: p.japanese)),
    trailing: HomeSpeakButton(text: p.japanese, compact: true),
    children: [
      if (p.romaji.isNotEmpty) SearchHighlight(text: p.romaji, query: q, style: Theme.of(context).textTheme.bodySmall),
      SearchHighlight(text: p.meaningVi, query: q),
      _meta(context, [
        SearchBadge(text: p.isVocab ? 'Từ vựng' : 'Mẫu câu'),
        if ((p.categoryName ?? '').isNotEmpty) _small(context, p.categoryName!),
      ]),
    ],
  );

  Widget _faq(BuildContext context, SearchFaq f, String q) => SearchHitTile(
    icon: Icons.quiz_outlined,
    title: SearchHighlight(text: f.question, query: q, maxLines: 2),
    onTap: () => pushScreen<void>(context, FaqScreen(faqId: f.id)),
    children: [_excerpt(context, f.answer, q), if ((f.topicName ?? '').isNotEmpty) _small(context, f.topicName!)],
  );
}
