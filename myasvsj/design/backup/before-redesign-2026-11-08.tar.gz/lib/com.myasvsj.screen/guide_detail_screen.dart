import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/guide_controller.dart';
import 'package:myasvsj/com.myasvsj.model/guide.dart';
import 'package:myasvsj/com.myasvsj.model/guide_viewer.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/date_text.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/guide_content.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/media_image.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// Chi tiết một cẩm nang (`GET /api/guides/{id}`): các mục có ảnh, nguồn tham khảo; hàng nút của người xem
/// (`…/viewer`): Lưu / Đã lưu, Đánh dấu đã xong hoặc "Tiến độ: x/y việc"; và tab "Hướng dẫn chuẩn bị" (checklist
/// `…/preparation`) khi cẩm nang có checklist. Khách tick được checklist nhưng không lưu (màn hình nói rõ).
class GuideDetailScreen extends StatefulWidget {
  const GuideDetailScreen({super.key, required this.guideId, this.openChecklist = false});

  final int guideId;

  /// Mở sẵn tab "Hướng dẫn chuẩn bị" (như `?tab=preparation` của web), ví dụ từ "Cẩm nang của tôi".
  final bool openChecklist;

  @override
  State<GuideDetailScreen> createState() => _GuideDetailScreenState();
}

class _GuideDetailScreenState extends State<GuideDetailScreen> {
  /// Người đang đăng nhập lúc tải; đổi (vừa đăng nhập / đăng xuất) thì tải lại trạng thái và dấu tick.
  int? _userId;

  static final RegExp _numbered = RegExp(r'^\d+[.)]\s');

  @override
  void initState() {
    super.initState();
    _userId = context.read<AuthController>().currentUser?.id;
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final guides = context.read<GuideController>();
    await guides.loadGuide(widget.guideId);
    if (mounted) {
      showMessage(context, guides.takeMessage());
    }
  }

  @override
  Widget build(BuildContext context) {
    final guides = context.watch<GuideController>();
    final userId = context.watch<AuthController>().currentUser?.id;
    if (userId != _userId) {
      _userId = userId;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          _load();
        }
      });
    }
    final guide = guides.guideOf(widget.guideId);
    if (guide == null) {
      final error = guides.guideErrorOf(widget.guideId);
      return Scaffold(
        appBar: AppBar(title: const Text('Cẩm nang')),
        body: error != null ? ErrorView(message: error, onRetry: _load) : const LoadingView(),
      );
    }
    final viewer = guides.viewerOf(widget.guideId);
    if (!guide.preparationEnabled) {
      return Scaffold(
        appBar: AppBar(title: const Text('Cẩm nang')),
        body: _page([_header(guides, guide, viewer), ..._details(guide)]),
      );
    }
    return DefaultTabController(
      length: 2,
      initialIndex: widget.openChecklist ? 1 : 0,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Cẩm nang'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Xem chi tiết'),
              Tab(text: 'Hướng dẫn chuẩn bị'),
            ],
          ),
        ),
        // Tiêu đề và hàng nút ở đầu cả hai tab, nên "Lưu" và "Tiến độ" luôn thấy (như web)
        body: TabBarView(
          children: [
            _page([_header(guides, guide, viewer), ..._details(guide)]),
            _page([_header(guides, guide, viewer), ..._checklist(guides, guide)]),
          ],
        ),
      ),
    );
  }

  Widget _page(List<Widget> children) => RefreshIndicator(
    onRefresh: _load,
    child: ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 32), children: children),
  );

  // ---------------------------------------------------------------- Đầu trang và hàng nút

  Widget _header(GuideController guides, Guide guide, GuideViewer? viewer) {
    final theme = Theme.of(context);
    final created = guide.createdAt;
    final meta = [
      if (created != null) 'Ngày tạo: ${formatDate(created)}',
      if (guide.creatorName != null && guide.creatorName!.isNotEmpty) guide.creatorName!,
    ].join(' · ');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (guide.topicName != null)
          Text(guide.topicName!, style: theme.textTheme.labelLarge?.copyWith(color: theme.colorScheme.primary)),
        const SizedBox(height: 4),
        Text(guide.title, style: theme.textTheme.headlineSmall),
        if (meta.isNotEmpty) ...[const SizedBox(height: 4), Text(meta, style: theme.textTheme.bodySmall)],
        if (viewer != null) _memberActions(guides, guide, viewer),
        const Divider(height: 24),
      ],
    );
  }

  /// Khách: lời mời đăng nhập và các nút (bấm thì đăng nhập). Thành viên: "Lưu" và "Đánh dấu đã xong", hoặc
  /// "Tiến độ" với cẩm nang có checklist (bấm mở tab checklist). Tài khoản staff: không có gì.
  Widget _memberActions(GuideController guides, Guide guide, GuideViewer viewer) {
    if (viewer.signedIn && !viewer.member) {
      return const SizedBox.shrink();
    }
    final theme = Theme.of(context);
    final progress = viewer.progress;
    final busy = guides.isBusy(guide.id);
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!viewer.signedIn)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text('Đăng nhập để lưu cẩm nang và theo dõi tiến độ.', style: theme.textTheme.bodySmall),
            ),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _toggleButton(
                on: viewer.saved,
                icon: viewer.saved ? Icons.bookmark_added : Icons.bookmark_border,
                label: viewer.saved ? 'Đã lưu' : 'Lưu',
                onPressed: busy ? null : () => _memberAction(guides.toggleSave),
              ),
              if (progress.checklist)
                Builder(
                  builder: (tabContext) => _toggleButton(
                    on: progress.done,
                    icon: Icons.checklist,
                    label: progress.done
                        ? 'Đã xong · ${progress.tasksTotal}/${progress.tasksTotal} việc'
                        : 'Tiến độ: ${progress.tasksDone}/${progress.tasksTotal} việc',
                    onPressed: () => DefaultTabController.maybeOf(tabContext)?.animateTo(1),
                  ),
                )
              else
                _toggleButton(
                  on: progress.done,
                  icon: Icons.task_alt,
                  label: progress.done ? 'Đã xong' : 'Đánh dấu đã xong',
                  onPressed: busy ? null : () => _memberAction(guides.toggleDone),
                ),
            ],
          ),
          if (viewer.signedIn && progress.checklist && !progress.done && progress.nextTask != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text('Việc tiếp theo: ${progress.nextTask}', style: theme.textTheme.bodySmall),
            ),
        ],
      ),
    );
  }

  Widget _toggleButton({
    required bool on,
    required IconData icon,
    required String label,
    required VoidCallback? onPressed,
  }) {
    return on
        ? FilledButton.tonalIcon(onPressed: onPressed, icon: Icon(icon), label: Text(label))
        : OutlinedButton.icon(onPressed: onPressed, icon: Icon(icon), label: Text(label));
  }

  /// "Lưu" / "Đánh dấu đã xong" cần tài khoản: khách được đưa sang đăng nhập; đăng nhập xong trang tự tải lại
  /// trạng thái thật của tài khoản, người dùng bấm lại nếu vẫn muốn.
  Future<void> _memberAction(Future<void> Function(int id) action) async {
    if (!context.read<AuthController>().isSignedIn) {
      await requireSignIn(context);
      return;
    }
    final guides = context.read<GuideController>();
    await action(widget.guideId);
    if (mounted) {
      showMessage(context, guides.takeMessage());
    }
  }

  // ---------------------------------------------------------------- Tab "Xem chi tiết"

  List<Widget> _details(Guide guide) {
    final theme = Theme.of(context);
    final cover = guide.coverImageUrl;
    final source = guide.sourceUrl;
    return [
      if (guide.summary.isNotEmpty) Text(guide.summary, style: theme.textTheme.bodyLarge),
      if (cover != null && cover.isNotEmpty) ...[
        const SizedBox(height: 12),
        MediaImage(url: cover, height: 180, width: double.infinity),
      ],
      if (guide.stageName != null) ...[
        const SizedBox(height: 8),
        Text('Giai đoạn: ${guide.stageName}', style: theme.textTheme.bodySmall),
      ],
      if (source != null) _linkButton('Đường dẫn gốc', source),
      for (var i = 0; i < guide.sections.length; i++) ...[
        const SizedBox(height: 16),
        Text(
          _numbered.hasMatch(guide.sections[i].heading)
              ? guide.sections[i].heading
              : '${i + 1}. ${guide.sections[i].heading}',
          style: theme.textTheme.titleMedium,
        ),
        const SizedBox(height: 4),
        GuideContent(text: guide.sections[i].content, onOpenLink: _openUrl),
        if (guide.sections[i].imageUrl != null) ...[
          const SizedBox(height: 8),
          MediaImage(url: guide.sections[i].imageUrl!, width: double.infinity, fit: BoxFit.fitWidth),
        ],
        if (guide.sections[i].referenceUrl != null) _linkButton('Tài liệu tham khảo', guide.sections[i].referenceUrl!),
      ],
      if (guide.sections.isEmpty)
        Padding(
          padding: const EdgeInsets.only(top: 16),
          child: Text('Nội dung hướng dẫn đang được cập nhật.', style: theme.textTheme.bodyMedium),
        ),
    ];
  }

  Widget _linkButton(String label, String url) => Align(
    alignment: Alignment.centerLeft,
    child: TextButton.icon(
      onPressed: () => _openUrl(url),
      icon: const Icon(Icons.open_in_new, size: 18),
      label: Text(label),
    ),
  );

  // ---------------------------------------------------------------- Tab "Hướng dẫn chuẩn bị"

  List<Widget> _checklist(GuideController guides, Guide guide) {
    final theme = Theme.of(context);
    final preparation = guides.preparationOf(guide.id);
    final error = guides.preparationErrorOf(guide.id);
    final head = [
      Text('Hướng dẫn chuẩn bị', style: theme.textTheme.titleLarge),
      Text(guide.title, style: theme.textTheme.bodySmall),
      const SizedBox(height: 12),
    ];
    if (preparation == null) {
      return [
        ...head,
        if (error != null)
          ErrorView(message: error, onRetry: () => guides.loadPreparation(guide.id))
        else
          const SizedBox(height: 120, child: LoadingView()),
      ];
    }
    final ticking = guides.isTicking(guide.id);
    return [
      ...head,
      Text(
        '${preparation.completed}/${preparation.total} công việc đã hoàn thành · ${preparation.percent}%',
        style: theme.textTheme.titleSmall,
      ),
      const SizedBox(height: 8),
      LinearProgressIndicator(value: preparation.percent / 100, semanticsLabel: 'Tiến độ chuẩn bị'),
      if (!preparation.signedIn) _guestNote(),
      const SizedBox(height: 8),
      for (final task in preparation.tasks)
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          controlAffinity: ListTileControlAffinity.leading,
          value: task.completed,
          onChanged: ticking ? null : (value) => _tick(guides, task.id, value ?? false),
          title: Text(task.title),
          subtitle: task.notes.isEmpty ? null : Text(task.notes),
        ),
      if (preparation.tasks.isEmpty)
        Text('Chưa có công việc trong danh sách chuẩn bị.', style: theme.textTheme.bodyMedium),
    ];
  }

  Widget _guestNote() {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: scheme.secondaryContainer, borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Bạn chưa đăng nhập: dấu tick chỉ để tự theo dõi và sẽ mất khi rời trang, không được lưu. '
            'Đăng nhập để tick công việc và lưu tiến độ riêng của bạn.',
            style: TextStyle(color: scheme.onSecondaryContainer),
          ),
          TextButton(onPressed: () => requireSignIn(context), child: const Text('Đăng nhập')),
        ],
      ),
    );
  }

  Future<void> _tick(GuideController guides, int taskId, bool completed) async {
    await guides.toggleTask(widget.guideId, taskId, completed);
    if (mounted) {
      showMessage(context, guides.takeMessage());
    }
  }

  /// Mở link http / https bằng trình duyệt; link khác bị bỏ qua.
  Future<void> _openUrl(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null || !(uri.scheme == 'http' || uri.scheme == 'https') || uri.host.isEmpty) {
      showMessage(context, 'Link không hợp lệ.');
      return;
    }
    var opened = false;
    try {
      opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      // Máy không có trình duyệt: báo bên dưới
    }
    if (!opened && mounted) {
      showMessage(context, 'Không mở được link.');
    }
  }
}
