import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/auth_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/phrase_controller.dart';
import 'package:myasvsj/com.myasvsj.model/phrase.dart';
import 'package:myasvsj/com.myasvsj.model/phrase_group.dart';
import 'package:myasvsj/com.myasvsj.model/phrase_overview.dart';
import 'package:myasvsj/com.myasvsj.model/phrase_part.dart';
import 'package:myasvsj/com.myasvsj.screen/empty_view.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/phrase_card.dart';
import 'package:myasvsj/com.myasvsj.screen/phrase_icon.dart';
import 'package:myasvsj/com.myasvsj.screen/phrase_list_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/phrase_practice_screen.dart';
import 'package:myasvsj/com.myasvsj.screen/sign_in_gate.dart';

/// Trang đầu Nhật ngữ (renderStart() của web): ô tìm (tiếng Nhật, romaji, nghĩa, chủ đề), nút "Luyện tập", rồi hai
/// cách xem "Chủ đề" / "Địa điểm", mỗi cách chia "Từ vựng" và "Mẫu câu" với số mục và tiến độ "đã thuộc" (thành viên).
/// Thành viên có thêm lối vào danh sách "Chưa thuộc" / "Đã thuộc". Khi đang tìm, kết quả thay chỗ phần bên dưới.
///
/// [topicId] / [categoryId] (ví dụ "Học thêm chủ đề này" ở Trang chủ) mở thẳng bộ đó lên trên trang đầu;
/// [initialQuery] (từ Tìm kiếm) tìm ngay khi mở.
class PhraseScreen extends StatefulWidget {
  const PhraseScreen({super.key, this.topicId, this.categoryId, this.initialQuery = ''});

  final String? topicId;
  final String? categoryId;
  final String initialQuery;

  @override
  State<PhraseScreen> createState() => _PhraseScreenState();
}

class _PhraseScreenState extends State<PhraseScreen> {
  static const Duration _searchDelay = Duration(milliseconds: 250);

  late final TextEditingController _search = TextEditingController(text: widget.initialQuery);
  Timer? _debounce;

  /// "topic" = Chủ đề, "category" = Địa điểm.
  String _by = 'topic';
  bool _started = false;
  int? _userId;

  @override
  void dispose() {
    _debounce?.cancel();
    _search.dispose();
    super.dispose();
  }

  /// Lần mở đầu: tìm theo [PhraseScreen.initialQuery] (chữ trống xóa kết quả của lần mở trước), tải trang đầu,
  /// rồi mở bộ được yêu cầu.
  void _open() {
    final phrases = context.read<PhraseController>();
    phrases.search(widget.initialQuery);
    phrases.loadOverview();
    if (widget.topicId != null || widget.categoryId != null) {
      Navigator.push(
        context,
        MaterialPageRoute<void>(
          builder: (_) => PhraseListScreen(topicId: widget.topicId, categoryId: widget.categoryId),
        ),
      );
    }
  }

  /// Kéo xuống làm mới, hoặc người dùng vừa đăng nhập / đăng xuất: số "đã thuộc" là của từng người.
  Future<void> _reload() async {
    final phrases = context.read<PhraseController>();
    await Future.wait([phrases.loadOverview(), if (phrases.query.isNotEmpty) phrases.search(phrases.query)]);
  }

  void _onChanged(String text) {
    setState(() {});
    _debounce?.cancel();
    _debounce = Timer(_searchDelay, () => context.read<PhraseController>().search(text));
  }

  void _onSubmitted(String text) {
    _debounce?.cancel();
    context.read<PhraseController>().search(text);
  }

  void _clearSearch() {
    _search.clear();
    _onSubmitted('');
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final userId = context.select<AuthController, int?>((a) => a.currentUser?.id);
    if (!_started || userId != _userId) {
      final first = !_started;
      _started = true;
      _userId = userId;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          first ? _open() : _reload();
        }
      });
    }
    final phrases = context.watch<PhraseController>();
    return Scaffold(
      appBar: AppBar(title: const Text('Nhật ngữ')),
      body: _body(phrases, userId != null),
    );
  }

  Widget _body(PhraseController phrases, bool signedIn) {
    final overview = phrases.overview;
    if (overview == null) {
      final error = phrases.overviewError;
      return error != null ? ErrorView(message: error, onRetry: phrases.loadOverview) : const LoadingView();
    }
    final theme = Theme.of(context);
    return RefreshIndicator(
      onRefresh: _reload,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          Text(
            'Học trước những câu và từ bạn sẽ cần khi sống ở Nhật. Mỗi mẫu câu, từ vựng thuộc một loại địa điểm '
            '(cửa hàng tiện lợi, ga tàu…) và một hoặc nhiều chủ đề, do Biên tập viên nội dung tiếng Nhật biên soạn.',
            style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _search,
            textInputAction: TextInputAction.search,
            onChanged: _onChanged,
            onSubmitted: _onSubmitted,
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search),
              hintText: 'Tìm câu tiếng Nhật, nghĩa, chủ đề',
              border: const OutlineInputBorder(),
              isDense: true,
              suffixIcon: _search.text.isEmpty
                  ? null
                  : IconButton(tooltip: 'Xóa', icon: const Icon(Icons.close), onPressed: _clearSearch),
            ),
          ),
          const SizedBox(height: 12),
          if (phrases.query.isNotEmpty)
            ..._results(phrases, overview)
          else
            ..._browse(phrases.isMember, signedIn, overview),
        ],
      ),
    );
  }

  /// Kết quả tìm, chia "Từ vựng (n)" và "Mẫu câu (m)".
  List<Widget> _results(PhraseController phrases, PhraseOverview overview) {
    final theme = Theme.of(context);
    if (phrases.isSearching && phrases.results.isEmpty) {
      return const [LinearProgressIndicator()];
    }
    if (phrases.searchError != null) {
      return [Text(phrases.searchError!, style: TextStyle(color: theme.colorScheme.error))];
    }
    final found = phrases.results;
    return [
      Text('${found.length} kết quả', style: theme.textTheme.bodySmall),
      if (found.isEmpty) const EmptyView(text: 'Không tìm thấy mẫu câu hay từ vựng nào.', icon: Icons.search_off),
      for (final kind in Phrase.kinds)
        if (found.any((p) => p.kind == kind)) ...[
          _heading(
            overview.part(kind)?.icon ?? (kind == Phrase.vocabKind ? 'abc' : 'chat'),
            '${Phrase.kindName(kind)} (${found.where((p) => p.kind == kind).length})',
          ),
          for (final p in found.where((p) => p.kind == kind)) PhraseCard(phrase: p),
        ],
    ];
  }

  /// Phần duyệt: "Luyện tập", lời mời đăng nhập (khách), "Chủ đề" / "Địa điểm", rồi Từ vựng và Mẫu câu.
  List<Widget> _browse(bool member, bool signedIn, PhraseOverview overview) {
    final theme = Theme.of(context);
    return [
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          FilledButton.icon(
            onPressed: () => _push(const PhrasePracticeScreen()),
            icon: const Icon(Icons.style_outlined),
            label: const Text('Luyện tập'),
          ),
          if (member) ...[
            OutlinedButton.icon(
              onPressed: () => _push(const PhraseListScreen(mine: 'learning')),
              icon: const Icon(Icons.replay),
              label: const Text('Chưa thuộc'),
            ),
            OutlinedButton.icon(
              onPressed: () => _push(const PhraseListScreen(mine: 'learned')),
              icon: const Icon(Icons.task_alt),
              label: const Text('Đã thuộc'),
            ),
          ],
        ],
      ),
      if (!signedIn) ...[
        const SizedBox(height: 12),
        Card(
          margin: EdgeInsets.zero,
          color: theme.colorScheme.surfaceContainerHighest,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
            child: Row(
              children: [
                const Icon(Icons.info_outline),
                const SizedBox(width: 8),
                const Expanded(child: Text('Đăng nhập để lưu kết quả lật thẻ (Chưa thuộc / Đã thuộc).')),
                TextButton(onPressed: () => requireSignIn(context), child: const Text('Đăng nhập')),
              ],
            ),
          ),
        ),
      ],
      const SizedBox(height: 16),
      SegmentedButton<String>(
        showSelectedIcon: false,
        segments: [
          ButtonSegment(
            value: 'topic',
            icon: const Icon(Icons.category_outlined),
            label: Text('Chủ đề (${overview.groupsOf('topic').length})'),
          ),
          ButtonSegment(
            value: 'category',
            icon: const Icon(Icons.location_on_outlined),
            label: Text('Địa điểm (${overview.groupsOf('category').length})'),
          ),
        ],
        selected: {_by},
        onSelectionChanged: (value) => setState(() => _by = value.first),
      ),
      for (final part in overview.shownParts) ..._section(part, member),
    ];
  }

  /// "Từ vựng" hoặc "Mẫu câu" trong cách xem đang chọn: các chủ đề hoặc loại địa điểm của nó.
  List<Widget> _section(PhrasePart part, bool member) {
    final groups = part.groupsOf(_by);
    final learned = member ? ' · ${part.learned}/${part.count} đã thuộc' : '';
    return [
      const SizedBox(height: 16),
      _heading(part.icon, part.name, trailing: '${part.count} mục$learned'),
      if (groups.isEmpty)
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Text('Chưa có ${part.name.toLowerCase()} nào.'),
        )
      else
        for (final g in groups)
          _GroupTile(
            group: g,
            member: member,
            onTap: () => _push(
              PhraseListScreen(
                topicId: _by == 'topic' ? g.id : null,
                categoryId: _by == 'category' ? g.id : null,
                kind: part.kind,
              ),
            ),
          ),
    ];
  }

  Widget _heading(String icon, String title, {String? trailing}) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          PhraseIcon(icon, color: theme.colorScheme.primary),
          const SizedBox(width: 8),
          Expanded(child: Text(title, style: theme.textTheme.titleMedium)),
          if (trailing != null) Text(trailing, style: theme.textTheme.bodySmall),
        ],
      ),
    );
  }

  void _push(Widget screen) => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => screen));
}

/// Thẻ một chủ đề / loại địa điểm ở trang đầu: biểu tượng, tên, số mục, và thanh "đã thuộc" cho thành viên.
class _GroupTile extends StatelessWidget {
  const _GroupTile({required this.group, required this.member, required this.onTap});

  final PhraseGroup group;
  final bool member;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        onTap: onTap,
        leading: PhraseIcon(group.icon, size: 28, color: theme.colorScheme.primary),
        title: Text(group.name, maxLines: 2, overflow: TextOverflow.ellipsis),
        subtitle: member
            ? Row(
                children: [
                  Expanded(child: LinearProgressIndicator(value: group.count == 0 ? 0 : group.learned / group.count)),
                  const SizedBox(width: 8),
                  Text('${group.learned}/${group.count}'),
                ],
              )
            : Text('${group.count} mục'),
        trailing: const Icon(Icons.chevron_right),
      ),
    );
  }
}
