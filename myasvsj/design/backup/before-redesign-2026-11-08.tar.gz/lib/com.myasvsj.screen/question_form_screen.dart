import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:myasvsj/com.myasvsj.controller/faq_controller.dart';
import 'package:myasvsj/com.myasvsj.controller/question_controller.dart';
import 'package:myasvsj/com.myasvsj.model/media_item.dart';
import 'package:myasvsj/com.myasvsj.model/question_compose.dart';
import 'package:myasvsj/com.myasvsj.screen/app_message.dart';
import 'package:myasvsj/com.myasvsj.screen/error_view.dart';
import 'package:myasvsj/com.myasvsj.screen/faq_tile.dart';
import 'package:myasvsj/com.myasvsj.screen/loading_view.dart';
import 'package:myasvsj/com.myasvsj.screen/media_image.dart';
import 'package:myasvsj/com.myasvsj.screen/photo_picker.dart';
import 'package:myasvsj/com.myasvsj.screen/question_detail_screen.dart';

/// Form "Đặt câu hỏi" ([questionId] null) và "Sửa câu hỏi" (`/qa/ask`, `/qa/{id}/edit` của web): câu hỏi, chủ đề,
/// mô tả chi tiết, tối đa 5 ảnh. Khi gõ câu hỏi mới (≥ 8 ký tự) hiện các câu hỏi thường gặp giống điều định hỏi.
///
/// Đặt xong: mở câu hỏi vừa đăng. Sửa xong: đóng form và trả về true để màn chi tiết hiện câu thông báo.
class QuestionFormScreen extends StatefulWidget {
  const QuestionFormScreen({super.key, this.questionId});

  /// null = đặt câu hỏi mới; khác null = sửa câu hỏi này.
  final int? questionId;

  @override
  State<QuestionFormScreen> createState() => _QuestionFormScreenState();
}

class _QuestionFormScreenState extends State<QuestionFormScreen> {
  final _title = TextEditingController();
  final _content = TextEditingController();
  final _topicIds = <int>{};

  /// Ảnh đã đăng còn giữ (khi sửa) và ảnh mới chọn trên máy.
  List<MediaItem> _kept = [];
  List<String> _newImages = [];

  /// Đã thay đổi gì đó: rời form thì hỏi lại. [_leaving] = đang đóng form sau khi lưu.
  bool _dirty = false;
  bool _leaving = false;

  late final FaqController _faq = context.read<FaqController>();

  bool get _editing => widget.questionId != null;

  @override
  void initState() {
    super.initState();
    _faq.clearSuggestions();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final c = context.read<QuestionController>();
    await c.openForm(questionId: widget.questionId);
    final old = c.editing;
    if (!mounted || old == null) {
      return;
    }
    _title.text = old.title;
    _content.text = old.content;
    setState(() {
      _topicIds
        ..clear()
        ..addAll(old.topicIds);
      _kept = old.images;
      _dirty = false;
    });
  }

  @override
  void dispose() {
    _faq.clearSuggestions();
    _title.dispose();
    _content.dispose();
    super.dispose();
  }

  void _changed() {
    if (!_dirty) {
      setState(() => _dirty = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = context.watch<QuestionController>();
    return PopScope(
      canPop: !_dirty || _leaving,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) {
          _leaveIfConfirmed();
        }
      },
      child: Scaffold(
        appBar: AppBar(title: Text(_editing ? 'Sửa câu hỏi' : 'Đặt câu hỏi')),
        body: _body(c),
      ),
    );
  }

  Widget _body(QuestionController c) {
    if (c.isLoadingForm) {
      return const LoadingView();
    }
    final compose = c.compose;
    if (compose == null) {
      // Không mở được form: phiên đăng nhập hết, không phải người hỏi, câu hỏi không còn…
      return ErrorView(message: c.formError ?? 'Không tải được dữ liệu. Vui lòng thử lại.', onRetry: _load);
    }
    final theme = Theme.of(context);
    final errors = c.fieldErrors;
    final status = c.editing?.status;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
      children: [
        Text(
          _editing
              ? 'Sửa lại câu hỏi để mọi người hiểu đúng điều bạn cần.'
              : 'Hỏi cộng đồng, các senpai đã trải qua sẽ trả lời bạn.',
          style: theme.textTheme.bodyMedium,
        ),
        if (!_editing && compose.newAccount) _quota(compose),
        if (_editing && (status == 'PROCESSING' || status == 'REJECTED'))
          Card(
            color: status == 'REJECTED' ? theme.colorScheme.errorContainer : theme.colorScheme.tertiaryContainer,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                status == 'REJECTED'
                    ? 'Câu hỏi chưa được đăng vì ảnh vi phạm Quy tắc cộng đồng (đã được gỡ). Sửa xong bấm “Lưu thay đổi” '
                          'để đăng lại.'
                    : 'Ảnh đang được quét; trong lúc này chỉ bạn thấy câu hỏi.',
              ),
            ),
          ),
        const SizedBox(height: 12),
        TextField(
          controller: _title,
          maxLength: compose.titleMax,
          minLines: 1,
          maxLines: 3,
          textInputAction: TextInputAction.next,
          decoration: InputDecoration(
            labelText: 'Câu hỏi *',
            hintText: 'Ví dụ: Gia hạn visa du học cần mang những giấy tờ gì?',
            border: const OutlineInputBorder(),
            errorText: errors['title'],
          ),
          onChanged: (text) {
            _changed();
            if (!_editing) {
              _faq.suggest(text);
            }
          },
        ),
        if (!_editing) _suggestions(),
        const SizedBox(height: 8),
        Text('Chủ đề * (${_topicIds.length}/${compose.topicsMax})', style: theme.textTheme.titleSmall),
        const SizedBox(height: 4),
        Wrap(
          spacing: 8,
          runSpacing: 4,
          children: [
            for (final topic in compose.topics)
              FilterChip(
                label: Text(topic.name),
                selected: _topicIds.contains(topic.id),
                onSelected: (on) => setState(() {
                  _dirty = true;
                  if (on) {
                    _topicIds.add(topic.id);
                  } else {
                    _topicIds.remove(topic.id);
                  }
                }),
              ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          errors['topicIds'] ?? 'Chọn từ 1 đến ${compose.topicsMax} chủ đề. Không có chủ đề phù hợp thì chọn “Khác”.',
          style: theme.textTheme.bodySmall?.copyWith(
            color: errors['topicIds'] != null ? theme.colorScheme.error : null,
          ),
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _content,
          minLines: 5,
          maxLines: 12,
          maxLength: compose.contentMax,
          decoration: InputDecoration(
            labelText: compose.contentRequired ? 'Mô tả chi tiết *' : 'Mô tả chi tiết (không bắt buộc)',
            hintText: 'Thêm bối cảnh để mọi người trả lời đúng: bạn đang ở đâu, đã thử những gì',
            alignLabelWithHint: true,
            border: const OutlineInputBorder(),
            errorText: errors['content'],
            helperText: compose.canPostLinks
                ? 'Bạn có tag định danh nên được chèn link. Không dùng link rút gọn (bit.ly, tinyurl…).'
                : 'Chỉ tài khoản đã có tag định danh mới được chèn link, ghi số điện thoại hoặc tài khoản Zalo, LINE, '
                      'Telegram, hay đăng ảnh có mã QR.',
            helperMaxLines: 3,
          ),
          onChanged: (_) => _changed(),
        ),
        if (c.editing?.places.isNotEmpty ?? false) ...[
          const SizedBox(height: 8),
          Text(
            'Địa điểm liên quan (giữ nguyên): ${c.editing!.places.map((p) => p.name).join(', ')}',
            style: theme.textTheme.bodySmall,
          ),
        ],
        const SizedBox(height: 16),
        _images(compose, errors['images']),
        if (c.formError != null)
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Text(c.formError!, style: TextStyle(color: theme.colorScheme.error)),
          ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            TextButton(onPressed: () => Navigator.maybePop(context), child: const Text('Hủy')),
            const SizedBox(width: 8),
            FilledButton.icon(
              onPressed: c.isSaving ? null : _save,
              icon: const Icon(Icons.send),
              label: Text(c.isSaving ? 'Đang gửi…' : (_editing ? 'Lưu thay đổi' : 'Đăng câu hỏi')),
            ),
          ],
        ),
      ],
    );
  }

  Widget _quota(QuestionCompose compose) {
    final full = compose.postsLimit > 0 && compose.postsUsed >= compose.postsLimit;
    return Card(
      color: full ? Theme.of(context).colorScheme.errorContainer : null,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Text(
          'Tài khoản mới, hôm nay: ${compose.postsUsed}/${compose.postsLimit} bài viết và review.'
          '${full ? ' Bạn đã dùng hết lượt đăng hôm nay, hãy quay lại vào ngày mai.' : ''}',
        ),
      ),
    );
  }

  /// "Có thể đã có câu trả lời": câu hỏi thường gặp giống câu đang gõ, mở rộng tại chỗ.
  Widget _suggestions() {
    final suggestions = context.watch<FaqController>().suggestions;
    if (suggestions.isEmpty) {
      return const SizedBox.shrink();
    }
    final theme = Theme.of(context);
    return Card(
      margin: const EdgeInsets.only(top: 4, bottom: 8),
      color: theme.colorScheme.secondaryContainer.withValues(alpha: 0.4),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text('Có thể đã có câu trả lời', style: theme.textTheme.titleSmall),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
              child: Text(
                'Những câu hỏi thường gặp này giống điều bạn định hỏi. Nếu chưa đúng ý, bạn cứ đăng câu hỏi.',
                style: theme.textTheme.bodySmall,
              ),
            ),
            for (final entry in suggestions) FaqTile(entry: entry),
          ],
        ),
      ),
    );
  }

  /// Ảnh đã đăng (khi sửa, bỏ được) và ảnh mới chọn; tổng cộng tối đa imagesMax.
  Widget _images(QuestionCompose compose, String? error) {
    final theme = Theme.of(context);
    final room = compose.imagesMax - _kept.length;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Ảnh (không bắt buộc)', style: theme.textTheme.titleSmall),
        const SizedBox(height: 8),
        if (_kept.isNotEmpty) ...[
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final image in _kept)
                Stack(
                  children: [
                    MediaImage(url: image.url, width: 80, height: 80),
                    Positioned(
                      right: 0,
                      top: 0,
                      child: InkWell(
                        onTap: () => setState(() {
                          _dirty = true;
                          _kept = [..._kept]..remove(image);
                        }),
                        child: const CircleAvatar(
                          radius: 12,
                          child: Icon(Icons.close, size: 16, semanticLabel: 'Bỏ ảnh này'),
                        ),
                      ),
                    ),
                  ],
                ),
            ],
          ),
          const SizedBox(height: 8),
        ],
        PhotoPicker(
          paths: _newImages,
          max: room < 0 ? 0 : room,
          label: _kept.isEmpty ? 'Ảnh' : 'Ảnh mới',
          onChanged: (paths) => setState(() {
            _dirty = true;
            _newImages = paths;
          }),
        ),
        const SizedBox(height: 4),
        Text(
          error ??
              'Ảnh JPG, PNG hoặc HEIC, tối đa ${compose.imagesMax} ảnh, mỗi ảnh không quá ${compose.imageMaxMb} MB.',
          style: theme.textTheme.bodySmall?.copyWith(color: error != null ? theme.colorScheme.error : null),
        ),
      ],
    );
  }

  Future<void> _save() async {
    final c = context.read<QuestionController>();
    final saved = await c.saveQuestion(
      title: _title.text,
      content: _content.text,
      topicIds: _topicIds.toList(),
      keepImageIds: [for (final image in _kept) image.id],
      imagePaths: _newImages,
    );
    if (!saved || !mounted) {
      return;
    }
    setState(() => _leaving = true);
    if (_editing) {
      Navigator.pop(context, true);
      return;
    }
    // Câu hỏi mới: mở luôn câu vừa đăng, như web
    showMessage(context, c.takeMessage());
    final id = c.lastSavedId;
    if (id == null || id == 0) {
      Navigator.pop(context, true);
      return;
    }
    Navigator.pushReplacement(context, MaterialPageRoute<void>(builder: (_) => QuestionDetailScreen(questionId: id)));
  }

  /// Bấm quay lại khi form có thay đổi chưa lưu: hỏi trước khi bỏ.
  Future<void> _leaveIfConfirmed() async {
    if (await _confirmLeave() && mounted) {
      setState(() => _leaving = true);
      Navigator.pop(context);
    }
  }

  Future<bool> _confirmLeave() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Bỏ thay đổi?'),
        content: const Text('Bạn có thay đổi chưa lưu. Bạn có muốn bỏ các thay đổi này không?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Ở lại')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Bỏ thay đổi')),
        ],
      ),
    );
    return ok == true;
  }
}
